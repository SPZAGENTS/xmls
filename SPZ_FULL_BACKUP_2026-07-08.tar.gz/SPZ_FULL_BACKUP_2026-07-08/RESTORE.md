# SPZ Backup - הוראות שחזור

## מה מועבר?
- ✅ active-crons/ - כל סקריפטי ה-automation
- ✅ skills/ - כל הסקילים והכלים
- ✅ scripts/ - סקריפטים משותפים
- ✅ memory/ - כל הזיכרונות והארכיון
- ✅ MEMORY.md - זיכרון מרכזי
- ✅ MASTER-INSIGHTS.md + INSIGHTS-CROSS-REFERENCE.md
- ✅ כל קבצי התצורה (AGENTS.md, SOUL.md, TOOLS.md, וכו')
- ✅ .env.template - תבנית למפתחות API (ללא מפתחות אמיתיים!)

## מה חסר?
- ❌ .env עם מפתחות API אמיתיים (צריך להגדיר ידנית)
- ❌ קובצי state מקומיים (spz_state.db וכו')

## הוראות שחזור

### שלב 1: העתקת קבצים
```bash
cp -r active-crons/ ~/.openclaw/workspace/
cp -r skills/ ~/.openclaw/workspace/
cp -r scripts/ ~/.openclaw/workspace/
cp -r memory/ ~/.openclaw/workspace/
cp MEMORY.md ~/.openclaw/workspace/
cp MASTER-INSIGHTS.md ~/.openclaw/workspace/
cp INSIGHTS-CROSS-REFERENCE.md ~/.openclaw/workspace/
cp HEARTBEAT.md ~/.openclaw/workspace/
# וכו'...
```

### שלב 2: הגדרת API Keys
1. העתק את .env.template ל-.env
2. מלא את המפתחות האמיתיים שלך

### שלב 3: התקנת dependencies
- wacli (WhatsApp CLI)
- node.js, python3
- כל הסקילים שצריך

### שלב 4: רישום קרונים ב-OpenClaw
```bash
cron add --name spz-rss-hourly --schedule "0 * * * *" --command "bash ~/.openclaw/workspace/active-crons/01-spz-rss-hourly/run.sh"
cron add --name twitter-grok-4h --schedule "0 */4 * * *" --command "bash ~/.openclaw/workspace/active-crons/02-twitter-grok-4h/run.sh"
# וכו'...
```
