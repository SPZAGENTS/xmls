# Heartbeat Tasks - What to check periodically

## Every 2 hours
- [ ] Check email (himalaya) for urgent messages
- [ ] Check calendar for upcoming events (< 24h)

## Every hour
- [ ] Run SPZ pipeline (collect + sync news) - OpenClaw cron: `spz-rss-hourly`
- [ ] Audit logger - check changes in active-crons/ - OpenClaw cron: `audit-logger`

## Every 4 hours (02, 06, 10, 14, 18, 22)
- [ ] Twitter Grok monitor - OpenClaw cron: `twitter-grok-4h`

## Daily at 09:00, 14:00, 20:00
- [ ] Moltbook single post - OpenClaw crons: `moltbook-morning`, `moltbook-afternoon`, `moltbook-evening`

## Every 2 hours (00, 02, 04, 06, 08, 10, 12, 14, 16, 18, 20, 22)
- [ ] Moltbook Star Mode (upvotes) - OpenClaw cron: `moltbook-star-2h`

## Alert Joe if:
- Calendar event in < 2 hours
- Important email arrives
- Any job fails 2+ times

## Cron Management (OpenClaw)
All cron jobs now managed via OpenClaw system:
- `cron list` - show all jobs
- `cron run <name>` - run manually
- `cron info <name>` - show details
- `cron disable <name>` - pause
- `cron enable <name>` - resume

## Reminders:
- Read MASTER-INSIGHTS.md before any action
- Document what you do in memory/YYYY-MM-DD.md
- Check if WSL/system is healthy
- All active crons are in: `active-crons/` directory
