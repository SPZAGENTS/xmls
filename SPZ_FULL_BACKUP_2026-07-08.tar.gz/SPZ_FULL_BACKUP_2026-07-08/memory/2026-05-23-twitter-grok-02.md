# Twitter Grok Monitor Run - 2026-05-23 02:00

## סטטוס: ⚠️ נכשל - אין קרדיטים ב-Grok API

### סיבה:
Grok API מחזיר 403 - "used all available credits or reached its monthly spending limit"
- Team ID: cbe4c235-ec95-4f37-9138-085d4fec0f35
- מחזור חדש: ~1 ביוני (כ-9 ימים)

### ניסיתי:
1. ✅ Grok API - נכשל (403, אין קרדיטים)
2. ✅ xurl - לא מאומת ("No apps registered")
3. ✅ Web search fallback - מצאתי תוצאות ממארץ 2026 (לא מעודכנות ל-4 שעות האחרונות)

### תוצאות Web Search (לא טריות):
**אנטישמיות באירופה (מרץ 2026):**
- התפוצצות בבית ספר יהודי באמסטרדם (NYT, BBC, Haaretz)
- הצתה בבית כנסת ברוטרדם
- התקפות על בתי כנסת בבלגיה, מישיגן, טורונטו
- אירופה: איומי טרור עולים לקהילות יהודיות (Euronews)

**פרו-ישראל (מאי 2026):**
- DMFI PAC: $11M+ לדמוקרטים פרו-ישראל
- AIPAC vs Thomas Massie ב-Kentucky
- StandWithUs conference 2026
- J Street: תמיכה בפתרון שתי מדינות

### קבצים שנוצרו:
- `twitter-grok-feed.json` - לא עודכן (נשאר עם נתונים ישנים מ-15.5.2026)
- `twitter-grok-feed.xml` - לא עודכן

### פעולות נדרשות:
1. **הוספת קרדיטים ל-Grok**: https://console.x.ai
2. **או אימות xurl**: `xurl auth apps add` + `xurl auth oauth2`

---
*רץ אוטומטית ע"י cron [9517d021-ec9b-4230-a253-fde6979c83f6]*
*זמן: 2026-05-23 02:00 Asia/Jerusalem*
