---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: contacts
description: אנשי קשר ומספרי טלפון
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
version: "1.0.0"
---

# Contacts

## Personal
- **יוסי** (אני) = `+972527222872` — האדם שלי
- **שפיצי** (אתה) = `+972502303683` — הסוכן הראשי (אני!)

## Others
- **בן הסחבק** = `+972544289167`
- **סוכן סודי** = `+972525938537` — פעולות מיוחדות
