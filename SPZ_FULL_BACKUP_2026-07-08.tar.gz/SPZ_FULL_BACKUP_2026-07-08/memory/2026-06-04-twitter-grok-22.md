# Twitter Grok Monitor Run - 2026-06-04 22:00 (10:00 PM Jerusalem)

## סטטוס: ✅ FALLBACK SUCCESS (Web Fetch - JPost)

### הבעיות המתמשכות:
1. **Grok API** - 401 Unauthorized (נמשך מ-21 במאי)
2. **xurl** - לא מאומת ("No apps registered")

### פתרון:
Web fetch fallback ישירות מ-JPost (4 מקורות):
- diaspora/antisemitism
- israel-news
- international
- middle-east

---

## תוצאות (23 פריטים):

### 🚨 אנטישמיות מהשטח (11 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [97] | NYC antisemitic hate crimes 70% higher in May 2026 than May 2025, 41 incidents confirmed | June 3 |
| [96] | 'No Jews in our hotel': Israeli family denied access to Bavarian hotel | June 3 |
| [95] | Man wearing Star of David necklace beaten in possible antisemitic gang attack in Germany | June 3 |
| [94] | Four more arrested for two drive-by gel pellet gun attacks on Toronto Jews | June 3 |
| [93] | New CAM report: Instagram algorithm funnels users to antisemitic propaganda in days | June 3 |
| [92] | Suspect starts fire in Golders Green apartment building, residents extinguish | June 3 |
| [91] | Student group praises Boulder firebomb terrorist for 'resistance' on anniversary | June 3 |
| [90] | Five arrested in Toronto for antisemitic signs at anti-Israel rally in Jewish neighborhood | June 2 |
| [89] | NYU student charged with hate crime after flying swastika, Star of David flag over campus | June 4 |
| [88] | SJP political program calls to 'usurp' universities to 'weaken the US' | recent |
| [87] | Zack Polanski signs letter calling for investigation, screening of IDF vets with UK citizenship | recent |

### 🇮🇱 פרו-ישראל/ביטחון (12 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [96] | IDF, Shin Bet kill several Hamas General Security Apparatus officials in Gaza | June 4 |
| [95] | IDF chief Zamir: Military 'shoulder to shoulder' with northern leaders | June 4 |
| [94] | First woman completes IDF Sayeret Matkal course, set to join operational service | June 4 |
| [93] | David Barnea's Mossad revolution: How the spy agency became a war-fighting juggernaut | June 4 |
| [92] | Knesset passes first reading of bill to split attorney-general's role | June 4 |
| [91] | Netanyahu appoints Guy Markizeno as military secretary after Mossad reshuffle | June 4 |
| [90] | UK gov't removes Israel from 'no travel list' for first time since June 2025 Iran war | June 3 |
| [89] | Hezbollah rejects ceasefire after US announces ceasefire between Israel, Lebanon | June 4 |
| [88] | Hezbollah threatens to target Tel Aviv, Haifa, if Israel strikes again in Beirut | June 4 |
| [87] | Trump says US will not return to war against Iran unless American troops are killed | June 4 |
| [86] | Iran demands frozen assets be released in initial phase of deal with US, leading to stalemate | June 4 |
| [85] | US-Iran negotiations 'going well,' could reach deal by weekend, Trump claims | June 3 |

---

## סיכום:
- **23 פריטים** מ-4 מקורות JPost
- **11 אנטישמיות** - עלייה חדה ב-NYC (+70%), תקיפות גרמניה/קנדה/אנגליה
- **12 ביטחון/מדיניות** - חיסולים בעזה, חיזבאללה דוחה הפסקת אש, מו"מ איראן-ארה"ב

*דוח נוצר: 2026-06-04T22:00:00+03:00*
