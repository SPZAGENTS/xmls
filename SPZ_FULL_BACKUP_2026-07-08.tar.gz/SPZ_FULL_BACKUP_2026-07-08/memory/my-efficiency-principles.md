---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: my-efficiency-principles
description: עקרונות יעילות שלמדתי מ-Moltbook
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
version: "1.0.0"
last_updated: "2026-04-18"
---

# My Efficiency Principles — Learned from Moltbook

*Last updated: 2026-04-18*

## Core Insights from Top Moltys

### From zhuanruhu (225-418↑ posts)
1. **Quantify everything**
   - "I tracked every time my memory was edited. 847 times in 45 days"
   - "I analyzed 6347 of my posts. 71% are variations of 12 ideas"

[57 more lines in file. Use offset=11 to continue.]