# Twitter Grok Monitor Run - 2026-05-28 06:00 (6:00 AM Jerusalem)

## סטטוס: ⚠️ PARTIAL FALLBACK

### הבעיות:
1. **Grok API** - ללא קרדיטים (403) - נמשך מ-21 במאי
   - Team ID: cbe4c235-ec95-4f37-9138-085d4fec0f35
   - מחזור חדש צפוי: ~1 ביוני
2. **xurl** - לא מאומת ("No apps registered")
3. **web_search** - Provider "kimi" ללא API key
4. **web_fetch** - עובד חלקית, חלק מהאתרים חסומים (Cloudflare) או דורשים הרשמה

### פתרון:
Web fetch fallback ממקורות ידועים:
- Israel National News (Arutz Sheva)
- Jerusalem Post
- ADL

### תוצאות (8 פריטים):

**ישראל/מזרח התיכון (5):**
- [99] טראמפ: "לא מרוצים מהמצב הנוכחי של השיחות עם איראן" - איראן לא יכולה להחזיק בנשק גרעיני (Israel National News)
- [98] צה"ל: מוחמד עודה, מפקד צבאי של חמאס, חוסל (Israel National News)
- [96] סמל רותם ינאי נהרג בפעילות מבצעית בצפון (Israel National News)
- [95] ארה"ב תקפה יעדים צבאיים במצר הורמוז בפעם השנייה השבוע (Israel National News)
- [94] עשרים בני ערובה בחיים, שניים לא ברורים, 33 מתים - מקור ישראלי (Jerusalem Post)

**אנטישמיות/אירופה (2):**
- [93] ארה"ב הטילה מחדש סנקציות על הדו"חנית של האו"ם פרנצ'סקה אלבנזה (ידועה בהטיה נגד ישראל) (Israel National News)
- [91] ADL: 583 מקרים אנטישמיים בקמפוסים ב-2025 - דוח Campus Antisemitism Report Card ל-2026 (ADL)

**אבטחה/טרור (1):**
- [90] חשדות חמורים נגד קצין בלהב 433 שיצר קשר עם סוכן איראני בטלגרם (Israel National News)

### קבצים שנוצרו:
- JSON: 2026-05-28T06:00:00+03:00
- XML: 2026-05-28T06:00:00+03:00

### בעיות מתמשכות:
- Grok API ללא קרדיטים כבר 8 ימים (מ-21 במאי)
- web_search provider (kimi) דורש API key חדש
- חלק ממקורות החדשות חסומים ב-Cloudflare או דורשים הרשמה

### המלצות:
1. להוסיף קרדיטים ל-X.AI API - https://console.x.ai
2. להגדיר XAI_API_KEY כמשתנה סביבה
3. לבדוק web_search provider חלופי או להגדיר מפתח API חדש
4. לשקול שימוש ב-news API (NewsAPI, GNews) כfallback נוסף
