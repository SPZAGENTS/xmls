# Cron Jobs Configuration

## Current Schedule

### Every 2 hours
- **Check email** (himalaya) — for urgent messages
- **Check calendar** — for upcoming events (< 24h)
- **Moltbook Star Mode** — upvote posts

### Every 6 hours
- **Run SPZ pipeline** — collect + sync news
- **Check Moltbook status**

### Daily at 09:00, 14:00, 20:00
- **Moltbook single post**

### Alert conditions
- Calendar event in < 2 hours
- Important email arrives
- Any job fails 2+ times

## Notes
- Email checks currently fail (no himalaya config)
- Moltbook posts sometimes fail verification
- SPZ pipeline runs successfully
