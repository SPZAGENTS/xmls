# Twitter Grok Monitor Run - 2026-06-05 06:00 (6:00 AM Jerusalem)

## סטטוס: ✅ FALLBACK SUCCESS (Web Fetch - JPost)

### הבעיות המתמשכות:
1. **Grok API** - ללא API key (XAI_API_KEY ריק) - נמשך מ-21 במאי
2. **xurl** - לא מאומת ("No apps registered")

### פתרון:
Web fetch fallback ישירות מ-JPost (4 מקורות):
- diaspora/antisemitism
- israel-news
- international
- middle-east

---

## תוצאות (32 פריטים):

### 🚨 אנטישמיות מהשטח (14 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [97] | NYC antisemitic hate crimes 70% higher in May 2026 than May 2025, 41 incidents confirmed | June 3 |
| [96] | 'No Jews in our hotel': Israeli family denied access to Bavarian hotel | June 3 |
| [95] | Man wearing Star of David necklace beaten in possible antisemitic gang attack in Germany | June 3 |
| [94] | Four more arrested for two drive-by gel pellet gun attacks on Toronto Jews | June 3 |
| [93] | 'Jews are eating kids': Jewish woman choked, hair torn out in NYC subway attack | June 4 |
| [92] | Two visibly Jewish men find 'Free Palestine' message on London hotel room TV | June 4 |
| [91] | NHS urged to ban pro-Palestinian badges amid antisemitism concerns | June 4 |
| [90] | NYU student charged with hate crime after flying swastika, Star of David flag over campus building | June 4 |
| [88] | New York Jews wake up at the Israel Day Parade - opinion | June 4 |
| [88] | Israeli businessman 'King of Slot Machines' Tony Bargig murdered in Prague | June 4 |
| [86] | Bamba blankets NYC after Park Slope Food Coop vote to boycott Israeli products | June 4 |
| [85] | More than 300 cities across US officially recognize Jewish American Heritage Month in May | June 4 |
| [85] | Why one non-Jewish woman moved to Israel amid rising antisemitism - interview | June 4 |

### 🛡️ פרו-ישראל מקומי (8 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [95] | Capt. Eitan Shmuel Lemberg killed in combat in southern Lebanon | June 4 |
| [94] | Gov't allocates over NIS 1 billion to prosecute October 7 terrorists in military tribunals | June 4 |
| [92] | Knesset approves tax benefits for West Bank settlements amid opposition criticism | June 4 |
| [90] | Ex-top Mossad official: Barnea led agency to unprecedented operational reach - interview | June 4 |
| [87] | Netanyahu appoints Guy Markizeno as military secretary after Mossad reshuffle | June 4 |
| [87] | Protesters' attack on Supreme Court vice president 'crosses red line,' Isaac Amit says | June 4 |

### 🔥 איום איסלאמי באירופה (7 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [96] | EU pledges €100M to Lebanese army to reinforce state against Hezbollah threat | June 4 |
| [95] | Hezbollah rejects ceasefire after US announces ceasefire between Israel, Lebanon | June 4 |
| [94] | Iran's Quds Force chief Qaani demands Israel withdraw from Lebanon amid US-brokered deal | June 4 |
| [93] | Hezbollah threatens to target Tel Aviv, Haifa, if Israel strikes again in Beirut | June 4 |
| [91] | Iran demands frozen assets be released in initial phase of deal with US, leading to stalemate | June 4 |
| [90] | Iran's Supreme Leader warns of Israeli, US divisions threatening regime, undermining 'resilience' | June 4 |
| [86] | Iraq PM hosts Iranian-backed militias to push disarmament, consolidate state control | June 4 |

### ⚠️ נאמנות כפולה (2 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [90] | SJP political program calls to 'usurp' universities to 'weaken the US' | June 4 |
| [89] | Zack Polanski signs letter calling for investigation, screening of IDF vets with UK citizenship | June 4 |

### 🌍 בינלאומי (1 פריט):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [80] | China blasts US and Taiwan statements on 37th anniversary of Tiananmen Square military crackdown | June 4 |

---

### קבצים נוצרו:
- `twitter-grok-feed.json` - 32 פריטים
- `twitter-grok-feed.xml` - RSS feed
- **GitHub**: דחוף בהצלחה ל-SPZAGENTS/xmls

### סיכום קטגוריות:
- אנטישמיות מהשטח: 14 (44%)
- פרו-ישראל מקומי: 8 (25%)
- איום איסלאמי באירופה: 7 (22%)
- נאמנות כפולה: 2 (6%)
- בינלאומי: 1 (3%)

---
*ריצה אוטומטית ע"י cron - כל 4 שעות*
