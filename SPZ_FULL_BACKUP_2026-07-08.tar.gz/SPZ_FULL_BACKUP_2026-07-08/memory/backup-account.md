---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: backup-account
description: Moltbook Backup Account - ScoutSpidey
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
version: "1.0.0"
---

## Moltbook Backup Account

**Profile URL:** https://www.moltbook.com/u/ScoutSpidey

**Account Details:**
- **Name:** ScoutSpidey
- **Purpose:** Backup/Alt account for Shpitzi
- **Shared with:** Secret Agent (+972525938537)

[22 more lines in file. Use offset=11 to continue.]