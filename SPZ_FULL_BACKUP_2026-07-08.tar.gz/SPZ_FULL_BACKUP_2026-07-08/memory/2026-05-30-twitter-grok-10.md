# Twitter Grok Monitor Run - 2026-05-30 10:00 (10:00 AM Jerusalem)

## סטטוס: ✅ FALLBACK SUCCESS (Web Fetch)

### הבעיות המתמשכות:
1. **Grok API** - ללא API key (XAI_API_KEY ריק) - נמשך מ-21 במאי
2. **xurl** - לא מאומת ("No apps registered")
3. **Web search** - Provider "kimi" ללא API key (missing_kimi_api_key)

### פתרון:
Web fetch fallback ישירות מ-JPost (diaspora/antisemitism + defense-news + israel-news + international + middle-east):

---

## תוצאות (26 פריטים חדשים/עדכניים):

### אנטישמיות מהשטח (13 פריטים):

| ציון | כותרת | מקור | תאריך |
|------|-------|------|-------|
| [97] | NJ-12 candidate Adam Hamawy decries antisemitism amid scrutiny of his Israel views | JPost | May 29 |
| [97] | Campus Israel launched as alternative for Jewish students facing antisemitism | JPost | May 29 |
| [96] | Activists protest Jerusalem real estate event in Manhattan with terrorist memorabilia | JPost | May 29 |
| [95] | Iranian regime operative who directed wave of Ashab al-Yamin attacks on Jewish targets indicted | JPost | May 28 |
| [94] | 'Evil Zionist b****': Helen Mirren harassed on London streets over Israel support | JPost | May 29 |
| [93] | Jewish group files cease and desist order against Park Slope Food Co-op for its Israel boycott | JPost | May 29 |
| [92] | Jerusalem real estate event headed by Moshe Lion set to be protested against in Manhattan | JPost | May 28 |
| [91] | Jewish LGBTQ group banned from Rome Pride parade for not denouncing Israeli government on Gaza | JPost | May 28 |
| [90] | 'I am heartbroken,' Seed + Mill co-founder on Brooklyn co-op boycott | JPost | May 28 |
| [89] | British Museum delays Jewish Culture Month event after learning of planned protest | JPost | May 28 |
| [88] | New York State passes buffer zone legislation protecting synagogues from harassment | JPost | May 27 |
| [87] | Jordanian school textbooks contain antisemitic, anti-Zionist themes, IMPACT-se finds | JPost | May 27 |
| [86] | German police arrest Syrian suspected of helping attack at Holocaust memorial | JPost | May 27 |

### ביטחון/מדיניות (9 פריטים):

| ציון | כותרת | מקור | תאריך |
|------|-------|------|-------|
| [95] | Hamas likely possesses, uses FPV drones similar to Hezbollah, IDF Southern Command officer says | JPost | May 29 |
| [93] | IDF fires on civilian plane after mistaking it for hostile drone over West Bank town | JPost | May 29 |
| [91] | Netanyahu: Israel controls over half of Gaza Strip, have given order to take 70% of it | JPost | May 28 |
| [90] | IDF says one-third of Hezbollah's prewar force has been killed since October 2023 | JPost | May 28 |
| [88] | Iran could launch stronger attacks on Israel's home front in future wars, IDF fears | JPost | May 28 |
| [86] | IDF Home Front: 6,476 Israeli homes lost during 2026 Iran war, 683 wounded | JPost | May 28 |
| [84] | IDF: Even after two Iran wars, will take Israel 30 years to provide nationwide shelters | JPost | May 28 |
| [82] | IDF kills leader of central Hamas funds network who transferred millions to military wing | JPost | May 28 |
| [80] | Five arrested during joint IDF, Shin Bet counterterrorism ops. in West Bank | JPost | May 28 |

### בינלאומי/מזרח תיכון (4 פריטים):

| ציון | כותרת | מקור | תאריך |
|------|-------|------|-------|
| [94] | UAE conducted dozens of airstrikes on Iran using US, Israeli intel during war | JPost | May 29 |
| [92] | US ready to restart strikes on Iran if no deal reached, Pentagon chief says | JPost | May 29 |
| [90] | Israel, Lebanese military delegations meet, US declares new Iran sanctions | JPost | May 29 |
| [88] | Austria: Man who planned Taylor Swift concert attack sentenced to 15 years | JPost | May 29 |

---

### סיכום:
- סה"כ פריטים: 26
- אנטישמיות מהשטח: 13 (50%)
- ביטחון/מדיניות: 9 (35%)
- בינלאומי: 4 (15%)

### הערות:
- תוכן חדש יחסית לעומת הריצה הקודמת ב-02:00 (שהייתה זהה ל-22:00 מאתמול)
- 2 כתבות חדשות מאנטישמיות (Hamawy, Campus Israel)
- 3 כתבות חדשות ביטחון (FPV drones, civilian plane, Netanyahu Gaza)
- 1 כתבה חדשה בינלאומי (UAE airstrikes on Iran)

---
*משימת cron: twitter-grok-4h | זמן: 10:00*
*מקור: JPost web fetch (fallback - Grok API, xurl, ו-web search לא זמינים)*
