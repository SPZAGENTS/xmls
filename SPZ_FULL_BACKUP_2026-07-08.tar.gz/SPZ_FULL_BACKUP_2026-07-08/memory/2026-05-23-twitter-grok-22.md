# Twitter Grok Monitor Run - 2026-05-23 22:00 (10:00 PM Jerusalem)

## סטטוס: ⚠️ Fallback - Grok API ללא קרדיטים, web search חסום

### בעיות:
1. **Grok API** - אין קרדיטים (403)
   - Team ID: cbe4c235-ec95-4f37-9138-085d4fec0f35
   - מחזור חדש: ~1 ביוני (~9 ימים)
   - ניסיונות רצופים כושלים: 21, 22, 23 (02:00, 10:00, 18:00, 22:00)

2. **web_search** - SearXNG לא מוגדר
   - שגיאה: "SearXNG base URL is not configured"
   - DuckDuckGo fallback חזר 0 תוצאות (freshness not supported)
   - Kimi provider לא תומך ב-date filtering

3. **web_fetch** - עבד חלקית
   - Israel National News: מצאתי כתבות אחרונות
   - Hillel: נתוני קמפוס

### תוצאות Web Fetch Fallback:

**1. אנטישמיות ואירועים נגד יהודים:**
- 🇦🇹 משרד התפוצות הזהיר מאנטישמיות ומפגינים נגד ישראל לקראת אירוויזיון 2026 בווינה (Israel National News #426906)
- 🎓 1,662 ת incidentים אנטישמיים בקמפוסים בארה"ב בשנה"ל 2025-2026 (Hillel International, נכון ל-15 מאי)
- 🚫 שמחי חקלי סירב להכניס את יוטיובר אמריקאי Tyler Oliveira בגין תוכן אנטישמי (Israel National News #426916)

**2. סכסוך ישראל-חיזבאללה:**
- 🚁 חיזבאללה שיגר רקטות וכטב"מים נגד כלי הנדסה לא מאוישים של צה"ל בדרום לבנון (Israel National News #426908)
- 💥 צה"ל חיסל תא שיגור שנסה להעביר משגר רקטות במשאית (Israel National News #426912)

**3. פוליטיקה פנימית ישראל:**
- 🏛️ טיבי ומשפחות שכולות התנגשו במליאת הכנסת, פסקו את הדיון (Israel National News #426914)
- 🎯 נתניהו תקף את ראש המוסד ברנע על השתתפות בעתירה לבג"ץ (Israel National News #426909)
- ⚖️ נתניהו מינה את רומן גופמן למנכ"ל המוסד (Israel National News #426915)

### סיכום:
- **Grok API**: נכשל (0 תוצאות)
- **Web Search**: נכשל (SearXNG down)
- **Web Fetch**: הצליח חלקית (3 מקורות)
- **סה"כ פריטים**: 7 (fallback ידני)

### מה צריך לעשות:
1. **הוספת קרדיטים ל-Grok API** - https://console.x.ai (כנראה צריך לחכות ל-1 ביוני)
2. **תיקון SearXNG** - הגדרת SEARXNG_BASE_URL בקונפיגורציה
3. **אלטרנטיבה**: הגדרת xurl Twitter API אם עדיין רלוונטי

---
*רץ אוטומטית ע"י cron*
