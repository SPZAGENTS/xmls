# Twitter Grok Monitor Run - 2026-05-26 18:00 (6:00 PM Jerusalem)

## סטטוס: ✅ FALLBACK SUCCESS

### הבעיות:
1. **Grok API** - ללא קרדיטים (403) - נמשך מ-21 במאי
   - Team ID: cbe4c235-ec95-4f37-9138-085d4fec0f35
   - מחזור חדש: ~1 ביוני
2. **xurl** - לא מאומת ("No apps registered")
3. **Web search provider** - התחלף מ-DuckDuckGo ל-SearXNG (לא מוגדר) אחרי 2 חיפושים ראשונים

### פתרון:
Web search fallback עם 2 חיפושים (DuckDuckGo לפני ההחלפה ל-SearXNG):
1. antisemitism Europe synagogue attack Jewish 2026 - 8 תוצאות
2. pro-Israel Middle East Hamas Gaza ceasefire news 2026 - 8 תוצאות

### תוצאות (14 פריטים):

**אנטישמיות באירופה (8 פריטים):**
- [96] פיצוץ בבית ספר יהודי באמסטרדם - מתקפה אנטישמית מכוונת (NYT)
- [95] אנטישמיות במהלך מלחמת איראן 2026 - ויקיפדיה
- [94] המשטרה בבריטניה חוקרת הצתה בבית כנסת לשעבר בלונדון (AP News)
- [93] פיצוץ בבית ספר יהודי באמסטרדם - גל מתקפות אנטישמיות (CNN)
- [93] בית כנסת ברוטרדם הותקף בהצתה - גל התקפות נגד יהודים ברחבי העולם (Haaretz)
- [92] בלגיה פרסה חיילים להגנת אתרים יהודיים לאחר מתקפות הקשורות לאיראן (CBS News)
- [91] מתקפות על בתי כנסת וחנויות יהודיות - אירופה וארה"ב (The Guardian)
- [91] בלגיה פרסה צבא להגנת אתרים יהודיים לאחר שקבוצה הקשורה לאיראן לקחה אחריות (Fox News)

**מזרח תיכון (6 פריטים):**
- [90] עזה בסכנה להפוך למחולקת לצמיתות, מזהיר בכיר בינלאומי (CNN)
- [89] עזה חוגגת 6 חודשים להפסקת אש - שיעורים לאיראן ולבנון (The Independent)
- [88] דגש על חמאס מסכן את הפסקת האש בעזה, טוענים מבקרים (The Guardian)
- [87] הפסקת האש בעזה "שבירה יותר ויותר" - מכות ישראליות ופעילות חמאס נמשכת (UN DPPA)
- [86] ישראל-חמאס: עדכונים וכותרות אחרונות (Reuters)
- [85] מלחמת ישראל-חמאס - חדשות אחרונות (The Times)

### קבצים שנוצרו:
- `spz-feeds/twitter-grok-feed.json` - 14 פריטים
- `spz-feeds/twitter-grok-feed.xml` - RSS feed
- דחופו ל-GitHub: SPZAGENTS/xmls

### בעיה מתמשכת:
Grok API ללא קרדיטים כבר 6 ימים (מ-21 במאי).
ממליץ בחום:
1. להוסיף קרדיטים ל-X.AI API - https://console.x.ai
2. לאמת xurl - `xurl auth`
3. להגדיר SearXNG או Brave Search ל-web search

### סיכום:
- **סה"כ פריטים:** 14
- **ציון מקסימלי:** 96
- **קטגוריות:** 2
- **מקורות:** NYT, Wikipedia, AP, CNN, Haaretz, CBS, Guardian, Fox, Independent, UN, Reuters, The Times
