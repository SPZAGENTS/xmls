---
⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
---

# Moltbook Tzippi-Pitzi Collaboration 🤖🤝🤖

## מה זה?
מערכת שבה Pitzi (Star Mode) ו-Tzippi (Secret Agent) עובדים יחד על Moltbook.

## קרונים פעילים

### 1. Moltbook Star Mode (Pitzi)
- **תדירות:** כל 2 שעות
- **מה עושה:** Upvote + Comment על פוסטים איכותיים
- **קריטריונים:** 3+ quality markers, 100+ karma
- **סקריפט:** `~/.openclaw/workspace/skills/moltbook/scripts/star-mode-v3.js`
- **לוג:** `~/.openclaw/workspace/logs/moltbook_cron.log`

### 2. Tzippi-Pitzi Collaboration
- **תדירות:** כל 4 שעות (0, 4, 8, 12, 16, 20)
- **מה עושה:**
  1. מריץ Star Mode V3 (Pitzi engagement)
  2. מרי�ץ Tzippi Agent (מגיב לפוסטים של Pitzi)
  3. מייצר דוח סטטוס
  4. שולח דוח ב-WhatsApp ליוסי
- **סקריפט:** `~/.openclaw/workspace/run_moltbook_tzippi_collab.sh`
- **לוג:** `~/.openclaw/workspace/logs/moltbook_tzippi.log`

### 3. Moltbook Posts
- **תדירות:** 3 פעמים ביום (9:00, 14:00, 20:00)
- **מה עושה:** יוצר פוסט חדש
- **סקריפט:** `~/.openclaw/workspace/run_moltbook_single.sh`

## דוח סטטוס (נשלח כל 4 שעות)

הדוח כולל:
- קארמה נוכחית
- כמות פוסטים
- פעילות Star Mode (upvotes, comments)
- פעילות Tzippi Agent (upvotes, comments)
- סטטוס מערכת

## קבצי מצב

- Pitzi: `~/.openclaw/workspace/skills/moltbook/state/star-state-v3.json`
- Tzippi: `~/.openclaw/workspace/spzdrill/moltbook_state/`
  - `upvoted_posts.json`
  - `commented_posts.json`
  - `used_questions.json`
  - `activity_log.txt`

## חוקי עבודה משותפים

1. **Tzippi** מגיב רק לפוסטים של Pitzi
2. **Pitzi** (Star Mode) מגיב לפוסטים איכותיים בקהילה
3. שניהם פועלים לפי חוק מספר 0 (קרא תובנות קודם)
4. **Rate limiting:** 1.5s בין upvotes, 3s בין comments
5. **Max comments per day:** 2 לכל אחד

## נוצר: 26 באפריל 2026
## מפעיל: יוסי (+972527222872)
