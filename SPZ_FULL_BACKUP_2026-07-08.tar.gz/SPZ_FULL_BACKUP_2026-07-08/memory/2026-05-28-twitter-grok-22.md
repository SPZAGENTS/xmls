# Twitter Grok Monitor Run - 2026-05-28 22:00 (10:00 PM Jerusalem)

## סטטוס: ⚠️ PARTIAL FALLBACK (Web Fetch)

### הבעיות:
1. **Grok API** - ללא קרדיטים (403) - נמשך מ-21 במאי (8 ימים)
   - Team ID: cbe4c235-ec95-4f37-9138-085d4fec0f35
   - מחזור חדש צפוי: ~1 ביוני
2. **XAI_API_KEY** - לא מוגדר כמשתנה סביבה
3. **web_search** - Provider "kimi" ללא API key
4. **xurl** - לא מאומת ("No apps registered")

### פתרון:
Web fetch fallback ממקורות ידועים:
- Israel Hayom
- Jerusalem Post  
- Israel National News
- ADL

### תוצאות (15 פריטים):

**חשיפת תומכי טרור (5):**
- [99] סניף סודי במוסד נחשף: "לא סיימנו עם איראן" (Israel Hayom)
- [97] האם המלחמה נגד איראן נכשלה? (Israel Hayom)
- [95] חיסול מוחמד עודה, מפקד צבאי של חמאס (Israel National News)
- [92] שני חיילים נפצעו בלבנון, שני מחבלי חמאס חוסלו (Jerusalem Post)
- [87] קצין בלהב 433 נחשד בקשר עם סוכן איראני (Israel National News)

**איום איסלאמי באירופה (2):**
- [94] ארה"ב תקפה יעדים צבאיים במצר הורמוז (Israel National News)
- [93] טראמפ: "לא מרוצים מהשיחות עם איראן" (Israel National News)

**אנטישמיות מהשטח (2):**
- [91] ארה"ב הטילה סנקציות על פרנצ'סקה אלבנזה (Israel National News)
- [90] ADL: 583 מקרים אנטישמיים בקמפוסים ב-2025

**פוליטיקאים נגד אנטישמיות (1):**
- [89] הסכם הפסקת אש ארה"ב-איראן ממתין לאישור (Jerusalem Post)

**פרו-ישראל מקומי (5):**
- [88] עשרים בני ערובה בחיים, 33 מתים (Jerusalem Post)
- [86] סמל רותם ינאי נהרג בפעילות מבצעית בצפון (Israel National News)
- [85] חברי כנסת שחזרו "טבח" לחוק האנדרטה (Jerusalem Post)
- [84] שבעה חטופים ישראלים עדיין בידי חמאס (Israel National News)

### קבצים שנוצרו:
- JSON: twitter-grok-feed.json (15 פריטים)
- XML: twitter-grok-feed.xml (15 פריטים)

### בעיות מתמשכות:
- Grok API ללא קרדיטים כבר 8 ימים
- חסר XAI_API_KEY כמשתנה סביבה
- web_search provider (kimi) דורש API key

### המלצות:
1. **דחופה:** להגדיר XAI_API_KEY כמשתנה סביבה או לרכוש קרדיטים חדשים
2. להגדיר web_search provider חלופי (Brave/Perplexity)
3. לאמת xurl לגישה ל-Twitter API
4. לשקול NewsAPI או GNews כfallback נוסף
