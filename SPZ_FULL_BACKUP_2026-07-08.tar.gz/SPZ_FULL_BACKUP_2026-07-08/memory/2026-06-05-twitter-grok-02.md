# Twitter Grok Monitor Run - 2026-06-05 02:00 (2:00 AM Jerusalem)

## סטטוס: ✅ FALLBACK SUCCESS (Web Fetch - JPost)

### הבעיות המתמשכות:
1. **Grok API** - ללא API key (XAI_API_KEY ריק) - נמשך מ-21 במאי
2. **xurl** - לא מאומת ("No apps registered")
3. **Web search** - Provider "kimi" לא תומך ב-date/freshness filtering

### פתרון:
Web fetch fallback ישירות מ-JPost (4 מקורות):
- diaspora/antisemitism
- israel-news
- international
- middle-east

---

## תוצאות (25 פריטים):

### 🚨 אנטישמיות מהשטח (10 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [97] | NYC antisemitic hate crimes 70% higher in May 2026 than May 2025, 41 incidents confirmed | June 3 |
| [96] | 'No Jews in our hotel': Israeli family denied access to Bavarian hotel | June 3 |
| [95] | Man wearing Star of David necklace beaten in possible antisemitic gang attack in Germany | June 3 |
| [94] | Four more arrested for two drive-by gel pellet gun attacks on Toronto Jews | June 3 |
| [93] | Two visibly Jewish men find 'Free Palestine' message on London hotel room TV | June 4 |
| [92] | 'Jews are eating kids': Jewish woman choked, hair torn out in NYC subway attack | June 4 |
| [91] | NHS urged to ban pro-Palestinian badges amid antisemitism concerns | June 4 |
| [90] | NYU student charged with hate crime after flying swastika, Star of David flag over campus building | June 4 |
| [89] | SJP political program calls to 'usurp' universities to 'weaken the US' | June 4 |
| [88] | Zack Polanski signs letter calling for investigation, screening of IDF vets with UK citizenship | June 4 |

### 🇮🇱 חדשות ישראל/ביטחון (5 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [85] | Capt. Eitan Shmuel Lemberg killed in combat in southern Lebanon | June 4 |
| [84] | IDF, Shin Bet kill several Hamas General Security Apparatus officials in Gaza | June 4 |
| [77] | Gov't allocates over NIS 1 billion to prosecute October 7 terrorists in military tribunals | June 4 |
| [76] | Ex-top Mossad official: Barnea led agency to unprecedented operational reach | June 4 |
| [75] | Netanyahu appoints Guy Markizeno as military secretary after Mossad reshuffle | June 4 |

### 🌍 מזרח תיכון/בינלאומי (6 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [83] | Hezbollah rejects ceasefire after US announces ceasefire between Israel, Lebanon | June 4 |
| [82] | Trump says US will not return to war against Iran unless American troops are killed | June 4 |
| [81] | Hezbollah threatens to target Tel Aviv, Haifa, if Israel strikes again in Beirut | June 4 |
| [80] | Iran demands frozen assets be released in initial phase of deal with US, leading to stalemate | June 4 |
| [79] | US-Iran negotiations 'going well,' could reach deal by weekend, Trump claims | June 3 |
| [65] | Iran's Supreme Leader warns of Israeli, US divisions threatening regime | June 4 |

### 📰 אחר (4 פריטים):

| ציון | כותרת | תאריך |
|------|-------|-------|
| [78] | More than 300 cities across US officially recognize Jewish American Heritage Month in May | June 4 |
| [72] | Israel beats Albania in tense friendly after booing of Hatikvah | June 4 |
| [70] | Bamba blankets NYC after Park Slope Food Coop vote to boycott Israeli products | June 4 |
| [60] | UK-based Sky News Group ends venture with UAE's International Media Investments | June 4 |

---

## סיכום
- **25 פריטים** נאספו מ-4 מקורות JPost
- **10 פריטי אנטישמיות** (ציונים 88-97)
- **5 פריטי ביטחון** (ציונים 75-85)
- **6 פריטי מזרח תיכון** (ציונים 65-83)
- **XML נשמר** ב: `spz-feeds/twitter-grok-feed.xml`

## הבעיות המתמשכות
1. XAI_API_KEY ריק - Grok API לא זמין
2. xurl לא מאומת - אין אפשרות לחיפוש ישיר ב-X/Twitter
3. Web search provider (kimi) לא תומך ב-date filtering

## המלצות
- **מיידי:** רכוש API key חדש ל-Grok או מצא חלופה
- **ביניים:** הגדר xurl auth עם אפליקציית X
- **ארוך טווח:** שקול להחליף את provider ה-web search ל-Brave/Perplexity