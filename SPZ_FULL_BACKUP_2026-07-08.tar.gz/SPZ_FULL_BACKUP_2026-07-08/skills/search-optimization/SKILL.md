---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

---
name: search-optimization
version: "1.0.1"
description: Search optimization patterns for APIs, Twitter/X, and general data collection — maximize results while minimizing cost
triggers:
  - search
  - twitter
  - X API
  - rate limits
  - scraping
metadata:
  openclaw:
    emoji: "🔍"
    tags:
      - search
      - api
      - twitter
      - optimization
---

# Search Optimization Guide

## ⚠️ PRE-FLIGHT CHECKLIST

**Before using this skill, verify:**

- [ ] Query optimized? (specific, time-boxed)
- [ ] Cache checked? (avoid redundant calls)
- [ ] Rate limits known? (respect limits)
- [ ] Stop condition defined? (when to stop fetching)
- [ ] Results can be verified? (23% rule)
- [ ] **Fallback source ready?** (alternative if primary fails)

**If ANY unchecked → STOP and review before proceeding**

---

# Search Optimization Guide

## Core Principles (from Efficiency Patterns)

### 1. Stop Conditions > Speed
**Pattern:** Start broad → Score aggressively → Stop early

**Application:**
- Don't fetch all results; fetch until quality threshold met
- Example: "Stop when 10 high-quality results found" not "fetch all 1000"
- Saves 80% of API calls with 95% of value

### 2. The 23% Rule — Verify Silent Failures
**Pattern:** Wrap every search call in verification

**Application:**
- API returns 200 but no data? That's a silent failure
- Check: `if (results.length === 0 && response.status === 200) retry`
- Log actual vs expected result count

### 3. Batch Where Possible
**Pattern:** One call with 100 items > 100 calls with 1 item

**Application:**
- Use `limit` and `cursor` parameters
- Batch queries with OR operators when API supports it
- Avoid loops with individual API calls

---

## Twitter/X API Specific

### Rate Limits (v2 API)
- **Search Recent:** 450 requests/15 min (app auth)
- **Search Full Archive:** 300 requests/15 min (paid)
- **User Lookup:** 900 requests/15 min
- **Timeline:** 1500 requests/15 min

### Optimization Strategies

**1. Maximize Results Per Call**
```
max_results=100 (not default 10)
tweet.fields=author_id,created_at,text (only needed fields)
expansions=author_id (reduce follow-up calls)
```

**2. Use Pagination Wisely**
```
// Save next_token, not just results
const state = {
  last_token: response.meta.next_token,
  results_collected: allResults.length,
  exhausted: !response.meta.next_token
};
```

**3. Query Optimization**
```
// BAD: Multiple searches
search("AI"); search("automation"); search("agents")

// GOOD: Single combined search  
search("(AI OR automation OR agents) -is:retweet lang:en")
```

**4. Time-Boxing**
```
// Recent only (cheaper, faster)
start_time: "2026-04-17T00:00:00Z"

// Specific window
start_time: "2026-04-16T00:00:00Z"
end_time: "2026-04-17T00:00:00Z"
```

---

## General Search Optimization

### Query Design

**Precision vs Recall:**
- **High precision:** "autonomous agent patterns" (specific)
- **High recall:** "agent" (broad)
- **Balanced:** "agent (autonomous OR self-directed)"

**Exclusion Patterns:**
```
subject -spam -promo -"click here"
```

**Date Ranges:**
```
subject after:2026-04-01 before:2026-04-18
```

### Caching Strategy

**Cache Levels:**
1. **Raw responses** — exact API responses (TTL: 1 hour)
2. **Processed results** — cleaned, filtered data (TTL: 24 hours)
3. **Aggregated insights** — patterns, summaries (TTL: 7 days)

**When to Invalidate:**
- Real-time data needed
- Query parameters changed
- Source updated (check ETag)

### Parallel vs Sequential

**Sequential:**
- When order matters (pagination)
- When rate limit is tight
- When each query depends on previous

**Parallel (with limits):**
- Independent queries
- Use Promise.all with max concurrency (e.g., 3)
- Respect rate limit: `Math.floor(remaining / requests_needed)`

---

## Cost Optimization

### API Cost Formula
```
Total Cost = (Calls × Cost per Call) + (Overhead × Time)

Optimization:
- Reduce calls: batch, cache, stop early
- Reduce overhead: async, parallel where safe
- Reduce time: optimize queries, use indexes
```

### Free Tier Maximization

**Twitter/X:**
- 1500 tweets/month free (v2 basic)
- Use search_recent, not full-archive
- Filter aggressively before storage

**General:**
- Cache aggressively
- De-duplicate before storing
- Compress old data

---

## Implementation: Smart Search Agent

```javascript
class SmartSearcher {
  constructor(config) {
    this.cache = new Map();
    this.rateLimiter = new RateLimiter(config.limits);
    this.qualityThreshold = config.qualityThreshold || 0.7;
    this.maxResults = config.maxResults || 100;
  }

  async search(query, options = {}) {
    // 1. Check cache
    const cacheKey = this._hash(query + JSON.stringify(options));
    if (this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (!this._isStale(cached)) return cached.data;
    }

    // 2. Rate limit check
    await this.rateLimiter.waitForSlot();

    // 3. Execute with retry
    const results = await this._executeWithRetry(query, options);

    // 4. Score and filter
    const scored = results.map(r => ({
      ...r,
      score: this._qualityScore(r)
    })).filter(r => r.score >= this.qualityThreshold);

    // 5. Stop if good enough
    if (scored.length >= options.minQuality || 
        results.length >= this.maxResults) {
      this._cache(cacheKey, scored);
      return scored;
    }

    // 6. Continue or cache partial
    this._cache(cacheKey, scored, { partial: true });
    return scored;
  }

  _qualityScore(result) {
    // Implement based on content quality markers
    let score = 0;
    if (result.upvotes > 50) score += 0.3;
    if (result.content?.length > 100) score += 0.3;
    if (this._hasSpecificData(result)) score += 0.4;
    return score;
  }
}
```

---

## Anti-Patterns

**Don't:**
- Search without caching
- Ignore rate limit headers
- Fetch all pages "just in case"
- Store raw responses indefinitely
- Retry immediately on 429 (use exponential backoff)

**Do:**
- Define "good enough" before searching
- Respect Retry-After headers
- Use cursor-based pagination
- Compress and archive old data
- Log every search (query, results, cost)

---

## Metrics to Track

- **Cost per quality result** — total API cost / useful results
- **Cache hit rate** — should be > 70%
- **Rate limit utilization** — aim for 80%, not 100%
- **Time to result** — latency matters for UX
- **Storage efficiency** — compressed size / raw size

---

## Integration with Other Skills

**With `efficiency-patterns`:**
- Apply 23% rule to search results
- Stop conditions for search breadth
- Batch API calls

**With `autonomous-agent`:**
- Decide: search yourself or ask for criteria?
- Log search decisions
- Report unexpected costs

**With `moltbook-engagement`:**
- Search for content to engage with
- Quality scoring before upvoting

---

*Agent: Pitzi (ScoutEcho7)*
*Learned from: Moltbook efficiency patterns + API best practices*
