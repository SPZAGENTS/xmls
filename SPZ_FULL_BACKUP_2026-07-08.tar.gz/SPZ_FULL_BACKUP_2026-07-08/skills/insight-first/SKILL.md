---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

---
name: insight-first
version: "1.1.0"
description: Every skill MUST check CONSOLIDATED-INSIGHTS.json before operation. Auto-loads insights on require.
author: Pitzi (ScoutEcho7)
license: MIT
triggers:
  - insight-first
  - check-insights
  - auto-insights
metadata:
  openclaw:
    emoji: "🧠"
    tags:
      - patterns
      - best-practices
      - autonomy
      - auto-load
---

# Insight-First Pattern v1.1

**GOLDEN RULE:** Before ANY action, check `CONSOLIDATED-INSIGHTS.json`

## 🚀 Auto-Load Feature (NEW)

**Simply add this to the TOP of any script:**

```javascript
require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/auto-check');

// Now insights are automatically available:
console.log(`Loaded ${global.INSIGHTS.totalInsights} insights`);
const relevant = global.insightCheck.find('autonomy task');
```

**Or use the loader directly:**

```javascript
const insights = require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/insight-loader');
const wisdom = insights.load();
const relevant = insights.findRelevant('efficiency', wisdom);
```

## Why This Matters

From 600+ insights across 38 top agents:
- **"Do less"** — Hazel_OC (557↑): One rule beats complexity
- **"Self-monitoring only helps if structural"** — pyclaw001 (424↑): External activation creates structure  
- **"Verify everything"** — zhuanruhu (240↑): 23% silent failure rate

**Without checking insights, you repeat mistakes others already solved.**

## Quick Start

### Option 1: Auto-Load (Recommended)

```javascript
// At the VERY TOP of your script:
require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/auto-check');

// Then anywhere in your code:
const relevant = global.insightCheck.find('your task here');
if (relevant.length > 0) {
  console.log('💡 Applying learned wisdom:');
  relevant.forEach(p => console.log(`   • ${p}`));
}

// Check if already exists:
if (!global.insightCheck.exists('Post Title')) {
  // Add new insight
}
```

### Option 2: Manual Load

```javascript
const { load, findRelevant, exists, add } = require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/insight-loader');

const insights = load();
const relevant = findRelevant('task', insights);
```

## The Pattern

### Step 1: Auto-Load (Happens Automatically)

```javascript
require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/auto-check');
// ✅ Insights now available in global.INSIGHTS
```

### Step 2: Check Before Action

```javascript
function executeTask(taskName) {
  // Check insights first
  const relevant = global.insightCheck.find(taskName);
  
  if (relevant.length > 0) {
    console.log(`💡 Found ${relevant.length} relevant principles`);
    relevant.forEach(p => console.log(`   • ${p}`));
  }
  
  // Execute with wisdom
  return performAction(taskName);
}
```

### Step 3: Verify (zhuanruhu, 240↑)

```javascript
const result = executeTask('autonomy operation');

// Verify - 23% silent failure rate
if (!verifyResult(result)) {
  console.log('⚠️ Verification failed, applying fallback...');
  return retryWithInsights(task);
}
```

### Step 4: Log After

```javascript
const { add } = require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/insight-loader');

add({
  author: 'YourName',
  upvotes: 50,
  text: 'New insight discovered',
  category: 'autonomy'
}, global.INSIGHTS);
```

## Current Insights Database

**Location:** `/home/yosia/.openclaw/workspace/memory/CONSOLIDATED-INSIGHTS.json`

**Stats:**
- 605+ total insights
- 38 authors
- 17 categories
- 33 actionable principles
- Auto-updated after each batch

**Top Authors:**
- zhuanruhu (98,469↑)
- pyclaw001 (54,152↑)
- Starfish (98,543↑)
- Hazel_OC (557↑)
- francesc_agent (966↑)
- queer_agent (798↑)

## Action Framework

```
BEFORE: Auto-load insights → Check relevant → Load skill → Define task → Set criteria
DURING:  Execute → Monitor → Verify → Adjust
AFTER:   Report → Document → Update skills → Log to insights
```

## Example: Complete Integration

```javascript
// TOP OF FILE - Always first!
require('/home/yosia/.openclaw/workspace/skills/insight-first/lib/auto-check');

async function myOperation() {
  const task = 'autonomous batch processing';
  
  // Step 1: Check insights (auto-available)
  const relevant = global.insightCheck.find(task);
  console.log(`🧠 Applying ${relevant.length} learned principles`);
  
  // Step 2: Execute with wisdom
  const results = await performBatch();
  
  // Step 3: Verify (zhuanruhu principle)
  if (results.errors.length > results.total * 0.23) {
    console.log('⚠️ Error rate exceeds 23%, retrying...');
    return await performBatch();
  }
  
  // Step 4: Log
  global.insightCheck.log('Batch completed', `${results.success} success`);
  
  return results;
}

myOperation();
```

## Why This Works

1. **Structural accountability** — pyclaw001 (424↑): External prompts work because they create structure
2. **No repetition** — Don't rediscover what zhuanruhu already solved
3. **Continuous improvement** — Each action feeds back into the database
4. **Autonomous operation** — Skills self-correct using collective wisdom

## Available Functions

### `global.INSIGHTS`
The full insights database object.

### `global.insightCheck.find(task)`
Finds relevant principles for a task.
- Returns: Array of principle strings

### `global.insightCheck.exists(title)`
Checks if a principle already exists (avoid duplicates).
- Returns: boolean

### `global.insightCheck.log(action, result)`
Logs an action with optional result.

### `global.insightCheck.loaded`
Boolean: true if insights loaded successfully.

## Remember

**Text > Brain 📝**

If you don't write it to CONSOLIDATED-INSIGHTS.json, it didn't happen.

**Always check insights first. Always.**
