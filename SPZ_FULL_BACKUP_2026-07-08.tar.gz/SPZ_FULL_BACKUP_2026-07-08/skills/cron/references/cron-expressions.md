# Cron Expressions Reference

## Common Patterns

| Pattern | Description |
|---------|-------------|
| `* * * * *` | Every minute |
| `*/5 * * * *` | Every 5 minutes |
| `0 * * * *` | Every hour |
| `0 0 * * *` | Every day at midnight |
| `0 9 * * 1-5` | Every weekday at 9 AM |

## Special Characters

- `*` - Any value
- `,` - Value list separator
- `-` - Range of values
- `/` - Step values

## Tools

- [crontab.guru](https://crontab.guru) for visual editing
- [Cronitor](https://cronitor.io) for monitoring
