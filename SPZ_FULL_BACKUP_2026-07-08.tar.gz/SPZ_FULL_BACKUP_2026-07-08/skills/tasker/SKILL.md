---
name: tasker
description: Use when the user wants to manage automated recurring tasks or check on existing scheduled tasks. Use for creating, listing, editing, or deleting scheduled jobs that run periodically using cron syntax or natural language schedules. Triggers on phrases like "schedule a task", "set up a recurring task", "run this every", "check my scheduled tasks", "list my tasks", "manage tasks", or "tasker".
---

# Tasker Skill

Use the `tasker` command-line tool to create, manage, and inspect recurring tasks (cron jobs) through an intuitive CLI.

## Prerequisites

Ensure the `tasker` CLI is installed. The binary should be located in the skill scripts directory or on the system PATH.

## Commands

### List all scheduled tasks

```bash
tasker list
```

Shows all active tasks with their schedule, next run time, status, and command.

### Add a new scheduled task

```bash
tasker add --name "<task-name>" --schedule "<schedule>" --command "<command>"
```

**Schedule formats:**
- **Cron expression**: `"0 9 * * 1-5"` (weekdays at 9 AM)
- **Natural language**: `"every day at 9am"`, `"every 30 minutes"`, `"every monday at 8am"`
- **Interval**: `"*/5 * * * *"` (every 5 minutes)

**Examples:**
```bash
tasker add --name "morning-check" --schedule "0 8 * * *" --command "python check.py"
tasker add --name "heartbeat" --schedule "*/30 * * * *" --command "curl -s http://localhost:health"
tasker add --name "weekly-report" --schedule "every friday at 5pm" --command "python report.py"
```

### Remove a task

```bash
tasker remove <task-name>
```

Or by ID:
```bash
tasker remove --id <task-id>
```

### Get task details

```bash
tasker info <task-name>
```

Shows detailed information about a specific task including schedule, command, last run, next run, and run history.

### Edit a task

```bash
tasker edit <task-name> --schedule "<new-schedule>"
tasker edit <task-name> --command "<new-command>"
```

### Enable/disable a task

```bash
tasker disable <task-name>
tasker enable <task-name>
```

### Run a task immediately

```bash
tasker run <task-name>
```

Executes the task command right now, regardless of schedule.

### View task logs

```bash
tasker logs <task-name>
```

Shows recent execution logs for the task.

## Design Patterns

### Common scheduling patterns

| Pattern | Cron | Natural Language |
|---------|------|------------------|
| Every 30 min | `*/30 * * * *` | `"every 30 minutes"` |
| Hourly | `0 * * * *` | `"every hour"` |
| Daily 9 AM | `0 9 * * *` | `"every day at 9am"` |
| Weekdays 9 AM | `0 9 * * 1-5` | `"every weekday at 9am"` |
| Weekly Monday 8 AM | `0 8 * * 1` | `"every monday at 8am"` |
| Monthly 1st | `0 0 1 * *` | `"every month on the 1st"` |

### Task naming conventions

- Use lowercase with hyphens: `morning-check`, `weekly-report`
- Be descriptive: `backup-database` not `task1`
- Group related tasks with prefixes: `backup-db`, `backup-files`

### Best practices

- **Use absolute paths** in commands when possible
- **Test commands** before scheduling them with `tasker run <task-name>`
- **Check logs** after the first scheduled run to verify success
- **Disable rather than delete** tasks you might need again

## Scripts

The `scripts/tasker.sh` script provides the core CLI functionality. It uses `cron` under the hood with a simple JSON-based registry for metadata.
