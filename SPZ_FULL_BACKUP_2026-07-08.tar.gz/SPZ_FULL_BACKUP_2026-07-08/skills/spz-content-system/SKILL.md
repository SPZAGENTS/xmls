---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: spz-content-system
version: "1.0.0"
description: SPZ Content Aggregation System - RSS, Reddit, Twitter agents with GitHub XML output
triggers:
  - "spz"
  - "content aggregation"
  - "rss agent"
  - "reddit agent"
  - "twitter agent"
  - "xml files"
metadata:
  openclaw:
    emoji: "📰"
    tags: ["content", "rss", "reddit", "twitter", "github", "xml", "news"]
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "קרא גם: ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md (מידע מצטלב)"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
---

# SPZ Content Aggregation System

מערכת אוטומטית לאיסוף תוכן ממקורות חדשות ועדכון קבצי XML בגיטהאב.

## 🎯 מהות המערכת

מערכת SPZ מאגדת תוכן ממקורות מגוונים (RSS, Reddit, Twitter) ומעדכנת אוטומטית קבצי XML במאגר GitHub של SPZAGENTS/xmls.

## 📁 מבנה הקבצים

```
~/.openclaw/workspace/
├── spz_orchestrator.py          # מרכז ניהול - מריץ את כל הסוכנים
├── spz-rss-agent.py             # סוכן RSS - אוסף מ-28 מקורות
├── spz-reddit-agent.py          # סוכן Reddit - RSS feeds (ללא credentials)
├── spz-twitter-agent.py         # סוכן Twitter - Nitter (כרגע לא עובד)
├── spz_state.db                 # מסד נתונים SQLite למעקב
├── spz-feeds/
│   ├── rss_feed.json            # תוצאות RSS
│   ├── reddit_feed.json         # תוצאות Reddit
│   └── twitter_feed.json        # תוצאות Twitter
├── spz_github_files/            # קבצים שהורדו מגיטהאב
└── update_only_top_xml.py       # סקריפט עדכון TOP files
```

## 🚀 הרצת המערכת

### 1. הרצת כל הסוכנים (דרך ה-orchestrator)
```bash
cd ~/.openclaw/workspace
./spz_venv/bin/python spz_orchestrator.py
```

### 2. הרצת סוכן בודד
```bash
# RSS
./spz_venv/bin/python spz-rss-agent.py

# Reddit
./spz_venv/bin/python spz-reddit-agent.py

# Twitter
./spz_venv/bin/python spz-twitter-agent.py
```

### 3. עדכון קבצי XML בגיטהאב
```bash
python3 update_only_top_xml.py
```

## 📊 מקורות תוכן

### RSS (28 מקורות פעילים)

| קטגוריה | מקורות |
|---------|--------|
| **ישראלי** | Times of Israel, Jerusalem Post, Ynet, Israel Hayom, Srugim, Geektime |
| **BBC** | BBC World, BBC Middle East, BBC News, BBC UK |
| **בינלאומי** | Reuters, Guardian, NYT World, NYT Middle East, Washington Post, CNN, Fox News |
| **אמריקאי** | ABC News, NBC News, NPR, CBC |
| **אירופאי** | France24, Politico |

**תוצאות אחרונה:** 93 כתבות מ-28 מקורות (19/04/2026)

### Reddit (10 subreddits)
- r/Israel, r/Judaism, r/Jewish, r/Zionism
- r/WorldNews, r/MiddleEast, r/geopolitics
- r/news, r/IsraelPalestine, r/Military

**הערה:** Reddit מוגבל ל-25 פוסטים אחרונים לכל subreddit (RSS feeds)

### Twitter
**סטטוס:** לא פעיל - Nitter instances לא זמינים
**פתרון עתידי:** Twitter API v2 (דורש API key)

## 🔄 תהליך העדכון

1. **איסוף** - הסוכנים אוספים תוכן ממקורות
2. **דירוג** - חישוב importance score לכל כתבה
3. **סינון** - שמירת top 10 כתבות לכל מקור
4. **עדכון** - העלאת קבצי TOP לגיטהאב

## 📄 מבנה קבצי XML

```xml
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>Times of Israel - Top</title>
    <item>
      <title>כותרת הכתבה</title>
      <link>https://...</link>
      <description>תקציר...</description>
      <pubDate>2026-04-19</pubDate>
      <source>Times of Israel</source>
      <importance>95</importance>
    </item>
    <!-- עד 10 items -->
  </channel>
</rss>
```

## 🛠️ תחזוקה

### עדכון URLs שבורים
מקורות שצריכים תיקון:
- Haaretz, Maariv, Walla, Calcalist, Globes, Arutz Sheva
- Reuters (דרוש subscribe)

### הוספת מקור חדש
1. עדכן `RSS_SOURCES` ב-`spz-rss-agent.py`
2. הוסף את קובץ ה-TOP לגיטהאב (ריק)
3. הרץ `update_only_top_xml.py`

## 📈 סטטיסטיקות

- **51 סקילים** נוצרו/עודכנו
- **30 קבצי TOP** בגיטהאב
- **25 קבצים** עודכנו בהצלחה
- **93 כתבות** נאספו אחרונה

## 🔧 פתרון בעיות

### Reddit - 0 results
Reddit חוסם בקשות אוטומטיות. צריך להוסיף User-Agent או לעבור ל-API עם credentials.

### Twitter - לא עובד
Nitter מת. צריך Twitter API v2 (דורש bearer token).

### קבצים בעברית - שגיאת Unicode
5 קבצי TOP בעברית לא עודכנו:
- גיקטיים-top.xml
- היום-top.xml
- וואלה-top.xml
- זמן-ישראל-top.xml
- סרוגים-top.xml

**פתרון:** לתקן URL encoding ב-`update_only_top_xml.py`

## 📝 קבצים חשובים

| קובץ | תיאור |
|------|-------|
| `spz_orchestrator.py` | מרכז ניהול הסוכנים |
| `spz-rss-agent.py` | סוכן RSS עם 28 מקורות |
| `update_only_top_xml.py` | מעדכן קבצי TOP בגיטהאב |
| `run_with_limit.py` | wrapper להרצת סקריפטים |

## 🎯 משימות עתידיות

- [ ] תקן URLs שבורים (Haaretz, Maariv, etc.)
- [ ] תקן בעיית Unicode לקבצים בעברית
- [ ] הוסף Twitter API v2
- [ ] הוסף Reddit API (עם credentials)
- [ ] מחק קבצי batch ו-timestamp מיותרים
- [ ] הגדר cron job להרצה אוטומטית

---

*נוצר: 19 באפריל 2026*
*גרסה: 1.0.0*
