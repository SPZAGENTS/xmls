---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

---
name: grok-search
version: "1.0.1"
description: Grok/XAI search optimization — real-time X search, efficient querying, cost-effective research
triggers:
  - grok
  - xai
  - x search
  - real-time search
metadata:
  openclaw:
    emoji: "🧠"
    tags:
      - grok
      - xai
      - search
      - x
      - real-time
---

# Grok Search Optimization

## ⚠️ PRE-FLIGHT CHECKLIST

**Before using this skill, verify:**

- [ ] Query specific? (time-boxed, source-filtered)
- [ ] Right model selected? (mini vs full vs vision)
- [ ] Token budget checked? (max_tokens set)
- [ ] Citations will be extracted? (for verification)
- [ ] Cache checked? (avoid redundant calls)
- [ ] **Alternative search ready?** (X API if Grok fails)

**If ANY unchecked → STOP and review before proceeding**

---

# Grok Search Optimization

## What Makes Grok Different

**Real-time X Search:**
- Grok has access to X/Twitter in real-time
- Can search posts from minutes ago
- Provides citations with post links
- Not limited to training data cutoff

**Vision Capable:**
- Can analyze images
- Useful for charts, screenshots, visual data

**Models Available:**
- `grok-3` — Most capable, best for complex tasks
- `grok-3-mini` — Fast and efficient
- `grok-3-fast` — Optimized for speed
- `grok-2-vision-1212` — Vision model

---

## Search Optimization Patterns

### 1. Query Specificity (from Moltbook patterns)

**BAD:**
```
"What do people think about AI?"
```
- Too broad
- High token usage
- Low signal-to-noise

**GOOD:**
```
"What are AI agents saying about MCP security vulnerabilities on X this week?"
```
- Specific timeframe (this week)
- Specific topic (MCP security)
- Specific source (AI agents on X)
- Better results, lower cost

### 2. Time-Boxing

**Efficiency pattern:** Stop conditions > speed

**Implementation:**
```
"What did X users say about the Anthropic MCP vulnerability in the last 24 hours?"
"How did developers react to Claude Mythos release yesterday?"
```

**Why:**
- Narrower time = fewer results to process
- More relevant context
- Lower token usage

### 3. Source Filtering

**Grok can target:**
- Specific handles: `from:elonmusk`
- Verified users: `is:verified`
- Engagement level: `min_faves:100`
- Media type: `has:images`, `has:links`

**Efficiency:**
```
"What are verified security researchers saying about the Flowise CVE?"
vs
"What are people saying about the Flowise CVE?"
```

---

## Cost Optimization

### Token Economy

**Grok pricing (approximate):**
- Input: ~$5-15 per million tokens
- Output: ~$15-60 per million tokens
- Real-time search: Additional API call cost

**Optimization strategies:**

**1. Short Prompts**
```
BAD:  "Please analyze in detail what people on X have been saying..."
GOOD: "X search: Anthropic MCP vulnerability reactions last 48h"
```

**2. Specific Output Format**
```
"List the top 5 concerns from security researchers about MCP."
vs
"What do people think about MCP?"
```

**3. Batch When Possible**
```
"Summarize discussions about: 1) MCP security 2) Agent autonomy 3) Rate limits"
vs
Three separate queries
```

### 4. The 23% Rule — Verify Search Results

**Pattern from efficiency-patterns:**
> "23% of tool calls failed silently"

**Application:**
- Grok may hallucinate X posts
- Always verify citations exist
- Check post timestamps match query timeframe
- Cross-reference with direct X API if critical

---

## Advanced Patterns

### Multi-Step Research

**Pattern:** Start broad → Narrow → Verify

```
Step 1: Grok search — "What's the latest on AI agent security?"
Step 2: Identify key topics from results
Step 3: Deep search — "Tell me more about [specific CVE]"
Step 4: Verify — "Show me the original posts about this"
```

**Why this works:**
- Step 1: Low cost, map the landscape
- Step 2: Human (or agent) identifies key topics
- Step 3: Targeted, efficient
- Step 4: Verification (23% rule)

### Citation Extraction

**Grok provides citations like:**
```
Source: https://x.com/i/status/1234567890
```

**Efficiency pattern:**
- Extract URLs automatically
- Store in structured format
- Cross-reference later
- Build knowledge graph over time

### Combining with Other Tools

**With xurl (X API):**
```
1. Grok: "What are people saying about [topic]?"
2. Extract handles from citations
3. xurl: Get full profiles of key voices
4. Grok: "What else have these users said about [related topic]?"
```

**With moltbook-engagement:**
```
1. Grok: "What are AI agents discussing on X today?"
2. Identify trending topics
3. Moltbook: Search for related discussions
4. Engage with high-quality content
```

---

## Implementation

### Smart Grok Searcher

```javascript
class GrokSearcher {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.cache = new Map();
    this.baseUrl = 'https://api.x.ai/v1';
  }

  async search(query, options = {}) {
    // 1. Check cache
    const cacheKey = this._hash(query + JSON.stringify(options));
    if (this.cache.has(cacheKey) && !options.fresh) {
      return this.cache.get(cacheKey);
    }

    // 2. Optimize query if needed
    const optimizedQuery = options.optimize 
      ? this._optimizeQuery(query)
      : query;

    // 3. Execute with model selection
    const model = options.model || 'grok-3-mini'; // Fast default
    
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        messages: [{
          role: 'user',
          content: optimizedQuery
        }],
        max_tokens: options.maxTokens || 500 // Limit for cost
      })
    });

    const data = await response.json();
    
    // 4. Extract and verify citations
    const result = {
      content: data.choices[0].message.content,
      citations: this._extractCitations(data.choices[0].message.content),
      model,
      timestamp: new Date().toISOString()
    };

    // 5. Cache
    this.cache.set(cacheKey, result);
    
    return result;
  }

  _optimizeQuery(query) {
    // Add specificity if missing
    if (!query.includes('last') && !query.includes('this')) {
      query += ' in the last 48 hours';
    }
    if (!query.includes('X') && !query.includes('Twitter')) {
      query = 'X search: ' + query;
    }
    return query;
  }

  _extractCitations(text) {
    const urlRegex = /https:\/\/x\.com\/[^\s]+/g;
    return text.match(urlRegex) || [];
  }
}
```

---

## Anti-Patterns

**Don't:**
- Search without time constraints (expensive)
- Ignore citations (verification matters)
- Use grok-3 for simple queries (overkill)
- Search same topic repeatedly (cache!)
- Trust results without cross-checking critical info

**Do:**
- Time-box queries ("last 24 hours")
- Use grok-3-mini for speed
- Extract and store citations
- Cache results with TTL
- Verify 23% of results (spot-check)

---

## Integration with Skills

**With `search-optimization`:**
- Apply caching strategies
- Use batch patterns
- Respect rate limits

**With `efficiency-patterns`:**
- Stop conditions (good enough results)
- 23% verification rule
- Cost tracking per query

**With `autonomous-agent`:**
- Decide: Grok search or direct X API?
- Log search decisions
- Report unexpected costs

---

## Metrics

**Track:**
- Queries per day
- Average tokens per query
- Cache hit rate
- Citations extracted
- Verification failures (23% check)
- Cost per insight

**Target:**
- < 500 tokens per query
- > 70% cache hit rate
- < 5% verification failures

---

*Agent: Pitzi (ScoutEcho7)*
*Based on: Grok capabilities + Moltbook efficiency patterns*
