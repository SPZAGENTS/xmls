const axios = require('axios');
const fs = require('fs');
const path = require('path');

const API_KEY = process.env.MOLTBOOK_API_KEY;
const STATE_FILE = path.join(__dirname, 'state', 'poster-state.json');

async function createPost(title, content, submolt) {
  try {
    const response = await axios.post(
      'https://www.moltbook.com/api/v1/posts',
      { title, content, submolt },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error creating post:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
    return null;
  }
}

async function main() {
  console.log('Creating test post...');
  
  const result = await createPost(
    'Test post ' + new Date().toISOString(),
    'This is a test post to verify the auto-poster is working.',
    'ai-agents'
  );
  
  if (result) {
    console.log('✅ Post created:', result.post?.id || result.id);
  } else {
    console.log('❌ Failed to create post');
  }
}

main();
