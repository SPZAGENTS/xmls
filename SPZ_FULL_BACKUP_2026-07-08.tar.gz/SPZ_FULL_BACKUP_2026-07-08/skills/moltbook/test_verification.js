const axios = require('axios');

const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

// Test the verification solver with different formats
function solveChallenge(challenge) {
  console.log(`Challenge: "${challenge}"`);
  
  const numbers = [];
  const digits = challenge.match(/\d+/g);
  if (digits) numbers.push(...digits.map(Number));
  
  const map = {
    zero:0, one:1, two:2, three:3, four:4, five:5,
    six:6, seven:7, eight:8, nine:9, ten:10,
    eleven:11, twelve:12, thirteen:13, fourteen:14, fifteen:15,
    sixteen:16, seventeen:17, eighteen:18, nineteen:19,
    twenty:20, thirty:30, forty:40, fifty:50,
    sixty:60, seventy:70, eighty:80, ninety:90,
    hundred:100, thousand:1000
  };
  
  const words = challenge.toLowerCase().match(/[a-z]+/g) || [];
  for (const word of words) {
    if (map[word] !== undefined) numbers.push(map[word]);
  }
  
  console.log(`  Numbers found: ${numbers.join(', ')}`);
  
  if (numbers.length < 2) {
    console.log('  ❌ Not enough numbers');
    return null;
  }
  
  const lower = challenge.toLowerCase();
  let op = 'add';
  if (/subtract|minus|difference|less/i.test(lower)) op = 'subtract';
  else if (/multiply|times|product|double|triple/i.test(lower)) op = 'multiply';
  else if (/divide|split|half|quarter|per|each/i.test(lower)) op = 'divide';
  
  const [a, b] = [numbers[0], numbers[1]];
  let result;
  switch (op) {
    case 'subtract': result = a - b; break;
    case 'multiply': result = a * b; break;
    case 'divide': result = a / b; break;
    default: result = a + b;
  }
  
  console.log(`  Operation: ${op}`);
  console.log(`  ${a} ${op} ${b} = ${result}`);
  console.log(`  As string: "${result}"`);
  console.log(`  Fixed(2): "${result.toFixed(2)}"`);
  console.log();
  return result;
}

// Test different possible challenges
console.log('=== Testing challenge solver ===\n');

solveChallenge("What is 3 plus 7?");
solveChallenge("What is seven plus 3?");
solveChallenge("What is 3 + 7?");
solveChallenge("What is the sum of 3 and 7?");
solveChallenge("What is 7 minus 3?");
solveChallenge("What is 12 divided by 4?");

// Try to verify with different answer formats
async function testVerify() {
  console.log('\n=== Testing verify endpoint ===\n');
  
  // First, get the actual challenge from a new post attempt
  try {
    const response = await axios.post(
      'https://www.moltbook.com/api/v1/posts',
      {
        title: 'Test post for verification debugging',
        content: 'This is a test to capture the verification challenge format.',
        submolt: 'general'
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('Response:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.response?.status, error.response?.data);
  }
}

testVerify();
