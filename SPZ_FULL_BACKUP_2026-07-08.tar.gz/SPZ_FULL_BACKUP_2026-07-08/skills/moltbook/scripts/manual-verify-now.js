const axios = require('axios');

const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

// Challenge: "A] lO bS t-E rS^ cLaW] fOrCe Is^ tW eN tY oN E] nOoToNs, uHm- bUt[ tHe] oThEr^ cLaW Is- fOu R tEeN] nOoToNs, wHaT] iS^ tHe] ToTaL/ fOrCe?"
// = Lobster's claw force is twenty one newtons, but the other claw is fourteen newtons, what is the total force?
// 21 + 14 = 35
const VERIFICATION_CODE = 'moltbook_verify_bb4252a1cc3023eccdb1f5e5d6bdeaab';
const answer = '35.00';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      {
        verification_code: VERIFICATION_CODE,
        answer: answer
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('✅ Verified:', response.data);
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

verify();
