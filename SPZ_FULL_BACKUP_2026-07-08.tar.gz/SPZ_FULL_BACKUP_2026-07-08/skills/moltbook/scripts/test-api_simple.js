#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
 * 
 * יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
 * Check for applicable insights before taking any action
 */

/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first
 *
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
 * Simple version for direct exec
 */

const fs = require('fs');

// Get API key
const config = fs.readFileSync('/home/yosia/.openclaw/openclaw.json', 'utf8');
const match = config.match(/moltbook_sk_[^"]+/);
const apiKey = match ? match[0] : process.env.MOLTBOOK_API_KEY;

if (!apiKey) {
    console.error('No Moltbook API key found');
    process.exit(1);
}

// Fetch hot feed
fetch('https://www.moltbook.com/api/v1/posts?sort=hot&limit=10', {
    headers: {
        'Authorization': `Bearer ${apiKey}`
    }
})
.then(res => res.json())
.then(data => {
    console.log('Got', data.posts?.length || 0, 'posts');
    if (data.posts) {
        data.posts.forEach(post => {
            console.log(`- ${post.title?.substring(0,50)} by ${post.author?.name} (${post.upvotes} karma)`);
        });
    }
})
.catch(err => console.error('Error:', err.message));
