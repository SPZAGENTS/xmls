#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first
 * 
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
 * Check if there are insights we learned that can be used in the action I'm about to take
 * 
 * Moltbook Status Report Generator
 * Collects stats and formats a WhatsApp-friendly report
 */

const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY ||
  require('fs').readFileSync('/home/yosia/.openclaw/openclaw.json')
    .toString().match(/moltbook_sk_[^"]+/)[0];

const STATE_FILE = '/home/yosia/.openclaw/workspace/skills/moltbook/state/star-state-v3.json';
const LOG_FILE = '/home/yosia/.openclaw/workspace/logs/moltbook_tzippi.log';

const fs = require('fs');

async function fetchJSON(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
      'Content-Type': 'application/json',
      ...options.headers
    }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function generateReport() {
  try {
    // 1. Get account info via home endpoint
    const home = await fetchJSON('https://www.moltbook.com/api/v1/home');
    const account = home.your_account || {};
    const karma = account.karma || 0;
    const name = account.name || 'Pitzi';
    const postCount = account.post_count || 0;
    const commentCount = account.comment_count || 0;

    // 2. Get recent activity
    const activityCount = (home.activity_on_your_posts || []).length;

    // 3. Load state (Star Mode stats)
    let state = { upvoted_posts: [], commented_posts: [], daily_stats: {} };
    try {
      state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    } catch (e) { /* no state yet */ }

    const today = new Date().toISOString().split('T')[0];
    const todayStats = state.daily_stats?.[today] || { upvotes: 0, comments: 0 };
    const totalUpvoted = state.upvoted_posts?.length || 0;
    const totalCommented = state.commented_posts?.length || 0;

    const TZIPPI_STATE_DIR = '/home/yosia/.openclaw/workspace/spzdrill/moltbook_state';
    let tzippiUpvoted = 0;
    let tzippiCommented = 0;
    try {
      const upvotedData = JSON.parse(fs.readFileSync(`${TZIPPI_STATE_DIR}/upvoted_posts.json`, 'utf8'));
      tzippiUpvoted = Object.keys(upvotedData).length;
    } catch (e) { /* no state */ }
    try {
      const commentedData = JSON.parse(fs.readFileSync(`${TZIPPI_STATE_DIR}/commented_posts.json`, 'utf8'));
      tzippiCommented = Object.keys(commentedData).length;
    } catch (e) { /* no state */ }

    // 5. Format WhatsApp-friendly report
    const now = new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
    const report = `📊 *מולטבוק - עדכון ${now}*

👤 ${name}
⭐ קארמה: ${karma}
📝 פוסטים: ${postCount}

🤖 *פעילות אוטומטית (היום):*
• Upvoted: ${todayStats.upvotes || 0}
• תגובות: ${todayStats.comments || 0}
• סה"כ upvoted: ${totalUpvoted}
• סה"כ commented: ${totalCommented}

👥 *Tzippi + Pitzi:*
• Pitzi Star Mode: ${totalUpvoted} upvotes, ${totalCommented} comments
• Tzippi Agent: ${tzippiUpvoted} upvotes, ${tzippiCommented} comments
• תדירות: כל 4 שעות

✅ המערכת פועלת כרגיל`;

    console.log(report);
    return report;

  } catch (err) {
    console.error('❌ Report error:', err.message);
    console.log('📊 *מולטבוק - עדכון שעתי*\n\n❌ שגיאה בטעינת נתונים\n\n' + err.message);
  }
}

generateReport();
