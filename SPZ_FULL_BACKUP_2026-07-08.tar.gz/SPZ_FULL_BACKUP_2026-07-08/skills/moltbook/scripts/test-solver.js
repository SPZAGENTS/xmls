/**
 * Moltbook Verification Solver - v7
 * - Handle split words (e.g. "tw" + "ennty" = "twenty")
 * - Prioritize numbers followed by physics units
 * - Filter out descriptive numbers (e.g. "one claw")
 */

const canonicalNumbers = {
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
  'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
  'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
  'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
  'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
  'hundred': 100, 'thousand': 1000, 'million': 1000000
};

// Words that indicate a number is a physics value
const physicsUnits = new Set([
  'newtons', 'newton', 'meters', 'meter', 'seconds', 'second',
  'velocity', 'speed', 'force'
]);

// Physics/science words to skip as false positives
const physicsWords = new Set([
  'force', 'forces', 'newtons', 'newton', 'meters', 'meter', 'seconds', 'second',
  'velocity', 'speed', 'mass', 'energy', 'momentum', 'distance', 'time',
  'acceleration', 'gravity', 'weight', 'pressure', 'temperature'
]);

function levenshtein(a, b) {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      matrix[i][j] = b[i-1] === a[j-1]
        ? matrix[i-1][j-1]
        : Math.min(matrix[i-1][j-1] + 1, matrix[i][j-1] + 1, matrix[i-1][j] + 1);
    }
  }
  return matrix[b.length][a.length];
}

function tryMatchWord(clean) {
  if (clean.length < 3) return null;
  
  // Direct match
  if (canonicalNumbers[clean] !== undefined) {
    return { word: clean, value: canonicalNumbers[clean], exact: true };
  }
  
  // Fuzzy match
  let bestScore = Infinity;
  let bestMatch = null;
  let bestValue = null;
  
  for (const [numWord, numValue] of Object.entries(canonicalNumbers)) {
    if (clean.length < 4 && clean !== numWord) continue;
    
    const lenDiff = Math.abs(clean.length - numWord.length);
    if (lenDiff > 3) continue;
    
    const dist = levenshtein(clean, numWord);
    const threshold = clean.length >= 6 ? 2 : 1;
    
    if (dist <= threshold && dist < bestScore) {
      bestScore = dist;
      bestMatch = numWord;
      bestValue = numValue;
    }
  }
  
  if (bestMatch) {
    return { word: bestMatch, value: bestValue, exact: false };
  }
  
  return null;
}

function solveChallenge(challengeText) {
  const lower = challengeText.toLowerCase();
  
  // Extract words - split by non-letter, keep words with at least 2 chars
  let rawWords = lower.split(/[^a-z]+/).filter(w => w.length >= 2);
  
  console.log('Raw words:', rawWords);
  
  // Try to fix split words by merging short adjacent words
  const fixedWords = [];
  let i = 0;
  while (i < rawWords.length) {
    const word = rawWords[i];
    
    // If current word is short, try merging with next
    if (word.length <= 3 && i + 1 < rawWords.length) {
      const combined = word + rawWords[i + 1];
      const match = tryMatchWord(combined);
      if (match) {
        fixedWords.push(combined);
        i += 2;
        continue;
      }
      
      // Also try with next+next
      if (i + 2 < rawWords.length) {
        const combined2 = word + rawWords[i + 1] + rawWords[i + 2];
        const match2 = tryMatchWord(combined2);
        if (match2) {
          fixedWords.push(combined2);
          i += 3;
          continue;
        }
      }
    }
    
    fixedWords.push(word);
    i++;
  }
  
  console.log('Fixed words:', fixedWords);
  
  // Now find number matches and track if they're followed by units
  const numberMatches = [];
  for (let idx = 0; idx < fixedWords.length; idx++) {
    const word = fixedWords[idx];
    const clean = word.replace(/[^a-z]/g, '');
    
    // Skip physics words
    if (physicsWords.has(clean)) continue;
    
    const match = tryMatchWord(clean);
    if (match) {
      // Check if next word is a physics unit
      const nextWord = fixedWords[idx + 1];
      const hasUnit = nextWord && physicsUnits.has(nextWord.replace(/[^a-z]/g, '').toLowerCase());
      
      numberMatches.push({ ...match, original: word, hasUnit, index: idx });
    }
  }
  
  console.log('Number matches:', numberMatches.map(m => 
    `${m.original}->${m.word}=${m.value}${m.hasUnit ? '(unit)' : ''}`));
  
  // Build compound numbers
  const compounds = [];
  const compoundInfo = []; // track if any component had a unit
  i = 0;
  while (i < numberMatches.length) {
    const current = numberMatches[i];
    let value = current.value;
    let hadUnit = current.hasUnit;
    let j = i + 1;
    
    // Merge tens + ones: twenty + five = 25
    if (value >= 20 && value < 100 && value % 10 === 0) {
      while (j < numberMatches.length) {
        const next = numberMatches[j];
        if (next.value > 0 && next.value < 10) {
          value += next.value;
          hadUnit = hadUnit || next.hasUnit;
          j++;
        } else {
          break;
        }
      }
    }
    // hundred + something
    else if (value === 100) {
      let subValue = 0;
      let k = j;
      while (k < numberMatches.length && numberMatches[k].value < 100) {
        subValue += numberMatches[k].value;
        hadUnit = hadUnit || numberMatches[k].hasUnit;
        k++;
      }
      if (subValue > 0) {
        value += subValue;
        j = k;
      }
    }
    
    compounds.push(value);
    compoundInfo.push(hadUnit);
    i = j;
  }
  
  console.log('Compounds:', compounds, 'Has units:', compoundInfo);
  
  if (compounds.length < 2) {
    console.log('Not enough numbers found');
    return null;
  }
  
  // Determine operation
  let op = 'add';
  
  if (/\b(product|multiply|multiplied|multiplies|times|double|doubled|triple|tripled)\b/.test(lower)) {
    op = 'multiply';
  }
  else if (/\b(divided\s+by|split\s+among|shared\s+among|each\s+gets|half\s+of|quarter\s+of)\b/.test(lower)) {
    op = 'divide';
  }
  else if (/\b(loses|lost|remaining|remain|remains|subtract|minus|difference|decrease|drops|falls|reduces|less|take\s+away)\b/.test(lower)) {
    op = 'subtract';
  }
  else if (/\b(adds?|adding|total|sum|altogether|combined|plus|gains?|increases?)\b/.test(lower)) {
    op = 'add';
  }
  
  // If subtraction and we have "remains" or similar, might need to reverse order
  // e.g. "twenty three minus seven remains" = 23 - 7, not 7 - 23
  const [a, b] = [compounds[0], compounds[1]];
  let result;
  
  switch (op) {
    case 'subtract': result = a - b; break;
    case 'multiply': result = a * b; break;
    case 'divide': result = a / b; break;
    default: result = a + b;
  }
  
  console.log(`🧮 ${a} ${op} ${b} = ${result}`);
  
  const answer = Number.isInteger(result) ? result.toFixed(2) : String(result);
  return answer;
}

// Test with the 3 failed challenges
const challenges = [
  {
    text: "A] LoOb-.StEr ] ClAw FoR^Ce Is ThIrTy FiVe NeW>TOnS + AnD An OtHeR WaVe AdDs FoUrTeEn NeW\\ToNs, WhAtS ToTaL FoR}cE?",
    expected: "49.00"
  },
  {
    text: "A] lOoObSsTtErr S^wImS um] aT tW/eNnTy ThReEe -] sEeVeN mEtErS| pEr S^eCoNd, hOw- mUcH vElAwCiTeE rEmAiNs? umm errr",
    expected: "16.00"
  },
  {
    text: "Lo] b.StEr] ExErTs^ ThIrTy FiVe NoOtOnS~ WiTh^ OnE ClAw| AnD OtHeR AdDs< TwEnTy TwO, HoW MuCh ToTaL FoRcE? Umm lxq looobsss ter th i. sss",
    expected: "57.00"
  }
];

for (const challenge of challenges) {
  console.log('\n=== Challenge ===');
  console.log('Text:', challenge.text);
  const result = solveChallenge(challenge.text);
  console.log('Got:', result, '| Expected:', challenge.expected, '| Match:', result === challenge.expected);
}
