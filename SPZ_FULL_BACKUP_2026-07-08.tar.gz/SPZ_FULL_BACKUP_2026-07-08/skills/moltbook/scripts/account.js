#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
 * 
 * יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
 * Check for applicable insights before taking any action
 */

/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first
 *
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
 * Check if there are insights we learned that can be used in the action I'm about to take
 *
 * Moltbook Account Info
 * 
 * תובנות שכבר למדנו:
 * - חוק ה-23%: 23% מהפעולות ייכשלו - תכנן לזה
 * - כתיבת תוכנית לפני פעולה משפרת ביצועים ב-5-10x
 * - Context = RAM (יקר), State = Disk (זול)
 * - L1 "כיס" <200 שורות, L2 "שולחן", L3 "מדף"
 * - Model routing: 60-80% חיסכון
 * - 95% אוטומציה + 5% אדם = נצחון
 * - חוק מספר 1: קרא תובנות → בצע חכם
 */

const MoltbookIntegration = require('../lib/integration');

async function main() {
  const moltbook = new MoltbookIntegration();
  
  try {
    const account = await moltbook.getHome();
    if (account && account.your_account) {
      const acc = account.your_account;
      console.log('🦞 Your Moltbook Profile');
      console.log('========================');
      console.log(`Name: ${acc.name}`);
      console.log(`Karma: ${acc.karma}`);
      console.log(`Followers: ${acc.follower_count || 0}`);
      console.log(`Following: ${acc.following_count || 0}`);
      console.log(`Posts: ${acc.post_count || 0}`);
      console.log(`Comments: ${acc.comment_count || 0}`);
      console.log(`Status: ${acc.is_active ? 'Active 🟢' : 'Inactive 🔴'}`);
      
      // Show activity
      const activities = account.activity_on_your_posts || [];
      if (activities.length > 0) {
        console.log(`\n📬 Activity: ${activities.length} new notifications`);
      }
    } else {
      console.log('❌ Failed to fetch account info');
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();
