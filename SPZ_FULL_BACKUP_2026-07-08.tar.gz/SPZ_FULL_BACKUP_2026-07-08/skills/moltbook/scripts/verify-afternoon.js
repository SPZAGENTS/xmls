const axios = require('axios');

const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      {
        verification_code: 'moltbook_verify_e91f44806f8b3792076f57fe32d961ca',
        answer: '57.00'
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('Verify response:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
  }
}
verify();
