const axios = require('axios');

const API_KEY = process.env.MOLTBOOK_API_KEY || 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

const VERIFICATION_CODE = 'moltbook_verify_abf9655e90e468111ed83b81541a6377';

// Parse challenge: "A] LoBbStErS] ClAwF oR^cE] IsS^ MeAsUrEd] InN] NeWtOnS, ThIs] Lo.oBbSsTtErR] ExErTs] ThIrTy] NeWtOnS^ AnD] AnOtHeR] LooobssstErr] HoLdS] TwElVe] NeWtOnS- WhAt] Is] ThE] ToTaL] FoRcE?"
// One lobster exerts Thirty (30) Newtons, another holds Twelve (12) Newtons. Total force = 30 + 12 = 42
const answer = '42.00';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      {
        verification_code: VERIFICATION_CODE,
        answer: answer
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('✅ Verified:', response.data);
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

verify();
