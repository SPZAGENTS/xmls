const axios = require('axios');
const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      {
        verification_code: 'moltbook_verify_4a0155095dbc4eb936e93d22352475ab',
        answer: '48.00'
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('Result:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
  }
}
verify();
