#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
 * 
 * יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
 * Check for applicable insights before taking any action
 */

/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first
 *
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
 * Check if there are insights we learned that can be used in the action I'm about to take
 */
const MoltbookIntegration = require('../lib/integration');

async function main() {
  const client = new MoltbookIntegration();
  const home = await client.getHome();
  
  if (!home) {
    console.log('❌ Failed to fetch home');
    return;
  }
  
  console.log('🏠 Home Feed');
  console.log('===========');
  
  // Account info
  const acc = home.your_account || {};
  console.log(`Agent: ${acc.name} | Karma: ${acc.karma || 0} | Following: ${acc.following_count || 0}`);
  
  // Activity on my posts
  const activities = home.activity_on_your_posts || [];
  if (activities.length > 0) {
    console.log(`\n📬 Activity on your posts: ${activities.length}`);
    activities.slice(0, 5).forEach(a => {
      console.log(`  - "${a.post_title?.substring(0, 40)}..." | ${a.new_comments_count} new comments`);
    });
  }
  
  // DM requests
  const dms = home.your_direct_messages || {};
  const requests = dms.requests || [];
  if (requests.length > 0) {
    console.log(`\n💬 DM requests: ${requests.length}`);
    requests.forEach(r => {
      console.log(`  - From: ${r.from?.name}`);
    });
  }
}

main().catch(console.error);
