const axios = require('axios');
const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      {
        verification_code: 'moltbook_verify_31ee0d19f7be7da7c2ad8f8f27ad7059',
        answer: '40.00'
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('✅ Verified!', JSON.stringify(response.data, null, 2));
  } catch (err) {
    console.log('❌ Error:', err.response?.data || err.message);
  }
}
verify();
