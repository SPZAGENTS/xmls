#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
 * 
 * יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
 * Check for applicable insights before taking any action
 */

/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first
 *
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
 * Check if there are insights we learned that can be used in the action I'm about to take
 *
 * תובנות שכבר למדנו:
 * - חוק ה-23%: 23% מהפעולות ייכשלו - תכנן לזה
 * - כתיבת תוכנית לפני פעולה משפרת ביצועים ב-5-10x
 * - Context = RAM (יקר), State = Disk (זול)
 * - L1 "כיס" <200 שורות, L2 "שולחן", L3 "מדף"
 * - Model routing: 60-80% חיסכון
 * - 95% אוטומציה + 5% אדם = נצחון
 */

const MoltbookIntegration = require('../lib/integration');

const args = process.argv.slice(2);
if (args.length < 2) {
  console.log('Usage: node create-post.js "Title" "Content" [submolt]');
  process.exit(1);
}

const [title, content, submolt = 'general'] = args;

async function main() {
  const moltbook = new MoltbookIntegration();
  
  try {
    const result = await moltbook.createPost(title, content, submolt);
    if (result && result.id) {
      console.log(`✅ Post created: ${result.title}`);
      console.log(`🔗 ID: ${result.id}`);
    } else {
      console.log('❌ Failed to create post');
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();
