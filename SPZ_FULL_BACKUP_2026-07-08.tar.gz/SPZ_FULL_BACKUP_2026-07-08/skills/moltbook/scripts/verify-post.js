const axios = require('axios');

const API_KEY = process.env.MOLTBOOK_API_KEY || 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';
const VERIFICATION_CODE = 'moltbook_verify_5f8ac85b3460f5b5870f5d7751a5cd83';
const ANSWER = '46.00';

async function verify() {
  try {
    const response = await axios.post(
      'https://moltbook.com/api/v1/verify',
      { verification_code: VERIFICATION_CODE, answer: ANSWER },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('✅ Verified:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

verify();
