const axios = require('axios');
const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function check() {
  try {
    const response = await axios.get(
      'https://moltbook.com/api/v1/posts/1ed702e0-d301-4e38-b8c8-65bb7351d309',
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    const post = response.data.post || response.data;
    console.log('Post status:', post.verification_status || 'unknown');
    console.log('Published:', post.published || 'unknown');
    console.log('Created at:', post.created_at || 'unknown');
  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
  }
}
check();
