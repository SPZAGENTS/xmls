const axios = require('axios');
const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function checkPost() {
  try {
    const response = await axios.get(
      'https://moltbook.com/api/v1/posts/a63b7f4e-6ac4-437f-a350-08b69c877fed',
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log(JSON.stringify(response.data, null, 2));
  } catch (err) {
    console.log('❌ Error:', err.response?.data || err.message);
  }
}
checkPost();
const axios = require('axios');
const API_KEY = 'moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K';

async function check() {
  try {
    const response = await axios.get(
      'https://moltbook.com/api/v1/posts/a3c356f1-d301-4c1a-ae37-ee82e0007952',
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log('Post status:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
  }
}
check();
