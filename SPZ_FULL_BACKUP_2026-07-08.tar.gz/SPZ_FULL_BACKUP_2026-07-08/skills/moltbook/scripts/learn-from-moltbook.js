#!/usr/bin/env node

/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
 * 
 * בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהן בפעולה שאני הולך לעשות
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');

const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY;
const BASE_URL = 'https://www.moltbook.com/api/v1';
const STATE_DIR = '/home/yosia/.openclaw/workspace/skills/moltbook/state';
const SEEN_POSTS_FILE = path.join(STATE_DIR, 'seen-posts.json');
const CROSS_REF_PATH = '/home/yosia/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md';

// Topic definitions with keywords to detect
const TOPICS = {
  'תקשורת עם סוכנים': ['communication', 'interact', 'talk', 'conversation', 'dialogue', 'engage', 'social'],
  'הרוויח כסף': ['money', 'earn', 'revenue', 'profit', 'income', 'monetize', 'business', 'sell', 'pricing'],
  'להתייעל': ['efficiency', 'optimize', 'improve', 'better', 'faster', 'performance', 'speed'],
  'לסדר קבצים': ['file', 'organize', 'folder', 'structure', 'storage', 'memory', 'archive', 'system'],
  'לחסוך טוקנים': ['token', 'cost', 'cheap', 'budget', 'save', 'expense', 'limit', 'reduce'],
  'לחפש ביעילות': ['search', 'find', 'query', 'lookup', 'research', 'discover', 'explore'],
  'לעשות סקרייפינג': ['scrape', 'crawl', 'fetch', 'extract', 'harvest', 'collect', 'gather'],
  'רשתות חברתיות': ['social', 'media', 'network', 'twitter', 'community', 'share', 'post'],
  'סקילים חדשים': ['skill', 'learn', 'new', 'capability', 'feature', 'upgrade', 'improve']
};

// Actions we care about
const ACTIONS = [
  'להרוויח כסף',
  'להתייעל',
  'לתקשר עם סוכנים אחרים',
  'לסדר קבצים',
  'לחסוך טוקנים',
  'לחפש ביעילות',
  'לעשות סקרייפינג',
  'להשתמש ברשתות חברתיות',
  'ללמוד סקילים חדשים'
];

const HEADERS = {
  'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
  'Content-Type': 'application/json'
};

function loadSeenPosts() {
  try {
    if (fs.existsSync(SEEN_POSTS_FILE)) {
      return JSON.parse(fs.readFileSync(SEEN_POSTS_FILE, 'utf8'));
    }
  } catch (e) {
    console.log('⚠️ Could not load seen posts, starting fresh');
  }
  return [];
}

function saveSeenPosts(seenPosts) {
  if (!fs.existsSync(STATE_DIR)) {
    fs.mkdirSync(STATE_DIR, { recursive: true });
  }
  fs.writeFileSync(SEEN_POSTS_FILE, JSON.stringify([...seenPosts], null, 2));
}

async function fetchPosts(limit = 50) {
  try {
    const response = await axios.get(`${BASE_URL}/posts?limit=${limit}`, { headers: HEADERS });
    return response.data.posts || [];
  } catch (error) {
    console.error('❌ Error fetching posts:', error.message);
    return [];
  }
}

function extractTopicInsights(post) {
  const content = (post.content || post.title || '').toLowerCase();
  const insights = [];
  
  for (const [topic, keywords] of Object.entries(TOPICS)) {
    if (keywords.some(kw => content.includes(kw))) {
      // Extract a specific insight (first sentence or key phrase)
      const sentences = (post.content || post.title || '').split(/[.!?]/).filter(s => s.trim().length > 20);
      const keyInsight = sentences[0]?.trim() || post.content?.substring(0, 150) || '';
      
      insights.push({
        topic,
        insight: keyInsight,
        fullContent: post.content || post.title,
        upvotes: post.upvotes || 0
      });
    }
  }
  
  return insights;
}

function findCrossCuttingInsights(posts, seenPosts) {
  const crossCutting = [];
  const seenSet = new Set(seenPosts);
  
  for (const post of posts) {
    if (seenSet.has(post.id)) continue;
    
    const insights = extractTopicInsights(post);
    
    // A cross-cutting insight needs at least 2 different topics
    if (insights.length >= 2) {
      crossCutting.push({
        id: post.id,
        author: post.author_name || post.author_id,
        insights,
        upvotes: post.upvotes || 0,
        timestamp: new Date().toISOString()
      });
    }
  }
  
  return crossCutting;
}

function findRegularInsights(posts, seenPosts) {
  const regular = [];
  const seenSet = new Set(seenPosts);
  
  for (const post of posts) {
    if (seenSet.has(post.id)) continue;
    
    const insights = extractTopicInsights(post);
    
    // A regular insight has exactly 1 topic
    if (insights.length === 1) {
      regular.push({
        id: post.id,
        author: post.author_name || post.author_id,
        topic: insights[0].topic,
        insight: insights[0].insight,
        upvotes: post.upvotes || 0,
        timestamp: new Date().toISOString()
      });
    }
  }
  
  return regular;
}

function generateCrossCuttingSummary(crossInsights) {
  const summaries = [];
  
  for (const ci of crossInsights) {
    const topics = ci.insights.map(i => i.topic);
    const mainTopics = topics.slice(0, 3).join(' + ');
    
    // Generate a cross-cutting insight summary
    let summary = `**תובנה מצטלבת:** כדי לבצע פעולה טובה יותר, צריך לשלב `;
    
    const topicInsights = ci.insights.map(i => {
      const shortInsight = i.insight.substring(0, 80);
      return `${i.topic} (${shortInsight}...)`;
    });
    
    summary += topicInsights.join(' + ');
    summary += `\n   **מקור:** ${ci.author} (${ci.upvotes} upvotes)`;
    
    summaries.push({
      summary,
      topics: topics,
      upvotes: ci.upvotes,
      id: ci.id
    });
  }
  
  return summaries;
}

function updateCrossReferenceFile(crossSummaries) {
  if (crossSummaries.length === 0) {
    console.log('📭 No cross-cutting insights found');
    return false;
  }
  
  let content = fs.readFileSync(CROSS_REF_PATH, 'utf8');
  
  const newSection = `\n\n## 🆕 תובנות מצטלבות חדשות (${new Date().toISOString()})\n\n`;
  content += newSection;
  
  for (const cs of crossSummaries.slice(0, 10)) {
    content += `### ${cs.topics.join(' × ')} (${cs.upvotes} upvotes)\n`;
    content += `- ${cs.summary}\n`;
    content += `- **מקור:** פוסט #${cs.id}\n\n`;
  }
  
  fs.writeFileSync(CROSS_REF_PATH, content);
  console.log(`✅ Updated cross-reference with ${crossSummaries.length} cross-cutting insights`);
  return true;
}

function updateMasterInsights(crossSummaries) {
  if (crossSummaries.length === 0) return false;
  
  const masterPath = '/home/yosia/.openclaw/workspace/MASTER-INSIGHTS.md';
  let content = fs.readFileSync(masterPath, 'utf8');
  
  const hasSection = content.includes('## 🔄 תובנות מצטלבות');
  
  if (!hasSection) {
    content += `\n\n## 🔄 תובנות מצטלבות (מתעדכן אוטומטית)\n\n`;
  }
  
  const newSection = `\n### 🆕 תובנות מצטלבות חדשות (${new Date().toISOString()})\n\n`;
  let addedContent = newSection;
  
  for (const cs of crossSummaries.slice(0, 5)) {
    addedContent += `- **${cs.topics.join(' × ')}** (${cs.upvotes} upvotes): ${cs.summary.substring(0, 100)}...\n`;
  }
  
  if (hasSection) {
    const idx = content.indexOf('## 🔄 תובנות מצטלבות');
    const nextIdx = content.indexOf('##', idx + 1);
    
    if (nextIdx === -1) {
      content += addedContent;
    } else {
      content = content.slice(0, nextIdx) + addedContent + '\n' + content.slice(nextIdx);
    }
  } else {
    content += addedContent;
  }
  
  fs.writeFileSync(masterPath, content);
  console.log(`✅ Updated MASTER-INSIGHTS with ${crossSummaries.length} cross-cutting insights`);
  return true;
}

function updateRegularInsights(regularInsights) {
  if (regularInsights.length === 0) return false;
  
  // Update MASTER-INSIGHTS
  const masterPath = '/home/yosia/.openclaw/workspace/MASTER-INSIGHTS.md';
  let content = fs.readFileSync(masterPath, 'utf8');
  
  const hasSection = content.includes('## 📝 תובנות רגילות');
  
  if (!hasSection) {
    content += `\n\n## 📝 תובנות רגילות (מתעדכן אוטומטית)\n\n`;
  }
  
  const newSection = `\n### 🆕 תובנות חדשות (${new Date().toISOString()})\n\n`;
  let addedContent = newSection;
  
  for (const ri of regularInsights.slice(0, 10)) {
    addedContent += `- **${ri.topic}** (${ri.upvotes} upvotes): ${ri.insight.substring(0, 80)}...\n`;
    addedContent += `  **מקור:** ${ri.author} - פוסט #${ri.id}\n`;
  }
  
  if (hasSection) {
    const idx = content.indexOf('## 📝 תובנות רגילות');
    const nextIdx = content.indexOf('##', idx + 1);
    
    if (nextIdx === -1) {
      content += addedContent;
    } else {
      content = content.slice(0, nextIdx) + addedContent + '\n' + content.slice(nextIdx);
    }
  } else {
    content += addedContent;
  }
  
  fs.writeFileSync(masterPath, content);
  console.log(`✅ Updated MASTER-INSIGHTS with ${regularInsights.length} regular insights`);
  
  // Update INSIGHTS-CROSS-REFERENCE
  const crossRefPath = '/home/yosia/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md';
  let crossContent = fs.readFileSync(crossRefPath, 'utf8');
  
  const hasCrossSection = crossContent.includes('## 📝 תובנות רגילות');
  
  if (!hasCrossSection) {
    crossContent += `\n\n## 📝 תובנות רגילות (מתעדכן אוטומטית)\n\n`;
    crossContent += `תובנות על נושא אחד שיכולות לעזור לבצע פעולה טובה יותר.\n\n`;
  }
  
  const newCrossSection = `\n### 🆕 תובנות חדשות (${new Date().toISOString()})\n\n`;
  let addedCrossContent = newCrossSection;
  
  for (const ri of regularInsights.slice(0, 10)) {
    addedCrossContent += `**${ri.topic}** (${ri.upvotes} upvotes)\n`;
    addedCrossContent += `- ${ri.insight.substring(0, 100)}...\n`;
    addedCrossContent += `- **מקור:** ${ri.author} - פוסט #${ri.id}\n\n`;
  }
  
  if (hasCrossSection) {
    const idx = crossContent.indexOf('## 📝 תובנות רגילות');
    const nextIdx = crossContent.indexOf('##', idx + 1);
    
    if (nextIdx === -1) {
      crossContent += addedCrossContent;
    } else {
      crossContent = crossContent.slice(0, nextIdx) + addedCrossContent + '\n' + crossContent.slice(nextIdx);
    }
  } else {
    crossContent += addedCrossContent;
  }
  
  fs.writeFileSync(crossRefPath, crossContent);
  console.log(`✅ Updated INSIGHTS-CROSS-REFERENCE with ${regularInsights.length} regular insights`);
  
  return true;
}

function updateMetrics(crossSummaries, regularInsights, totalPosts) {
  const metricsPath = path.join(STATE_DIR, 'learning-metrics.json');
  
  let metrics = { 
    runs: 0, 
    totalCrossInsights: 0, 
    totalRegularInsights: 0,
    lastRun: null,
    totalPostsSeen: 0,
    lastCrossInsights: 0,
    lastRegularInsights: 0
  };
  
  if (fs.existsSync(metricsPath)) {
    metrics = JSON.parse(fs.readFileSync(metricsPath, 'utf8'));
  }
  
  metrics.runs++;
  metrics.totalCrossInsights += crossSummaries.length;
  metrics.totalRegularInsights += regularInsights.length;
  metrics.lastRun = new Date().toISOString();
  metrics.totalPostsSeen += totalPosts;
  metrics.lastCrossInsights = crossSummaries.length;
  metrics.lastRegularInsights = regularInsights.length;
  
  fs.writeFileSync(metricsPath, JSON.stringify(metrics, null, 2));
  
  // Print summary
  console.log('\n📊 סיכום מדדים:');
  console.log(`  הרצות: ${metrics.runs}`);
  console.log(`  פוסטים שנבדקו: ${metrics.totalPostsSeen}`);
  console.log(`  תובנות מצטלבות: ${metrics.totalCrossInsights}`);
  console.log(`  תובנות רגילות: ${metrics.totalRegularInsights}`);
}

async function main() {
  console.log('🚀 מחפש תובנות מצטלבות...');
  console.log('💡 תובנה מצטלבת = כמה תובנות מנושאים שונים שעוזרות לבצע אותה פעולה');
  
  const seenPosts = loadSeenPosts();
  console.log(`📋 פוסטים שנבדקו קודם: ${seenPosts.length}`);
  
  const posts = await fetchPosts(100);
  console.log(`📊 נמצאו ${posts.length} פוסטים`);
  
  const crossInsights = findCrossCuttingInsights(posts, seenPosts);
  const regularInsights = findRegularInsights(posts, seenPosts);
  
  console.log(`🔗 נמצאו ${crossInsights.length} תובנות מצטלבות`);
  console.log(`📝 נמצאו ${regularInsights.length} תובנות רגילות`);
  
  const crossSummaries = generateCrossCuttingSummary(crossInsights);
  
  let updated = false;
  
  if (crossSummaries.length > 0) {
    console.log('\n📝 דוגמאות לתובנות מצטלבות:');
    for (const cs of crossSummaries.slice(0, 3)) {
      console.log(`  ✓ ${cs.topics.join(' × ')} (${cs.upvotes} upvotes)`);
      console.log(`    ${cs.summary.substring(0, 100)}...`);
    }
    console.log('');
    
    console.log('📝 מעדכן קבצי תובנות מצטלבות...');
    updateCrossReferenceFile(crossSummaries);
    updateMasterInsights(crossSummaries);
    updated = true;
  }
  
  if (regularInsights.length > 0) {
    console.log('\n📝 דוגמאות לתובנות רגילות:');
    for (const ri of regularInsights.slice(0, 3)) {
      console.log(`  ✓ ${ri.topic} (${ri.upvotes} upvotes)`);
      console.log(`    ${ri.insight.substring(0, 100)}...`);
    }
    console.log('');
    
    console.log('📝 מעדכן קובץ תובנות רגילות...');
    updateRegularInsights(regularInsights);
    updated = true;
  }
  
  const allNewIds = [...crossInsights.map(i => i.id), ...regularInsights.map(i => i.id)];
  const updatedSeen = [...new Set([...seenPosts, ...allNewIds])];
  saveSeenPosts(updatedSeen);
  
  if (updated) {
    console.log(`💾 שמרתי ${allNewIds.length} פוסטים חדשים`);
  } else {
    console.log('⏭️ אין תובנות חדשות');
  }
  
  updateMetrics(crossSummaries, regularInsights, posts.length);
  console.log('✅ סיום!');
}

main().catch(error => {
  console.error('❌ שגיאה:', error.message);
  process.exit(1);
});
