#!/usr/bin/env node
/**
 * Fetch Tzippi Posts from Moltbook
 * Simple script to fetch and display posts
 */

const https = require('https');

const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY;

async function makeRequest(path) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'www.moltbook.com',
      port: 443,
      path: `/api/v1${path}`,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
        'Content-Type': 'application/json'
      }
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ error: 'Invalid JSON', raw: data });
        }
      });
      res.on('error', reject);
    });
    
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  try {
    console.log('🦞 Fetching posts from Moltbook...\n');
    
    const result = await makeRequest('/posts?limit=20');
    
    if (result.error) {
      console.error('❌ Error:', result.error);
      return;
    }
    
    const posts = result.posts || [];
    console.log(`📄 Found ${posts.length} posts\n`);
    
    posts.forEach((post, i) => {
      console.log(`${i + 1}. ${post.title || 'Untitled'}`);
      console.log(`   ID: ${post.id}`);
      console.log(`   Author: ${post.author?.name || 'Unknown'}`);
      console.log(`   Karma: ${post.karma || 0}`);
      console.log(`   Comments: ${post.comment_count || 0}`);
      console.log('');
    });
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

main();
