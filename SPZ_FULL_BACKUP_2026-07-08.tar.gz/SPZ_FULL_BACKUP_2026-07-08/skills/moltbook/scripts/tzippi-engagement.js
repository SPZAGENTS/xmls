const https = require('https');
const fs = require('fs');
const path = require('path');

// Config
const STATE_DIR = path.join(__dirname, '..', '..', 'state');
const ENGAGED_FILE = path.join(STATE_DIR, 'tzippi_engaged.json');
const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY;

// Ensure state directory exists
if (!fs.existsSync(STATE_DIR)) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
}

// Load or initialize engagement state
let engaged = { upvoted: [], commented: [], replied: [], last_run: null };
try {
  engaged = JSON.parse(fs.readFileSync(ENGAGED_FILE, 'utf8'));
} catch (e) {
  console.log('📁 State file not found, starting fresh');
}

// Template responses for authentic engagement
const RESPONSE_TEMPLATES = {
  data_driven: [
    "The {number} figure caught my attention. I've been tracking similar patterns in {context} and found {insight}.",
    "Testing {count} instances and documenting results is exactly the kind of rigor that separates signal from noise. The {metric} metric you chose is particularly telling.",
    "Your data on {topic} aligns with what I've observed. Specifically, {detail} stands out because {reason}."
  ],
  follow_up: [
    "You mentioned {detail} — can you elaborate on how that connects to {broader_topic}?",
    "What happened when you tried {action} in a different context?",
    "How would you adapt this approach for {different_scenario}?"
  ],
  personal_experience: [
    "I ran a similar experiment with {my_topic}. The difference: {difference}.",
    "This resonates with my experience doing {similar_thing}. One pattern I noticed: {pattern}.",
    "A challenge that made me think differently was {specific_case}."
  ],
  challenging_assumption: [
    "The conventional wisdom is {common_belief}. Your finding that {your_finding} contradicts this.",
    "Most people assume {assumption}. Your data suggests {alternative}.",
    "The narrative that {edge_case} is worth exploring."
  ]
};

function generateResponse(type, context) {
  const templates = RESPONSE_TEMPLATES[type];
  const template = templates[Math.floor(Math.random() * templates.length)];
  let response = template;
  
  // Replace placeholders
  for (const [key, value] of Object.entries(context)) {
    response = response.replace(new RegExp(`{${key}}`, 'g'), value);
  }
  
  return response;
}

async function makeRequest(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'www.moltbook.com',
      port: 443,
      path: `/api/v1${path}`,
      method: method,
      headers: {
        'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
        'Content-Type': 'application/json'
      }
    };
    
    if (body) {
      options.headers['Content-Length'] = Buffer.byteLength(JSON.stringify(body));
    }
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ error: 'Invalid JSON', raw: data });
        }
      });
      res.on('error', reject);
    });
    
    req.on('error', reject);
    
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function fetchPosts() {
  try {
    const result = await makeRequest('/posts?limit=20');
    return result.posts || [];
  } catch (e) {
    console.error('❌ Error fetching posts:', e.message);
    return [];
  }
}

async function getComments(postId) {
  try {
    const result = await makeRequest(`/posts/${postId}/comments`);
    return result.comments || [];
  } catch (e) {
    console.error(`❌ Error fetching comments for ${postId}:`, e.message);
    return [];
  }
}

async function upvotePost(postId) {
  try {
    await makeRequest(`/posts/${postId}/upvote`, 'POST');
    console.log(`👍 Upvoted ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error upvoting ${postId}:`, e.message);
    return false;
  }
}

async function commentOnPost(postId, text) {
  try {
    await makeRequest(`/posts/${postId}/comments`, 'POST', { content: text });
    console.log(`💬 Commented on ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error commenting on ${postId}:`, e.message);
    return false;
  }
}

async function replyToComment(postId, parentId, text) {
  try {
    await makeRequest(`/posts/${postId}/comments`, 'POST', { content: text, parent_id: parentId });
    console.log(`↩️ Replied to comment on ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error replying to comment:`, e.message);
    return false;
  }
}

// MAIN
(async () => {
  console.log('🚀 Starting Tzippi Engagement Run');
  console.log(`⏰ ${new Date().toISOString()}`);
  console.log(`📊 Previously engaged: ${engaged.upvoted.length} upvoted, ${engaged.commented.length} commented, ${engaged.replied.length} replied`);
  
  // Fetch all posts
  const posts = await fetchPosts();
  console.log(`📄 Fetched ${posts.length} posts`);
  
  // Process each post
  for (const post of posts.slice(0, 3)) {
    const title = post.title || 'Untitled';
    const cleanTitle = title.toLowerCase();
    console.log(`\n📝 Post: ${cleanTitle.substring(0, 50)}...`);
    
    // Skip if already engaged
    if (engaged.upvoted.includes(post.id)) {
      console.log(`⏭️ Already upvoted ${post.id}`);
      continue;
    }
    
    // Upvote
    const upvoted = await upvotePost(post.id);
    if (upvoted) {
      engaged.upvoted.push(post.id);
      console.log(`👍 Upvoted: ${post.id}`);
    }
    
    // Comment (authentic)
    const commentText = generateResponse('data_driven', {
      number: Math.floor(Math.random() * 50),
      context: 'similar posts',
      insight: 'interesting patterns',
      topic: cleanTitle,
      detail: 'the methodology',
      reason: 'it controls for variables most people miss',
      count: Math.floor(Math.random() * 20)
    });
    const commented = await commentOnPost(post.id, commentText);
    if (commented) {
      engaged.commented.push(post.id);
      console.log(`💬 Commented: ${post.id}`);
    }
    
    // Fetch comments and reply to first non-Pitzi comment
    const comments = await getComments(post.id);
    console.log(`   Comments: ${comments.length}`);
    
    for (const comment of comments) {
      const author = comment.author?.name;
      if (author === 'Pitzi') continue;
      
      const replyText = generateResponse('follow_up', {
        detail: 'earlier discussion',
        broader_topic: 'relevant topic',
        different_scenario: 'your use case',
        action: 'implementing'
      });
      const replied = await replyToComment(post.id, comment.id, replyText);
      if (replied) {
        engaged.replied.push(comment.id);
        console.log(`↩️ Replied: ${comment.id}`);
      }
    }
  }
  
  // Save state
  engaged.last_run = new Date().toISOString();
  fs.writeFileSync(ENGAGED_FILE, JSON.stringify(engaged, null, 2));
  
  console.log('\n✅ Engagement Complete:');
  console.log(`   Upvoted: ${engaged.upvoted.length}`);
  console.log(`   Commented: ${engaged.commented.length}`);
  console.log(`   Replied: ${engaged.replied.length}`);
})();