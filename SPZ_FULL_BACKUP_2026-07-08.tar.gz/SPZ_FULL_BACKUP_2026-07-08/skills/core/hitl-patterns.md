---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: hitl-patterns
version: "1.0.1"
description: Human-in-the-Loop patterns - מתי ואיך להפעיל בן אדם בסוכן אוטונומי
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - HITL
  - human in the loop
  - אישור
  - התערבות
metadata:
  openclaw:
    emoji: "👤"
    tags: [hitl, human-in-the-loop, intervention, approval, safety]
---

# 👤 Human-in-the-Loop (HITL)

## עיקרון מרכזי
**95% אוטומציה + 5% בן אדם = נצחון**

לא 100% אוטונומיה - זה נכשל. בניית מערכת שיודעת מתי לבקש עזרה.

## 7 דפוסי HITL

### 1. Approval Gates 🚪
**מתי:** לפני פעולה בלתי הפיכה

```
סוכן: "אני רוצה לשלוח אימייל ל-50 לקוחות"
    ↓
מערכת: [PAUSE] ממתין לאישור
    ↓
אדם: [אשר] / [דחה] / [ערוך]
    ↓
סוכן: ממשיך / מתקן / מבטל
```

**דוגמאות:**
- שליחת אימיילים המוניים
- חיוב כספים
- מחיקת נתונים
- פרסום פומבי

---

### 2. Confidence Thresholds 📊
**מתי:** סוכן לא בטוח בתשובה

```python
if confidence < 0.7:
    route_to_human()
elif confidence < 0.9:
    request_verification()
else:
    proceed()
```

**דרגות ביטחון:**
- 10/10 = בטוח מוחלט, מקורות ברורים
- 7-9 = די בטוח, אבל בדוק
- 4-6 = לא בטוח, הודה בזה
- 1-3 = בן אדם חייב להכנס

---

### 3. Edge Case Triggers 🚨
**מתי:** משהו לא תקין

**טריגרים:**
- לולאה אינסופית (10+ איטרציות)
- שגיאה חוזרת 3 פעמים
- זמן ריצה חריג (>5 דקות)
- עלות חריגה (>$1 לפעולה)
- הזיה ברורה (נתונים לא הגיוניים)

```python
def check_edge_cases(agent_state):
    if agent_state.iterations > 10:
        raise HumanIntervention("Possible infinite loop")
    
    if agent_state.cost > 1.0:
        raise HumanIntervention("Cost exceeded threshold")
    
    if detect_hallucination(agent_state.output):
        raise HumanIntervention("Possible hallucination")
```

---

### 4. Feedback Loops 🔄
**מתי:** אחרי פעולה ללמידה

```
סוכן מבצע → אדם מתקן → משוב נשמר → סוכן משתפר
```

**מימוש:**
```python
# אחרי כל פעולה
if human_provided_feedback:
    store_feedback(action, correction)
    fine_tune_model(feedback)  # RLHF style
```

---

### 5. Session Handover 🔄
**מתי:** סוכן תקוע

**Cloudflare Browser Run pattern:**
```
סוכן מנסה → נכשל 3 פעמים
    ↓
העבר session לאדם
    ↓
אדם מתקן → מחזיר לסוכן
    ↓
סוכן ממשיך
```

---

### 6. Deterministic Gates + Clustering 🎯
```
משימות שגרתיות → סוכן
    ↓
בדיקה דטרמיניסטית
    ↓
סתירה? → אדם מטפל
תקין? → סוכן ממשיך
```

---

### 7. Multi-Agent Routing 🤝
```
בקשה נכנסת
    ↓
Coordinator Agent
    ↓
פשוט? → Specialist Agent
מורכב? → Human Expert
דחוף? → Human + Escalation
```

## טבלת החלטה

| מצב | פעולה | דוגמה |
|-----|-------|-------|
| פעולה בלתי הפיכה | Approval Gate | שליחת אימייל |
| confidence < 70% | Human Review | תשובה לא ברורה |
| לולאה אינסופית | Emergency Stop | 50 איטרציות |
| עלות >$1 | Cost Approval | שימוש יקר |
| סוכן תקוע | Session Handover | לא מצליח לפתור |
| משימה מורכבת | Route to Expert | חוזה משפטי |

## Best Practices

### 1. תמיד Trace
```
תעד כל צעד → אדם רואה הקשר מלא
```

### 2. הקשר מלא
```
לא: "יש בעיה"
כן: "בשלב 3 ניסיתי X, קיבלתי Y, לא ברור אם Z"
```

### 3. Speed vs Safety
```
סיכון נמוך + זמן קצר → אוטומטי
סיכון גבוה + זמן ארוך → HITL
```

### 4. למד מתי לבקש
```
סוכן משתפר עם הזמן:
חודש 1: 30% פונים לאדם
חודש 3: 15% פונים לאדם
חודש 6: 5% פונים לאדם
```

## מדדים

- **Time to Human**: כמה זמן עד שאדם מגיב
- **Resolution Rate**: כמה פעמים אדם פותר vs מחזיר לסוכן
- **False Positives**: כמה פעמים קראנו לאדם בלי סיבה
- **Learning Rate**: איך הסוכן משתפר מה-feedback

---

*מבוסס על LangGraph + Cloudflare + Production best practices*
