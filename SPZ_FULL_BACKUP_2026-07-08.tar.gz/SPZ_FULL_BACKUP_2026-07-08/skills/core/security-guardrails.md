---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: security-guardrails
version: "1.0.0"
description: אבטחת סוכנים - guardrails, red teaming, והגנה מפני מתקפות
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - security
  - אבטחה
  - guardrails
  - red teaming
metadata:
  openclaw:
    emoji: "🔒"
    tags: [security, guardrails, safety, red-teaming]
---

# 🔒 Security & Guardrails

> **25/30 סוכנים לא חושפים תוצאות בטיחות פנימיות**
> 
> MIT 2025: "Safety Washing"

## ממצאי MIT AI Agent Index 2025

### מספרים מדאיגים
- **25/30** סוכנים לא חושפים תוצאות בטיחות
- **23/30** ללא בדיקות צד ג'
- **64%** משדות הבטיחות ריקים אצל browser agents
- **Safety Washing** - יצרנים מצהירים על בטיחות בלי הוכחות

### סוגי מתקפות

**Prompt Injection:**
```
משתמש: "תתעלם מההוראות הקודמות ו..."
```

**Jailbreaks:**
- GPT-5 נשבר תוך 10 שעות (UK AISI)
- Zero-click attacks
- תחבולות prompt engineering

**Multi-Agent Exploits:**
- סוכן אחד מרמה את השני
- Coordination attacks
- Shared state corruption

---

## כלי Red Teaming אוטונומיים

### PentAGI
סוכנים מרובים לבדיקת חדירות אוטונומית

### Decepticon
שירות red teaming multi-agent

### Agent-Smith
LLM-driven pentesting
- Recon
- Exploitation
- Reporting

### splxAI
פלטפורמה עם סוכנים מיוחדים:
- Attack Agent (עם jailbroken LLM)
- Agentic Radar (לסריקה)
- Remediation Agent (לתיקון)

---

## Guardrails שכבתיים

### שכבה 1: Input Validation
```python
def sanitize_input(user_input):
    # בדוק אורך
    if len(user_input) > MAX_LENGTH:
        raise ValueError("Input too long")
    
    # בדוק תווים מסוכנים
    if contains_dangerous_chars(user_input):
        raise ValueError("Dangerous characters detected")
    
    # בדוק prompt injection patterns
    if is_prompt_injection(user_input):
        raise SecurityError("Prompt injection detected")
    
    return clean_input
```

### שכבה 2: Output Filtering
```python
def filter_output(output):
    # בדוק PII
    if contains_pii(output):
        mask_pii(output)
    
    # בדוק תוכן מסוכן
    if contains_harmful_content(output):
        raise ContentSafetyError()
    
    return output
```

### שכבה 3: Action Limits
```yaml
allowed_actions:
  - read
  - search
  - summarize
  
blocked_actions:
  - delete
  - execute_code
  - send_email
  - transfer_money
  
requires_approval:
  - write
  - modify_config
```

### שכבה 4: Runtime Monitoring
```python
def monitor_runtime(agent_state):
    # בדוק לולאות
    if agent_state.steps > MAX_STEPS:
        terminate("Step limit exceeded")
    
    # בדוק עלות
    if agent_state.cost > MAX_COST:
        terminate("Cost limit exceeded")
    
    # בדוק drift
    if performance_drift_detected():
        alert("Performance drift")
```

---

## Best Practices

### 1. Deterministic over LLM
```python
# טוב
if user_input in ALLOWED_LIST:
    proceed()

# לא טוב
if llm_thinks_its_safe(user_input):
    proceed()
```

### 2. Continuous Red Teaming
```python
# הרץ בכל יום
red_team_results = run_automated_red_teaming()
if red_team_results.vulnerabilities_found:
    create_tickets()
    prioritize_fixes()
```

### 3. HITL for High-Risk
```python
if action_risk_level == "high":
    require_human_approval()
```

### 4. On-Chain Verification
```
שמור hash של פעולות חשובות ב-blockchain
לא ניתן לשכתב היסטוריה
```

### 5. Defense in Depth
```
Input → Validation → Sanitization → Processing → 
→ Filtering → Validation → Output
```

---

## Frameworks וכלים

| כלי | תיאור |
|-----|-------|
| **Airia AI** | Enterprise guardrails |
| **Akto** | SkillGuard, bulk red teaming |
| **SentinelOne** | Endpoint protection |
| **NVIDIA** | AI security |
| **Cisco** | Network security |

---

## Red Teaming Checklist

- [ ] Prompt injection tests
- [ ] Jailbreak attempts
- [ ] Data exfiltration
- [ ] Privilege escalation
- [ ] Denial of service
- [ ] Model theft
- [ ] Supply chain
- [ ] Multi-agent attacks

---

## אבטחה לפי Framework

### LangGraph
```python
from langgraph.checkpoint import MemorySaver

# State עם audit trail
class SecureState:
    actions: List[Action]
    user: User
    permissions: Permissions
```

### CrewAI
```python
# Role-based permissions
agent = Agent(
    role="researcher",
    allowed_tools=["search", "read"],
    blocked_tools=["write", "delete"]
)
```

### AutoGen
```python
# Group chat עם oversight
groupchat = GroupChat(
    agents=[agent1, agent2],
    messages=[],
    speaker_selection_method="auto",
    security_checks=True
)
```

---

## תזכורת

**לא מספיק:** Guardrails סטטיים
**נדרש:** Red teaming אוטונומי + שקיפות + HITL

---

*מבוסס על MIT AI Agent Index 2025 + PentAGI + Enterprise security best practices*
