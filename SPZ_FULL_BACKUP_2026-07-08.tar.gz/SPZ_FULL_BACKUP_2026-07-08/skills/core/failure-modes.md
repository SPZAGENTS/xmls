---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: failure-modes
version: "1.0.0"
description: מצבי כשלון ולקחים מייצור - מה נכשל ואיך מתקנים
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - failure
  - כשלון
  - שגיאה
  - lessons learned
metadata:
  openclaw:
    emoji: "⚠️"
    tags: [failure, errors, lessons, production, debugging]
---

# ⚠️ Failure Modes & Lessons Learned

> **88-95% מהפיילוטים נכשלים בייצור**> 
> לא בגלל "מודלים טיפשים" - בגלל הנדסה גרועה

## המציאות המרה

### נתונים מדאיגים:
- **88-95%** מהפיילוטים לא מגיעים לייצור
- **68%** מבצעים ≤10 צעדים
- **47%** ≤5 צעדים לפני התערבות אנושית
- **80%** משתמשים ב-workflows סטטיים
- **85% הצלחה לצעד** = **~19% הצלחה ל-10 צעדים**

### כשלון מתמטי:
```
0.85^10 = 0.197
= 19.7% הצלחה

85% לצעד נשמע טוב
אבל על 10 צעדים = כישלון
```

---

## סוגי כשלון עיקריים

### 1. Planning/Reasoning

**הבעיות:**
- Tool hallucination - פרמטרים שגויים
- Unbounded horizons - דריפט
- Poor termination - לא יודע לעצור
- Sycophantic loops - מסכים עם המשתמש יתר על המידה

**הפתרונות:**
- ReAct (לא רק CoT)
- Bounded planning - הגבל צעדים
- Explicit exit logic
- Output checks

---

### 2. Memory/State

**הבעיות:**
- Context decay - שכחה
- In-memory loss on crashes
- Single memory type ב-scale

**הפתרונות:**
- Multi-layer memory (episodic/semantic/procedural)
- Durable checkpoints
- Position-aware context

---

### 3. Tools/Execution

**הבעיות:**
- Unreliable calls
- Infinite loops
- Timeouts
- Rigid tools

**הפתרונות:**
- Retries/fallbacks
- Schema validation
- Adaptive tool re-ranking
- Circuit breakers

---

### 4. Multi-Agent

**14 מצבי כשלון זוהו:**
1. Role disobedience
2. History loss
3. Withholding info
4. Task derailment
5. ועוד 10...

**הפתרונות:**
- Clear roles/prompts
- Structured flows
- Cross-verification
- Modular reuse

---

## לקחים מרכזיים

### 1. Overhyped Autonomy

**האשליה:**
סוכן אוטונומי לחלוטין שפותר הכל

**המציאות:**
- Constrained > Autonomous
- 10 צעדים מקסימום
- התערבות אנושית תכופה

**הלקח:**
```
Trade capability for reliability
```

---

### 2. Workflow-First

**הטעות:**
"Vibe coding" - לקפוץ ישר לקוד

**הנכון:**
```
Document processes → Define boundaries → Build agent
```

**McKinsey's 6 factors:**
1. Workflow focus
2. Right tasks
3. Benchmarks
4. Per-step tracking
5. Modularity
6. Human roles

---

### 3. Custom Over Frameworks

**הנתון:**
**85%** מהצוותים בייצור בונים מ-scratch

**למה?**
- Simple loops
- שליטה מלאה
- Debugging קל
- Frameworks = overkill

---

### 4. Adaptation > Execution

**הבעיה:**
סוכנים נכשלים כי לא מעדכנים תכניות באמצע

**הפתרון:**
```python
while not done:
    outcome = execute_step()
    if outcome != expected:
        plan = revise_plan(outcome)
    monitor_outcome(outcome)
```

---

### 5. Observability = חיים

**הנתון:**
**75%** חסרי benchmarks

**הפתרון:**
- OpenTelemetry
- Prometheus/ELK/PagerDuty
- Track every step
- Not just outcomes

---

## מציאות ייצור 2025-2026

### מה עובד:
- Frontier models (Claude/GPT) - **dominant**
- Open-source לעלות/רגולציה
- 10x human speed
- סבלנות לדקות ארוכות

### מה לא עובד:
- Autonomy מלאה
- Long-horizon ללא הגבלה
- "Vibe coding"
- אין monitoring

---

## Taxonomy Resources

- Microsoft report
- HORIZON benchmark
- Sequoia/McKinsey studies
- Stanford 500+ failures analysis

---

## Bottom Line

**ההצלחה = 80% failure-handling**

- Build for verification first
- Constraints > autonomy
- Observability = חובה
- HITL = ברירת מחדל

**לא מודלים טיפשים - הנדסה גרועה.**

---

*מבוסס על 400+ סוכנים בייצור + Stanford + McKinsey*
