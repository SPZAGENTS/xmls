---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: reasoning-planning
version: "1.0.0"
description: תכנון וחשיבה - CoT, ToT, ReAct, ו-deep agents
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - reasoning
  - planning
  - תכנון
  - חשיבה
metadata:
  openclaw:
    emoji: "🧩"
    tags: [reasoning, planning, cot, tot, react]
---

# 🧩 Reasoning & Planning

> **CoT = Workaround טרנזיציוני**> 
> העתיד: high-dimensional latent spaces

## אבולוציה של חשיבה

### 2023-2024: Chatbots → Basic Reasoning
- RLHF
- Chain-of-Thought (CoT)
- "Think step by step"

### 2025: Single-Task Agents
- Agentic RL
- Continuous planning
- Deep Agents

### 2026: Long-Running/Multi-Agent
- RL context management
- ADLC (Agent-Driven Lifecycle)
- Economic autonomy

---

## טכניקות מרכזיות

### 1. Chain-of-Thought (CoT)

**בסיסי:**
```
"Think step by step"
```

**מתקדם:**
```python
response = llm.generate(
    prompt + "\n\nLet's think through this step by step:"
)
# Verbalize intermediate steps
```

**יתרונות:**
- Inspectable
- מובן לאנשים

**חסרונות:**
- איטי
- Text = bottleneck
- מוגבל ל-backtracking

---

### 2. Tree-of-Thoughts (ToT)

```
                    [Start]
                   /   |   \
              [A1]   [A2]   [A3]
             /  |      |       \
         [B1] [B2]   [B3]    [B4]
          |
      [Best]
```

**אלגוריתם:**
```python
for step in range(max_steps):
    # Generate candidates
    candidates = generate_thoughts(current_state, n=3)
    
    # Evaluate
    scores = evaluate(candidates)
    
    # Select best
    best = select(candidates, scores)
    
    # Expand
    current_state = best
```

---

### 3. Graph-of-Thoughts (GoT)

**יותר גמיש מ-ToT:**
```
Nodes = thoughts
Edges = relationships
Can merge, refine, regenerate
```

---

### 4. ReAct (Reason → Act → Observe → Reflect)

**לופ של תכנון ופעולה:**
```python
while not done:
    # Reason
    thought = reason(context)
    
    # Act
    action = decide_action(thought)
    result = execute(action)
    
    # Observe
    observation = observe(result)
    
    # Reflect
    reflection = reflect(observation)
    
    # Update context
    context += f"\n{thought}\n{action}\n{observation}\n{reflection}"
```

**מתאים ל:**
- Tool use
- Interactive tasks
- Dynamic environments

---

### 5. Deep Agents (2025+)

**Living to-do list:**
```python
plan = {
    "tasks": [
        {"id": 1, "status": "done", "result": "..."},
        {"id": 2, "status": "in_progress", "assigned_to": "sub_agent_1"},
        {"id": 3, "status": "pending", "depends_on": [2]}
    ],
    "orchestrator": "main_agent",
    "sub_agents": ["search", "code", "verify"]
}
```

**יתרונות:**
- Structured planning
- Dynamic delegation
- Multi-agent coordination

---

## טכניקות מתקדמות

### Meta's COCONUT (2024)
**חשיבה ב-latent spaces:**
- לא דרך טקסט
- High-dimensional
- יעיל יותר
- **Challenge:** alignment ו-monitoring

### Plan-and-Execute
```python
# Phase 1: Plan
plan = generate_plan(task)

# Phase 2: Execute (with recovery)
for step in plan:
    try:
        result = execute(step)
    except Exception:
        # Re-plan
        plan = replan_from_failure(step)
```

### Reflexion/CRITIC
```python
# Self-critique
output = generate()
critique = critique(output)

if critique.issues:
    improved = improve_based_on_critique(output, critique)
    return improved
```

---

## חשיבה מוגבלת (Bounded Reasoning)

**מגבלות מחקר:**
- **~10 turns** - peak performance
- **~25 turns** - ירידה משמעותית
- **אחרי 25** - checkpoint וריענון

**המלצה:**
```python
if turn_count > 25:
    checkpoint()
    refresh_context()
    reset_turn_count()
```

---

## תחזיות 2026

| תחום | תחזית |
|------|--------|
| Enterprise apps | 40% with agents (מ-5% ב-2025) |
| Agentic coding | כפול מהירות |
| Sovereign AI | עלייה |
| Long-running | ימים של אוטונומיה |

---

## Frameworks מומלצים

| Framework | שימוש |
|-----------|-------|
| **LangGraph** | State-based planning |
| **CrewAI** | Multi-agent swarms |
| **AutoGen** | Conversational |
| **LlamaIndex** | ReasoningBank |
| **OpenClaw** | (China) |
| **GLM 5.1** | Top open agent |

---

## אתגרים

1. **Brittleness** - שבירות במשימות מורכבות
2. **Context limits** - תקרת חלון
3. **Web IO costs** - עלות גלישה
4. **Safety** - ב-latent reasoning

---

## Best Practices

1. **התחל פשוט** - CoT בסיסי
2. **התקדם בהדרגה** - ToT/GoT אם צריך
3. **שמור על inspectability** - לא latent (עדיין)
4. **הגבל turns** - ~25 מקסימום
5. **תכנן לכישלון** - ReAct עם recovery
6. **שתף תכנון** - Deep Agents style

---

## Bottom Line

**המעבר מ-CoT פשוט ל-planning מתקדם**

- CoT = טרנזיציה
- ToT/GoT = גמישות
- ReAct = אינטראקציה
- Deep Agents = מבנה
- Latent = העתיד (אבל זהירות)

---

*מבוסס על 2025 reasoning research + Meta/Deep Agents*
