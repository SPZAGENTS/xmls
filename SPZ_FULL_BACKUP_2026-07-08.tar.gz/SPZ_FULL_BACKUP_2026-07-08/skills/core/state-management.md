---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: state-management
version: "1.0.0"
description: ניהול מצב ואופטימיזציית context window - טכניקות 2025
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - state
  - context window
  - זיכרון
  - optimization
metadata:
  openclaw:
    emoji: "🧠"
    tags: [state, context, memory, optimization]
---

# 🧠 State Management & Context Optimization

> **Context Window = צוואר הבקבוק**
> 
> ביצועים טובים ב-10-40% fill, ירידה אחרי כך

## הבנה בסיסית

### Context vs State

**Context = RAM (זיכרון עבודה)**
- זמני, ephemeral
- מוגבל ע"י softmax
- יקר בטוקנים

**State = Disk (זיכרון קבוע)**
- חיצוני, scalable
- זול בטוקנים
- נטען לפי דרישה

> **כלל אצבע: Window = scratchpad, לא database!**

---

## Context Engineering (#1 Skill לסוכן)

### ארבע טכניקות מרכזיות:

**1. Writing Out (כתיבה חוצה)**
```python
# במקום לשמור ב-context
with open("scratchpad.md", "w") as f:
    f.write(thought_process)

# טען רק כשצריך
with open("scratchpad.md", "r") as f:
    relevant = extract_relevant(f.read())
```

**2. Selecting In (RAG)**
```python
# הכנס רק מה שרלוונטי
relevant_memories = retrieve(query, top_k=5)
context = build_context(identity, task, relevant_memories)
```

**3. Compression (דחיסה)**
```python
# 95% reduction דרך סיכום
summary = summarize(long_text, ratio=0.05)
timeline = extract_timeline(details)
full_details = load_on_demand()
```

**4. Isolation (סגירה)**
```python
# Multi-agent sandboxes
agent1_context = ["identity", "task1"]
agent2_context = ["identity", "task2"]
# שתף דרך external memory, לא context
```

---

## External Persistent State

### Filesystem/DB
```yaml
state_storage:
  - YAML/JSON logs
  - SQLite for structured
  - Git history for versioning
  - Markdown for human-readable
```

**יתרון:** סוכנים מתחילים טריים כל סשן - עולה על context ארוך!

### Message History
```python
# הפשוט ביותר
conversation = load_history()
# LLM ממשיך מהשיחה בלבד
```

### Managed Services
- **Cloudflare Agent Memory** - auto-extract, summarize, retrieve
- **MemMachine** - universal memory layer
- **AgentFS** - filesystem state

---

## Multi-Agent & Decomposition

### Fresh Windows לכל סוכן
```python
agent1 = Agent(context=["identity", "task1"])
agent2 = Agent(context=["identity", "task2"])

# שתף דרך external whiteboard
shared_state.write(agent1_result)
agent2_input = shared_state.read()
```

**יתרונות:**
- Context נקי לכל סוכן
- No attention dilution
- Scalable

---

## Advanced Patterns

### Progressive Disclosure
```
Level 1: Summary (10% of tokens)
Level 2: Key points (20%)
Level 3: Full details (on demand)
```

### Compression Pipeline
```
Raw Data → Summary → Timeline → Details on Demand
           (95%     (98%        (100% when
            saved)    saved)      needed)
```

### Graph-Based Retrieval
```python
# Neo4j או similar
relevant = graph.query("""
  MATCH (n:Memory)-[r:RELATED_TO]->(m)
  WHERE n.topic = {query}
  RETURN m LIMIT 5
""")
```

### MCP Tools
```python
# Model Context Protocol
state = mcp_tool("read_state", key="user_preferences")
```

### Self-Evolving
```python
# Agentic Context Engineering
playbook = evolve_from_reflections()

# Autogenesis
improvements = self_validate(playbook)
```

---

## טכניקות יעילות

### מספרים מרשימים:
- **60%+** חיסכון בעלויות דרך caching/compression
- **95%** reduction בטוקנים עם סיכום
- **10-40%** fill = optimal performance
- **75%** מהחוקרים מתקשים ב-state

### כללי אצבע:
1. **קרא קבצים, אל Context** - Filesystem > Window
2. **Decompose** - Fresh windows לכל משימה
3. **Cache** - אל תחשב מחדש
4. **Compress** - סכם לפני הכנסה
5. **Load on Demand** - טען רלוונטי בלבד

---

## מבנה L1/L2/L3 מעודכן

```
L1 "כיס" (~3K tokens)
├── Identity
├── Current Task
└── Active References (pointers, לא תוכן!)

L2 "שולחן" (external)
├── Recent Interactions ( summaries)
├── Working Notes
└── Scratchpad Files

L3 "מדף" (external, semantic)
├── Full History (compressed)
├── Knowledge Base
└── Reference Materials
```

---

## Frameworks מומלצים

| Framework | יתרון |
|-----------|-------|
| **LangGraph** | State management |
| **n8n** | Visual workflows |
| **Agno** | Plan-learn agents |
| **Temporal** | Reliability |
| **AgentFS** | Filesystem state |

---

## Bottom Line

**חלונות קטנים + State חיצוני > חלונות גדולים**

- Externalize state (disk > window)
- Decompose tasks
- Engineer context surgically
- זה מנצח מודלים גדולים יותר!

---

*מבוסס על 2025 Context Engineering research*
