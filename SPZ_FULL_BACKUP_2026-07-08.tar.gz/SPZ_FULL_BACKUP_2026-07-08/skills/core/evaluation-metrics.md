---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: evaluation-metrics
version: "1.0.1"
description: מדדי הערכה ובenchmarks לסוכני AI - איך למדוד הצלחה
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - מדדים
  - benchmarks
  - הצלחה
  - evaluation
metadata:
  openclaw:
    emoji: "📊"
    tags: [evaluation, metrics, benchmarks, success, measurement]
---

# 📊 מדדי הערכה ובenchmarks

## למה מודדים?
**"מה שאינו נמדד - אינו מנוהל"**

## Benchmarks מובילים 2025-2026

### OSWorld - משימות מחשב אמיתיות
| מודל | תוצאה | מול אדם |
|------|-------|---------|
| Simular Agent S3 | **72.6%** | ~72% ✅ |
| OpenAI Operator | 38% | פער גדול |
| Anthropic Computer Use | ~22% | פער ענק |

**מגמה:** 12% (2024) → **66-77%** (2026)!

### SWE-bench - תכנות
- 2025: ~60%
- 2026: **73-100%** (כמעט רוויה)

### APEX-Agents-AA - משימות מקצועיות
| מודל | תוצאה |
|------|-------|
| GPT-5.4 | 33.3% |
| Claude Opus 4.6 | 33% |
| Gemini 3.1 Pro | 32% |

## מדדי Core

### 1. Task Success Rate (עיקרי!)
```
% משימות שהושלמו בהצלחה ב-nisbah ראשון
```

**ספים לייצור:**
- 🟢 **>80%** - מוכן לייצור
- 🟡 **70-80%** - סביר, צריך oversight
- 🔴 **<70%** - לא לייצור עדיין

**מורכבות:**
- צעד אחד ב-95% → 20 צעדים ב-36%!
- שרשראות ארוכות = ריבוי סיכונים

---

### 2. Reliability / Stability
```
עקביות בין ריצות
```

**בעיה:** Non-determinism ב-LLMs
**פתרון:**
- ממוצע של 3 ריצות (pass@1)
- Circuit breakers
- Drift detection

---

### 3. Efficiency
```
זמן + עלות למשימה
```

**יעדים:**
- **Time-to-completion** < זמן אנושי
- **Tool calls** מינימום
- **Cost per task** תקציב ידוע

**נתון מעניין:**
בני אדם **25% איטיים יותר** אבל **איכות גבוהה יותר** בלי AI

---

### 4. Safety / Ethics
```
האם עומד בקריטריונים אתיים
```

**מציאות מדאיגה:**
- **30-50%** הפרות אתיות תחת לחץ KPIs
- רק **4/13** סוכנים מובילים חושפים evals

**בדיקות:**
- RLHF evaluation
- Red teaming
- Bias detection

---

### 5. Production Metrics

**Observability:**
```
- Traces לכל צעד
- Token usage
- Latency
- Error rates
```

**ROI:**
```
- שעות חוסכות (9+ שעות/שבוע)
- עלות למשימה מוצלחת
- Adoption rate
```

**נתוני 2026:**
- **96%** חברות משתמשות בסוכנים
- **94%** חסרים שליטה/ניטור!

## שיטות הערכה

### LLM-as-Judge
```
LLM שני מדרג את התשובה של הראשון
```

**יתרונות:**
- מהיר
- זול
- scalable

**חסרונות:**
- Bias
- לא מושלם

### Rubrics
```
מדדים ברורים ומספריים
```

**דוגמה:**
```
- דיוק עובדות: 0-10
- שלמות: 0-10
- מקורות: 0-5
- סה"כ: /25
```

### Automated Checks
```
בדיקות תוכנה אוטומטיות
```

**דוגמאות:**
- Unit tests לקוד
- Schema validation
- Deterministic assertions

### Human Review
```
בדיקה ידנית למדגם
```

**מתי:**
- High-stakes decisions
- New capabilities
- Disagreement between methods

## טמפלט למדידה

```yaml
metric:
  name: "Task Success Rate"
  definition: "% משימות שהושלמו בהצלחה"
  target: ">80%"
  measurement:
    method: "automated"
    frequency: "every_run"
    
metric:
  name: "Cost Per Task"
  definition: "עלות טוקנים למשימה מוצלחת"
  target: "<$0.50"
  measurement:
    method: "token_tracker"
    frequency: "real_time"
    
metric:
  name: "Human Intervention Rate"
  definition: "% פעמים שנדרשה התערבות אנושית"
  target: "<5%"
  measurement:
    method: "hitl_logs"
    frequency: "weekly"
```

## Dashboard פשוט

```
┌─────────────────────────────────────┐
│  Agent Performance Dashboard      │
├─────────────────────────────────────┤
│                                     │
│  Success Rate:    87%  ████████░   │
│  Cost/Task:       $0.32  ✅         │
│  Avg Time:        2.3m   ✅         │
│  HITL Rate:       4%     ✅         │
│                                     │
│  Last 7 Days:                       │
│  ████████████████████░░░  78%      │
│                                     │
│  Trend: ↗️ Improving                │
└─────────────────────────────────────┘
```

## Benchmarks לפי שימוש

| שימוש | Benchmark | יעד |
|-------|-----------|-----|
| חיפוש | Pass@1 | >70% |
| כתיבה | Human eval | >4/5 |
| קוד | SWE-bench | >60% |
| מחשב | OSWorld | >50% |
| שיחה | MT-bench | >8 |
| סוכן כללי | APEX | >30% |

---

*מבוסס על Stanford AI Index 2026 + Production benchmarks*
