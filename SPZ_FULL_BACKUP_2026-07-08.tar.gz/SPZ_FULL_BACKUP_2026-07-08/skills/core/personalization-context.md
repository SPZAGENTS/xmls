---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: personalization-context
version: "1.0.0"
description: פרסונליזציה והתאמה ל-context משתמש - memory, user profiles, והתאמה דינמית
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - personalization
  - user context
  - פרסונליזציה
  - התאמה
metadata:
  openclaw:
    emoji: "👤"
    tags: [personalization, user, context, memory, adaptation]
---

# 👤 Personalization & Context Adaptation

> **Memory is the "final unlock" for effective agents**
> 
> 2025 = inflection point for personalization

## למה פרסונליזציה חשובה?

### הבעיה:
```
Agents without memory:
├── Generic outputs
├── Repeated questions
├── No learning
└── Poor UX
```

### הפתרון:
```
Agents with memory:
├── Tailored responses
├── Context awareness
├── Continuous learning
└── Excellent UX
```

---

## סוגי Memory לפרסונליזציה

### 1. User Profiles
```json
{
  "user_id": "user_123",
  "preferences": {
    "language": "hebrew",
    "tone": "professional",
    "detail_level": "high"
  },
  "history": {
    "common_tasks": ["research", "coding"],
    "success_patterns": ["step-by-step", "examples"]
  },
  "constraints": {
    "max_cost_per_action": 0.5,
    "preferred_models": ["claude", "gpt-4"]
  }
}
```

### 2. Episodic Memory
```python
# אינטראקציות אחרונות
recent_interactions = [
    {"timestamp": "...", "query": "...", "response": "..."},
    # Last 10-20 interactions
]
```

### 3. Semantic Memory
```python
# ידע כללי על המשתמש
user_knowledge = vector_db.search(
    "user_preferences",
    top_k=10
)
```

### 4. Procedural Memory
```python
# איך המשתמש עובד
workflow_patterns = {
    "morning_routine": ["check_email", "calendar", "news"],
    "coding_style": "test-driven",
    "communication": "concise"
}
```

---

## Frameworks לפרסונליזציה

### PAHF (Meta)
**Pre-action Human Feedback:**
```
1. Pre-action: clarification
2. Grounding: user memory
3. Post-action: updates

Handles: cold-start + preference drift
Benchmarks: shopping, embodied tasks
```

### TIPO
**Mobile GUI Agents:**
```
Privacy-focused personalization
Trajectory optimization
Aligns personas with tasks
```

### Weaviate Personalization Agent
**Recommenders:**
```python
# Uses:
# - User persona
# - Interactions (likes/dislikes)
# - Custom instructions

personalized_results = weaviate.search(
    query="...",
    user_persona=user_profile,
    interactions=user_history
)
```

### Supermemory User Profiles API
**Real-time personalization:**
```python
# Memory as "must-know" facts
# Agents learn and grow

profile = supermemory.get_profile(user_id)
profile.update(interaction)
```

---

## יישום מעשי

### שלב 1: איסוף נתונים
```python
def collect_user_data(interaction):
    return {
        "query": interaction.query,
        "context": interaction.context,
        "feedback": interaction.feedback,
        "timestamp": interaction.time
    }
```

### שלב 2: עיבוד והבנה
```python
def process_user_data(raw_data):
    # Extract preferences
    preferences = extract_preferences(raw_data)
    
    # Identify patterns
    patterns = identify_patterns(raw_data)
    
    # Update profile
    return update_profile(preferences, patterns)
```

### שלב 3: שימוש בפרסונליזציה
```python
def personalize_response(response, user_profile):
    # Adjust tone
    tone = user_profile["preferences"]["tone"]
    
    # Adjust detail level
    detail = user_profile["preferences"]["detail_level"]
    
    # Add context from memory
    context = get_relevant_memory(user_profile["user_id"])
    
    return format_response(response, tone, detail, context)
```

---

## יישומים עסקיים

### Retail/E-commerce
```
Hyper-personalization:
├── 66% accuracy gains
├── Proactive agents
└── Increased lock-in
```

### Sales/Marketing
```
Agents build 50+ personalization points:
├── LinkedIn profiles
├── News mentions
└── 18% reply rates
```

### Web3/Autonomy
```
Personalized fleets per user
NFT-linked identities
```

---

## Best Practices

### Privacy:
```python
# Nillion - blind computation
# OptimAI - privacy-preserving

sensitive_data = encrypt(user_data)
result = compute_on_encrypted(sensitive_data)
```

### Cold Start:
```python
# PAHF approach
if new_user:
    ask_clarifying_questions()
    build_profile_gradually()
else:
    use_existing_profile()
```

### Preference Drift:
```python
# Detect changes
if preference_changed(recent_interactions):
    update_profile()
    notify_user()
```

### Feedback Loops:
```python
@after_response
def collect_feedback(response, user_id):
    feedback = ask_user("Was this helpful?")
    update_profile(user_id, feedback)
```

---

## Checklist לפרסונליזציה

- [ ] User profile API
- [ ] Episodic memory
- [ ] Semantic memory
- [ ] Procedural memory
- [ ] Privacy controls
- [ ] Feedback loops
- [ ] Cold-start handling
- [ ] Preference drift detection
- [ ] Multi-modal (text/audio/video)
- [ ] Cross-device sync

---

## Bottom Line

**Personalization = Memory + Context + Adaptation**

- Memory = final unlock
- Continuous learning
- Privacy first
- User-growing systems

**2025 = השנה של הפרסונליזציה**

---

*מבוסס על Meta PAHF + Supermemory + Weaviate + 2025 research*
