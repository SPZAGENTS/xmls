---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: checkpoint-recovery
version: "1.0.1"
description: מערכת checkpoints ושחזור מכישלונות - idempotency ו-retry logic
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - checkpoint
  - שחזור
  - retry
  - idempotency
metadata:
  openclaw:
    emoji: "💾"
    tags: [checkpoint, recovery, retry, resilience, idempotency]
---

# 💾 Checkpoints ושחזור

## למה צריך?
**88-95% מהסוכנים נכשלים בייצור** - בגלל חוסר יכולת להתאושש

## עקרונות 12-Factor Agents

| Factor | משמעות |
|--------|--------|
| Unify execution & business state | שמור state משותף לשחזור |
| Launch/Pause/Resume APIs | hooks פשוטים לשחזור |
| Compact errors into context | הזן כשלים חזרה ל-self-retry |
| Stateless reducer | צעדי idempotency |
| Small, focused agents | סיבולת כשלון ב-multi-agent |

## מערכת Checkpoints

### מתי לשמור?
```
לפני פעולה בלתי הפיכה
    ↓
אחרי כל שלב מרכזי
    ↓
אחרי קריאת API חיצונית
    ↓
כשמתקרבים לגבול זמן/טוקנים
```

**תדירות אדפטיבית:**
- יותר often אחרי פעולות בלתי הפיכות
- פחות often אחרי קריאות לקריאה בלבד

### מבנה Checkpoint

```json
{
  "checkpoint_id": "uuid",
  "timestamp": "2026-04-19T08:30:00Z",
  "task_id": "task_001",
  "step": 3,
  "state": {
    "conversation_history": [...],
    "tool_outputs": {...},
    "cursor_position": "line 45",
    "partial_results": {...}
  },
  "irreversible_actions": [
    {"action": "api_call", "status": "completed", "idempotency_key": "abc123"}
  ],
  "metadata": {
    "tokens_used": 15000,
    "cost_so_far": 1.23,
    "estimated_remaining": 0.5
  }
}
```

## Idempotency (אידמפוטנטיות)

### מה זה?
**אותו קלט → אותה תוצאה, אין side effects נוספים**

**Idempotent:**
```
DELETE /resource/123 → 204 (מחוק)
DELETE /resource/123 → 204 (כבר מחוק, אותה תוצאה)
```

**Not Idempotent:**
```
POST /charge → $100 (חיוב ראשון)
POST /charge → $100 (חיוב שני - בעיה!)
```

### Retry Logic

**Exponential Backoff + Jitter:**
```python
wait = (2 ** attempt) + random.uniform(0, 1)  # 1s, 2s, 4s, 8s...
```

**AI-Specific Retries:**
- LLM-as-judge לבדיקת איכות
- Parallel rollouts - 3 ניסיונות במקביל
- Circuit breaker - עצור אחרי 5 כשלים

## Circuit Breaker Pattern

```
CLOSED → פתוח (עובד)
    ↓ 5 כשלים
OPEN → סגור (חסום ל-60 שניות)
    ↓ timeout
HALF_OPEN → בודק אם שב לעבוד
    ↓ הצלחה
CLOSED
```

---

*מבוסס על 12-Factor Agents + Temporal*
