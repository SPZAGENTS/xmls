---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: knowledge-wiki
version: "1.0.0"
description: Knowledge Wiki ו-Documentation - ניהול ידע לסוכני AI
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - wiki
  - documentation
  - knowledge base
  - documentation
metadata:
  openclaw:
    emoji: "📖"
    tags: [wiki, documentation, knowledge, docs]
---

# 📖 Knowledge Wiki & Documentation

> **From static docs to agentic knowledge systems**
> 
> "Where is the documentation?" → "Where is the AI agent?"

## המהפכה

### 2024 vs 2025:
```
2024:
├── Static documentation
├── Manual updates
├── Human-readable only
└── Siloed knowledge

2025:
├── Agent-maintained wikis
├── Auto-generated updates
├── Machine-readable
└── Collaborative knowledge graphs
```

---

## Knowledge Wiki Structure

### 1. Markdown-Based

**Format:**
```markdown
---
name: topic-name
version: "1.0.0"
description: Clear description
tags: [tag1, tag2]
---

# Topic Name

> Key insight here

## Section 1
Content...

## Section 2
Content...

---

*Last updated: 2025-01-01*
```

**Benefits:**
- Human-readable
- Machine-parseable
- Version controllable
- Searchable

---

### 2. Progressive Disclosure

**Structure:**
```
index.md
├── Overview
├── Quick links
└── Navigation

content/
├── topic-a.md
├── topic-b.md
└── topic-c.md

mocs/
├── map-of-content-a.md
└── map-of-content-b.md
```

**Access pattern:**
```
Index → MOC → Topic → Details
  ↓       ↓       ↓        ↓
High   Medium   Low    Lowest
level  level    level  level
```

---

### 3. Wikilinks & Relationships

```markdown
[[related-topic]]
[[specific-section#heading]]

# Creates graph:
Topic A ←→ Topic B ←→ Topic C
   ↓              ↓
Topic D ←→ Topic E
```

**Benefits:**
- Discoverability
- Context preservation
- Knowledge graph

---

## Agent Integration

### Global Knowledge Skills:
```python
# Any agent can access
@skill("/knowledge-[team]", query)
def search_team_knowledge(query):
    """
    Searches team wiki for relevant information
    Reduces context by 90%
    """
    return wiki.search(query, top_k=10)
```

### Auto-Generation:
```python
class DocumentationAgent:
    def generate_docs(self, code):
        """Auto-generate documentation from code"""
        return llm.generate(f"Document this: {code}")
    
    def update_wiki(self, changes):
        """Update wiki based on changes"""
        affected_pages = self.find_affected_pages(changes)
        for page in affected_pages:
            self.update_page(page, changes)
```

---

## Tools & Stacks

### Wiki Tools:
| Tool | Purpose |
|------|---------|
| Obsidian | Personal/team wikis |
| qmd | Hybrid BM25 + vector search |
| Mem0 | Persistent agent memory |
| Aidbase | UI-based RAG |
| Neon DB | Structured storage |

### Documentation:
| Tool | Purpose |
|------|---------|
| LlamaIndex | Agentic PDFs |
| Firecrawl | Web ingestion |
| HelpNDoc | Auto-generate docs |
| Manus | Documentation agent |

### Search:
| Tool | Purpose |
|------|---------|
| Perplexity | AI search |
| Exa | Neural search |
| Google Agent Skills | L1-L3 layers |

---

## Implementation

### Wiki Setup:
```python
class AgentWiki:
    def __init__(self, path):
        self.path = path
        self.index = self.load_index()
        self.graph = self.build_graph()
    
    def load_index(self):
        """Load index.md"""
        return parse_markdown(f"{self.path}/index.md")
    
    def build_graph(self):
        """Build wikilink graph"""
        graph = {}
        for file in self.get_all_files():
            links = extract_wikilinks(file)
            graph[file] = links
        return graph
    
    def search(self, query):
        """Hybrid BM25 + vector search"""
        bm25_results = self.bm25_search(query)
        vector_results = self.vector_search(query)
        return self.merge_results(bm25_results, vector_results)
```

### Maintenance:
```python
class WikiMaintenance:
    def lint(self):
        """Check for issues"""
        orphans = self.find_orphans()
        broken_links = self.find_broken_links()
        stale_content = self.find_stale_content()
        
        return {
            "orphans": orphans,
            "broken_links": broken_links,
            "stale": stale_content
        }
    
    def auto_update(self):
        """Auto-update based on changes"""
        changes = self.detect_changes()
        for change in changes:
            self.propagate_updates(change)
```

---

## Multi-Agent Wikis

### Shared Knowledge:
```
Team Wiki:
├── 8 agents
├── 571 files
└── Compounding knowledge via cross-links

Pattern:
Personal notebook → Team wiki → Organization wiki
```

### Benefits:
- Knowledge sharing
- Reduced duplication
- Collective intelligence
- Onboarding acceleration

---

## Best Practices

### Do:
- ✅ Small nodes (one idea/file)
- ✅ YAML frontmatter
- ✅ Wikilinks for relationships
- ✅ MOCs for navigation
- ✅ Auto-generation where possible
- ✅ Regular linting

### Don't:
- ❌ Large monolithic docs
- ❌ Orphaned pages
- ❌ Broken links
- ❌ Stale content
- ❌ Manual updates only

---

## 2026 Trends

### What's Coming:
```
- "Where is the AI agent?" vs "Where is the documentation?"
- Auto-generated docs standard
- Agent-maintained wikis
- Transferable blueprints
- Knowledge graphs
```

---

## Bottom Line

**Documentation = Living System**

- Agent-maintained
- Auto-updated
- Collaborative
- Searchable

**"Documentation that maintains itself"**

---

*מבוסס על 2025 knowledge wiki practices + Obsidian/qmd patterns*
