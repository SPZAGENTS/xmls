---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: api-integration
version: "1.0.0"
description: אינטגרציית APIs ושירותי צד שלישי - connectors, protocols, ו-authentication
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - API
  - integration
  - connector
  - third-party
metadata:
  openclaw:
    emoji: "🔌"
    tags: [api, integration, connector, third-party]
---

# 🔌 API Integration

> **80% of agent work = logic, not infra**
> 
> MCP standardizes connections

## המהפכה ב-2025

### מ-Custom Code לסטנדרטים:
```
Before:
├── Custom integrations
├── Brittle code
├── High maintenance
└── Slow development

After:
├── MCP standard
├── Pre-built connectors
├── Low maintenance
└── Fast development
```

---

## MCP (Model Context Protocol)

### מה זה:
**Standard for AI agents to connect to external tools**

**Use cases:**
- Cross-chain execution
- Browser control
- Databases
- APIs

**Examples:**
```
Salesforce Headless 360:
├── Exposes APIs/MCP
├── For Agentforce
└── Unified access

Cloudflare Enterprise MCP:
├── Secure governance
├── Managed connections
└── Enterprise-ready

Google Chrome DevTools:
├── Via MCP
├── Agent debugging
└── Full access
```

---

## Pre-Built Connector Platforms

### Composio
```
Features:
├── 250+ integrations
├── Handles retries
├── Auth management
├── Payments
└── Production-ready

Use: Quick integrations
```

### n8n
```
Visual workflows:
├── 700+ apps
├── No-code/low-code
├── MCP support
└── Self-hosted option

Use: Workflow automation
```

### InferenceAI
```
Universal AI provider gateway:
├── Multiple providers
├── Unified interface
├── Cost optimization
└── Fallback handling
```

---

## Frameworks & Orchestrators

### Multi-Agent Logic:
- **CrewAI** - Role-based teams
- **LangGraph** - Stateful workflows
- **AutoGen** - Conversational agents

### Kubernetes-Native:
- **KAOS** - Scales with MCP
- **Dapr** - Distributed runtime

### Observability:
- **AgentOps** - Debugging
- **LangSmith** - Tracing

---

## Top Connectors 2025

### APIs/Tools:
| Tool | Use |
|------|-----|
| Composio | 250+ apps |
| Stripe | Payments |
| deBridge MCP | Cross-chain |

### Browsers/Computer:
| Tool | Use |
|------|-----|
| Browserbase | Headless automation |
| OpenInterpreter | Terminal control |
| dev-browser | Playwright sandbox |

### Memory/DB:
| Tool | Use |
|------|-----|
| Mem0 | State persistence |
| Neon | Serverless Postgres |
| Google MCP Toolbox | 20+ DBs |

### Search:
| Tool | Use |
|------|-----|
| Firecrawl | Web scraping |
| Perplexity | AI search |
| Exa | Neural search |

### Monitoring:
| Tool | Use |
|------|-----|
| AgentOps | Debugging |
| Langfuse | Tracing |

---

## Enterprise Solutions

### Coinbase:
```
Testing Slack/email agents
Production experimentation
```

### Cloudflare:
```
OpenAI Agent Cloud
├── Secure hosting
├── Global scale
└── Enterprise features
```

### Salesforce:
```
APIs for agents
├── Headless 360
├── MCP native
└── Agentforce integration
```

### X API:
```
"Owned Reads" - cheap access
Agent-friendly pricing
Social data
```

---

## Implementation

### Basic MCP:
```python
# Server
from mcp import Server

server = Server("my-tools")

@server.tool()
def search(query: str) -> str:
    return web_search(query)

@server.tool()
def calculate(expression: str) -> float:
    return eval(expression)

server.run()
```

```python
# Client
from mcp import Client

client = Client("my-tools")

# Discover
tools = client.list_tools()

# Use
result = client.call_tool("search", {"query": "weather"})
```

### Composio Integration:
```python
from composio import Composio

client = Composio(api_key="...")

# Connect to GitHub
github = client.get_integration("github")

# Use in agent
@agent.tool
def create_issue(title: str, body: str):
    return github.create_issue(title, body)
```

---

## Authentication

### Patterns:
```python
# OAuth 2.0
@oauth_required
 def use_api():
     token = get_valid_token()
     return api.call(token)

# API Keys
@api_key_required
 def use_service():
     key = get_api_key()
     return service.call(key)

# Token Refresh
@auto_refresh
 def long_running_task():
     # Handles expiration
     return api.long_operation()
```

---

## Error Handling

### Retry Logic:
```python
@retry(max_attempts=3, backoff=2)
def api_call():
    try:
        return api.request()
    except RateLimit:
        wait_and_retry()
    except ServerError:
        fallback()
```

### Fallbacks:
```python
def resilient_call():
    try:
        return primary_api()
    except:
        try:
            return secondary_api()
        except:
            return cached_result()
```

---

## Best Practices

### Do:
- ✅ Use MCP standard
- ✅ Implement retries
- ✅ Handle auth
- ✅ Monitor costs
- ✅ Cache results

### Don't:
- ❌ Build custom integrations
- ❌ Hardcode credentials
- ❌ Ignore rate limits
- ❌ Skip error handling
- ❌ Forget fallbacks

---

## Challenges Solved

### Before MCP:
```
"Plumbing" fails:
├── Broken connectors
├── Expired tokens
├── Rate limits
└── 80% of work
```

### After MCP:
```
Standardized:
├── Reliable connections
├── Managed auth
├── Automatic retries
└── 20% of work
```

---

## Bottom Line

**Standards > Custom**

- MCP = Universal connector
- Pre-built > Build
- Reliable > Brittle

**"Focus on logic, not plumbing"**

---

*מבוסס על MCP standard + Composio/n8n + 2025 integration practices*
