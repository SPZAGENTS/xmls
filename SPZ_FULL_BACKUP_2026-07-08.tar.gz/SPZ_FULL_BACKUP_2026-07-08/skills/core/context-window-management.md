---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: context-window-management
version: "1.0.0"
description: ניהול חלון context ו-token limits - optimization, compression, ו-engineering
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - context window
  - token limits
  - context management
  - חלון context
metadata:
  openclaw:
    emoji: "📏"
    tags: [context, window, tokens, limits, compression, optimization]
---

# 📏 Context Window Management

> **Context engineering = Job #1 for AI agent builders**
> 
> Bigger isn't always better

## הבעיה

### Context Rot:
```
Long context → Degradation
├── Information overload
├── Attention dilution
└── Performance drops
```

### Context Poisoning:
```
Bad info → Compounds
├── Wrong assumptions
├── Cascading errors
└── Recovery difficult
```

### Token Costs:
```
32K window stuffed with history = $$$
├── Expensive
├── Wasteful
└── Unsustainable
```

---

## המצב 2025-2026

### Window Sizes:
| Model | Tokens |
|-------|--------|
| Qwen2.5 | 1M |
| Claude | 1M+ |
| GPT-5.2 | 400K |
| Recursive LM | 10M+ |

**But bigger ≠ better!**

### Production Reality:
```
57% of companies run agents
Failures stem from poor context
Context engineering > prompt engineering
```

---

## אסטרטגיות מרכזיות

### 1. Truncate & Set Limits

**Max tokens enforcement:**
```python
MAX_CONTEXT_TOKENS = 4000

def enforce_limit(context):
    if count_tokens(context) > MAX_CONTEXT_TOKENS:
        return truncate(context, MAX_CONTEXT_TOKENS)
    return context
```

**Circuit breakers for retention:**
```python
@circuit_breaker(threshold=5)
def add_to_context(new_info):
    if context_full():
        return False
    context.append(new_info)
    return True
```

---

### 2. Prune, Summarize, Compress

**Regular scanning:**
```python
def maintain_context(context):
    # Remove duplicates
    context = remove_duplicates(context)
    
    # Remove outdated
    context = remove_outdated(context, ttl=3600)
    
    # Compress if needed
    if too_large(context):
        context = summarize(context)
    
    return context
```

**LLM reflection for importance:**
```python
def score_importance(item):
    prompt = f"Rate importance 1-10: {item}"
    score = llm.generate(prompt)
    return int(score)

def keep_important_only(context, top_k=100):
    scored = [(item, score_importance(item)) for item in context]
    scored.sort(key=lambda x: x[1], reverse=True)
    return [item for item, _ in scored[:top_k]]
```

**Hierarchical layers (95% reduction):**
```
Layer 1: Summary (10%)
Layer 2: Timeline (30%)
Layer 3: Details (60%)

Access pattern:
Summary first → Timeline if needed → Details if critical
```

---

### 3. Selective Retrieval (RAG/Memory)

**Prioritize retrieval over storage:**
```python
def get_context(query):
    # Don't store everything
    # Retrieve on demand
    
    relevant = vector_db.search(query, top_k=10)
    reranked = rerank(relevant, query)
    return reranked
```

**Task-tailored memory:**
```python
MEMORY_TYPES = {
    "episodic": get_recent_history,
    "semantic": get_facts,
    "procedural": get_workflows
}

def get_appropriate_memory(task):
    if task.type == "creative":
        return MEMORY_TYPES["episodic"]()
    elif task.type == "factual":
        return MEMORY_TYPES["semantic"]()
    elif task.type == "repetitive":
        return MEMORY_TYPES["procedural"]()
```

**Filter tools/memories:**
```python
@filter_relevant
def retrieve_tools(query):
    all_tools = get_available_tools()
    return [t for t in all_tools if is_relevant(t, query)]
```

---

### 4. Multi-Agent & Isolation

**Split into sub-agents:**
```python
# Instead of one agent with huge context
# Use multiple agents with fresh windows

orchestrator = Agent(window_size=4000)
workers = [Agent(window_size=4000) for _ in range(5)]

result = orchestrator.divide_and_conquer(task, workers)
```

**Task decomposition:**
```python
def decompose_task(task):
    subtasks = break_down(task)
    
    for subtask in subtasks:
        agent = Agent(fresh_window=True)
        result = agent.execute(subtask)
        results.append(result)
    
    return combine(results)
```

---

### 5. Externalize Context

**Scratchpads:**
```python
# Write out thoughts
scratchpad = []

def think(step):
    thought = agent.reason(step)
    scratchpad.append(thought)
    return thought

def get_scratchpad():
    return "\n".join(scratchpad)
```

**State objects (Pydantic):**
```python
from pydantic import BaseModel

class AgentState(BaseModel):
    current_task: str
    context: str
    memory_refs: List[str]
    
# Offload from context to state
state = AgentState(
    current_task=task,
    context=retrieve_on_demand(),
    memory_refs=["mem_1", "mem_2"]
)
```

**Recursive Language Models (10M+ tokens):**
```python
# Recursive decomposition
class RecursiveLM:
    def process(self, text):
        if len(text) < CHUNK_SIZE:
            return self.model.generate(text)
        
        chunks = split(text)
        summaries = [self.process(c) for c in chunks]
        return self.process("\n".join(summaries))
```

---

### 6. Agentic Context Engineering

**The 4 Pillars:**

```python
class ContextEngineering:
    def write_out(self, context):
        """Pillar 1: Write out to scratchpads/LTM"""
        return offload_to_external(context)
    
    def select(self, query, sources):
        """Pillar 2: Select via RAG/tools/memories"""
        return retrieve_relevant(query, sources)
    
    def compress(self, context):
        """Pillar 3: Compress via summarization"""
        return summarize_hierarchical(context)
    
    def isolate(self, agent):
        """Pillar 4: Isolate via multi-agent/sandbox"""
        return create_fresh_window(agent)
```

---

### 7. Audit & Optimize

**Check utilization:**
```python
def audit_context_usage(context, references):
    """Check if <40% of context is referenced"""
    used_tokens = sum(count_tokens(r) for r in references)
    total_tokens = count_tokens(context)
    
    utilization = used_tokens / total_tokens
    
    if utilization < 0.4:
        log_warning(f"Low utilization: {utilization:.2%}")
        suggest_optimization()
```

**Prompt caching:**
```python
# Cache repeated prefixes
@cache
def get_system_prompt():
    return load_system_prompt()

# Only send once
# Reference via cache key
```

---

## Best Practices

### Golden Rules:
1. ✅ **Relevance > Size** - Quality over quantity
2. ✅ **Retrieve > Store** - On-demand loading
3. ✅ **Summarize > Keep** - Compression
4. ✅ **Isolate > Share** - Fresh windows
5. ✅ **Measure > Guess** - Track utilization

### Anti-Patterns:
- ❌ Stuffing everything into context
- ❌ Never clearing old info
- ❌ No compression
- ❌ Monolithic agents
- ❌ Ignoring costs

---

## Tools & Frameworks

### Elysia
```
Context management for agents
Built-in compression
Efficient retrieval
```

### Letta
```
Memory management
State externalization
Long-term persistence
```

### RLM Implementations
```
Recursive Language Models
10M+ effective tokens
Decomposition-based
```

---

## Bottom Line

**Context Engineering = Critical Skill**

- Optimize relentlessly
- Measure utilization
- Compress aggressively
- Isolate intelligently

**"The main limit is context, not model quality"**

---

*מבוסס על Cognition, Karpathy, Weaviate + 2025 context engineering*
