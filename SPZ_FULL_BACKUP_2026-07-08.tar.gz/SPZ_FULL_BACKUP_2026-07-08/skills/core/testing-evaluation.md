---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: testing-evaluation
version: "1.0.0"
description: Testing ו-Evaluation - בדיקות ובENCHMARKים לסוכני AI
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - testing
  - evaluation
  - benchmark
  - metrics
metadata:
  openclaw:
    emoji: "🧪"
    tags: [testing, evaluation, benchmark, metrics]
---

# 🧪 Testing & Evaluation

> **2025: From simple benchmarks to complex, long-horizon tasks**
> > Reasoning models dominate, coding agents near human-level

## המהפכה בבENCHMARKים

### 2024 vs 2025:
```
2024:
├── Static benchmarks
├── Short tasks
└── Academic focus

2025:
├── Production-like tasks
├── Long-horizon (hours)
├── Real-world applicability
└── Tool use + reasoning
```

### Benchmark Saturation:
```
"Clean tasks no longer reflect messy production realities"

Solution: Messy benchmarks that mirror real-world complexity
```

---

## מBENCHMARKים מובילים 2025

### 1. SWE-bench Family

**Gold Standard for Coding:**
```
SWE-bench: ~60% → 100%
SWE-bench Verified: Near-100%
SWE-bench Pro: 73-74%

Top Models:
- Claude Opus 4.5: 45-58%
- GPT-5.4: 58% (TerminalBench Hard)
```

**What it measures:**
- Real GitHub issue resolution
- Pull request generation
- Production code fixes

---

### 2. APEX-Agents (Mercor)

**Long-Horizon Professional Tasks:**
```
Domains:
├── Investment banking
├── Consulting
├── Law
└── 452 total tasks

Tools:
├── Spreadsheets
├── Documents
└── Real work tools

Scoring: Pass@1 via LLM judge

Top 2026:
- GPT-5.4: 33.3%
- Claude Opus 4.6: 33%
- Gemini 3.1 Pro: 32%
```

---

### 3. Galileo AI Agent Leaderboard

**Task Success Quality (TSQ):**
```
April 2025:
- Claude 3.7 Sonnet: 0.953
- Gemini 2.5 Pro: 0.941
- Llama 4: 0.741 (lagging)

Value: Gemini cheaper per quality point
```

---

### 4. OSWorld

**Real Computer Tasks:**
```
2024: 12%
2026: 66%

Improvement: 5.5x
```

**Tasks:**
- File management
- Web browsing
- Application use
- Multi-step workflows

---

### 5. AlphaEval

**Production-Grounded:**
```
Source: 94 tasks from 7 companies
Features:
├── Multimodal
├── Expert judgment
├── LLM-judge
├── Rubrics
└── UI testing
```

---

## BENCHMARKים נוספים

| Benchmark | Domain | Top Score | Notes |
|-----------|--------|-----------|-------|
| DSBench | Biomedical | - | Python/R reprod. science |
| ARC-AGI-2 | Reasoning | <30% | Abstract reasoning |
| FrontierMath | Math | 29% | Hard problems |
| METR | Time horizons | 12-14hr | Long tasks |
| CritPt | Physics | 20% | Complex physics |
| HLE | General | 60% | Human-level evals |
| MMMU-Pro | Multimodal | 83-92% | Vision + language |
| CAIA | Crypto | - | Crypto agents |
| BoxPwnr | Security | - | Pentesting |

---

## מדדים חשובים

### Core Metrics:
```python
METRICS = {
    "task_success_rate": "% completed successfully",
    "step_accuracy": "% correct per step",
    "tool_use_accuracy": "% correct tool selection",
    "latency": "Time to completion",
    "cost": "Total tokens/spend",
    "hallucination_rate": "% false claims",
    "recovery_rate": "% self-corrected"
}
```

### Production Metrics:
```python
PRODUCTION_METRICS = {
    "availability": "Uptime %",
    "error_rate": "Errors per 1000",
    "user_satisfaction": "NPS/CSAT",
    "cost_per_task": "$ per completion",
    "escalation_rate": "% to human"
}
```

---

## Evaluation-Driven Development (EDD)

### The Process:
```
1. Define task suite
2. Run agent
3. Evaluate results
4. Identify failures
5. Fix root causes
6. Iterate
```

### Implementation:
```python
class EvaluationDrivenDevelopment:
    def __init__(self):
        self.test_suite = load_tests()
        self.metrics = []
    
    def evaluate(self, agent):
        results = []
        for test in self.test_suite:
            result = agent.run(test.input)
            evaluation = self.score(result, test.expected)
            results.append(evaluation)
        
        return self.aggregate(results)
    
    def score(self, result, expected):
        return {
            "exact_match": result == expected,
            "llm_judge": llm_as_judge(result, expected),
            "human_review": human_eval(result, expected)
        }
    
    def gate_release(self, results):
        if results.success_rate > 0.95:
            return "PRODUCTION"
        elif results.success_rate > 0.80:
            return "CANARY"
        else:
            return "REJECTED"
```

---

## LLM-as-Judge

### Implementation:
```python
def llm_as_judge(prediction, expected):
    prompt = f"""
    Rate the quality of this prediction vs expected:
    
    Prediction: {prediction}
    Expected: {expected}
    
    Score 1-10, explain why.
    """
    
    result = llm.generate(prompt)
    return parse_score(result)
```

### Benefits:
- Scalable evaluation
- Consistent criteria
- Cost-effective

### Caveats:
- May have biases
- Needs calibration
- Human spot-checking required

---

## Best Practices

### Do:
- ✅ Production-like tasks
- ✅ Long-horizon testing
- ✅ Tool use evaluation
- ✅ LLM-as-judge + human review
- ✅ Continuous evaluation
- ✅ Track metrics over time

### Don't:
- ❌ Academic benchmarks only
- ❌ Short tasks exclusively
- ❌ No tool evaluation
- ❌ Skip human validation
- ❌ Evaluate once
- ❌ Ignore edge cases

---

## 2026 Predictions

### What's Next:
```
- Benchmark saturation on basics
- Focus on governance evals
- Continuous learning metrics
- Multi-agent swarm benchmarks
- Real-world task complexity
```

---

## Bottom Line

**Evaluation = Foundation**

- Complex benchmarks
- Long-horizon tasks
- Production realism
- Continuous improvement

**"Evaluate like it's production"**

---

*מבוסס על 2025 benchmarks + SWE-bench + APEX-Agents*
