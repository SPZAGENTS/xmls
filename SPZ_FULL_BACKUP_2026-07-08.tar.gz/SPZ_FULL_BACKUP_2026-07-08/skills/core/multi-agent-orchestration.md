---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: multi-agent-orchestration
version: "1.0.0"
description: 5 דפוסי תזמור multi-agent - מאורגן עד אוטונומי
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - multi-agent
  - orchestration
  - coordination
  - צוות
metadata:
  openclaw:
    emoji: "👥"
    tags: [multi-agent, orchestration, coordination, teams]
---

# 👥 Multi-Agent Orchestration

> **היררכיות נוקשות נחותות ב-14%** מארגון עצמי במודלים חזקים
> 
> אבל: מודלים חלשים צריכים מבנה!

## 5 דפוסי תזמור מרכזיים

### 1. Orchestrator-Subagent (Supervisor) 👨‍💼
**הכי מומלץ לרוב המקרים**

```
┌─────────────┐
│ Orchestrator │ ← מקבל משימה, מחלק לתת-משימות
└──────┬──────┘
       │
   ┌───┴───┐
   │       │
┌──┴──┐ ┌──┴──┐
│Sub 1│ │Sub 2│ ← מומחים בנושאים ספציפיים
│     │ │     │
└──┬──┘ └──┬──┘
   │       │
   └───┬───┘
       │
┌──────┴──────┐
│ Synthesizer │ ← מרכיב תוצאות
└─────────────┘
```

**מתאים ל:**
- מרבית מקרי הייצור
- צוותים ברורים
- תזמור פשוט

**יתרונות:**
- שליטה ברורה
- קל לניפוי באגים
- scalable

**חסרונות:**
- צוואר בקבוק במפקד
- פחות גמיש

---

### 2. Generator-Verifier 🎨✅
**אחד יוצר, השני בודק**

```
Generator Agent → יוצר output
       ↓
Verifier Agent → בודק איכות
       ↓
    [אישור] → סיים
    [דחה] → חזור ל-generator
```

**מתאים ל:**
- קוד (כתיבה + review)
- תוכן (יצירה + עריכה)
- ניתוח (ממצאים + ביקורת)

**יתרונות:**
- איכות גבוהה
- בטיחות

**חסרונות:**
- איטי יותר
- עלות כפולה

---

### 3. Agent Teams 🤝
**צוות קבוע שמשתף פעולה**

```
┌─────────┐
│Researcher│ ← אוסף מידע
└────┬────┘
     │
┌────┴────┐
│ Writer  │ ← כותב
└────┬────┘
     │
┌────┴────┐
│ Editor  │ ← עורך
└─────────┘
```

**מתאים ל:**
- זרימות עבודה קבועות
- איטרציה והשתפרות
- שיתוף פעולה

**יתרונות:**
- מוכר ונוח
- מיטוב מתמשך

**חסרונות:**
- מחזוריות
- עלות גבוהה (5-6x יותר טוקנים!)

---

### 4. Message Bus 📡
**pub/sub לאירועים - מנותק**

```
Publisher 1 ──┐
Publisher 2 ──┼──→ [Message Bus] ←── Subscriber 1
Publisher 3 ──┤         ↑            Subscriber 2
              │         │            Subscriber 3
           Events    Topics
```

**מתאים ל:**
- נפח גבוה
- async
- scale גבוה

**יתרונות:**
- Loose coupling
- Scalable
- Resilient

**חסרונות:**
- מורכב
- קשה ל-debug

---

### 5. Shared State 🧠
**כולם קוראים/כותבים זיכרון משותף**

```
        ┌──────────────┐
Agent 1 │              │ Agent 2
   ↓    │ Shared State │    ↓
   write│              │read
        └──────────────┘
              ↑
Agent 3 ──────┘
   update
```

**מתאים ל:**
- תיאום דינמי
- למידה משותפת
- Emergence

**יתרונות:**
- גמישות מקסימלית
- יכולות מתפתחות

**חסרונות:**
- Race conditions
- קונפליקטים
- קשה לשלוט

---

## השוואת Frameworks

| Framework | דפוסים | חוזק | חולשה |
|-----------|--------|------|--------|
| **CrewAI** | Hierarchical, Sequential | Teams, handoffs | פחות flexible |
| **AutoGen** | Group chat, Iteration | שיחות | יקר (5-6x טוקנים) |
| **LangGraph** | הכל + DAGs | Production, debugging | תלול יותר |
| **Swarms** | Topologies | Scale, unified | חדש פחות mature |

---

## המלצת שימוש

### לפי מורכבות:

**פשוט (80%):**
→ Orchestrator-Subagent

**בינוני:**
→ Generator-Verifier
→ Agent Teams

**מורכב (20%):**
→ Message Bus
→ Shared State
→ Hybrid

---

## Production Pattern

**80% workflow + 20% autonomy**

```
┌─────────────────────────────────────┐
│ Workflow (LangGraph/CrewAI)         │ 80%
│ - צפוי                             │
│ - בטוח                             │
│ - מהיר                             │
├─────────────────────────────────────┤
│ Autonomy (Agent Teams)             │ 20%
│ - גמיש                             │
│ - יצירתי                           │
│ - לומד                             │
└─────────────────────────────────────┘
```

---

## מספרים חשובים

- **14%** - Self-organization מנצח hierarchy במודלים חזקים
- **5-6x** - AutoGen יותר טוקנים מ-LangGraph
- **80%** - Workflow עדיף על autonomy
- **1,445%** - עלייה בשאלות על swarms (Gartner)

---

*מבוסס על Anthropic + CrewAI + AutoGen + LangGraph best practices*
