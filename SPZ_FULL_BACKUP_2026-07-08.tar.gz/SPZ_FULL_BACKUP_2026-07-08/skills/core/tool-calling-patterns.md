---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: tool-calling-patterns
version: "1.0.0"
description: 21 דפוסי קריאת כלים (tool calling) לסוכני AI - מהבסיסי למתקדם
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - כלים
  - tools
  - function calling
  - API
metadata:
  openclaw:
    emoji: "🔧"
    tags: [tools, function-calling, patterns, API]
---

# 🔧 דפוסי Tool Calling

> **70% ממקרי ה-agent לא צריכים אוטונומיה מלאה** - התחל עם workflows פשוטים

## 4 דפוסי ליבה (Core)

### 1. Tool Use / Function Calling
**מה:** סוכן מחליט מתי להפעיל כלי
**פלט:** JSON מובנה לקריאת כלים מדויקת

```json
{
  "tool": "web_search",
  "arguments": {
    "query": "AI agent patterns 2025",
    "limit": 5
  }
}
```

**מתי להשתמש:**
- כל פעם שצריך מידע חיצוני
- חישובים מורכבים
- פעולות מערכת

**יתרונות:**
- מונע הזיות
- מדויק וניתן לבדיקה
- ניתן ל-debugging

---

### 2. Planning Pattern
**מה:** פירוק משימות לצעדים עם כלים דינמיים

```
משימה: "תקן באג בקוד"
    ↓
1. קרא את הקוד (read_file)
2. נתח את הבעיה (analyze_code)
3. הצע תיקון (generate_fix)
4. החל תיקון (edit_file)
5. בדוק (run_tests)
```

**מתי להשתמש:**
- משימות מורכבות
- דרושות הרבה צעדים
- צריך גמישות

---

### 3. Reflection Pattern
**מה:** סוכן מבקר את עצמו ומשתפר

```
יצר קוד
    ↓
הריץ tests (tool)
    ↓
נכשל? → תקן ונסה שוב
    ↓
הצליח? → המשך
```

**מתי להשתמש:**
- איטרציה ושיפור
- איכות חשובה
- יש זמן

---

### 4. Routing Pattern
**מה:** סיווג קלט וניתוב לכלי/סוכן המתאים

```python
def route_input(query):
    if is_code_query(query):
        return code_agent
    elif is_search_query(query):
        return search_agent
    elif is_math_query(query):
        return calculator_tool
    else:
        return general_agent
```

**מתי להשתמש:**
- מערכת עם כלים רבים
- צריך להתמחות
- חיסכון בטוקנים

---

## 17 דפוסים מתקדמים

### Prompt Chaining
שרשרת קריאות LLM שכל אחת מאכילה את הבאה

### Parallelization
קריאות כלים במקביל לחיסכון זמן

### Multi-Agent
כמה סוכנים משתפים פעולה

### Memory Management
זיכרון משותף בין קריאות

### MCP (Model Context Protocol)
פרוטוקול סטנדרטי לכלי סוכנים

### Generator-Verifier
אחד יוצר, השני בודק

### Orchestrator-Subagent
מפקד מנתב למומחים

### Agent Teams
צוות קבוע שמשתף פעולה

### Message Bus
pub/sub לאירועים

### Shared State
כולם קוראים/כותבים זיכרון משותף

### Sequential Pipeline
צינור עיבוד קבוע

### Concurrent Processing
עיבוד מקבילי

### Group Chat
דיון בין סוכנים

### Handoff
מעבר אחריות

### Self-Organization
מבנה מינימלי למודלים חזקים

### DAG Workflows
גרף א-ציקלי מכוון

### State Machines
מכונת מצבים מוגדרת

---

## Best Practices 2025

### 1. Schema Design
```yaml
description: "מתי לקרוא, פרמטרים, preconditions"
strict_mode: true
json_schema: full
```

### 2. אמינות
- כלי idempotent (בטוח לנסות שוב)
- guardrails עם Pydantic
- checkpointing
- HITL לפעולות רגישות

### 3. חשיבה כמו סוכן
- הגבל context (10-20k טוקנים)
- כלים כמו CLI
- outputs עשירים ב-signal
- שגיאות ברורות

### 4. בחירת מודל
- מודלי reasoning (o3, Claude Opus) לתכנון
- מודלי fast לחזרה
- parallel calls לחיסכון
- trajectory caching

---

## Frameworks 2025-2026

| Framework | חוזק | דפוסים | מתאים ל |
|-----------|------|--------|---------|
| **CrewAI** | Role-based teams | Hierarchical, sequential | תוכן, מחקר |
| **AutoGen** | שיחות multi-agent | Group chat, iteration | קוד, שיתוף פעולה |
| **LangGraph** | Stateful, checkpoints | הכל + DAGs | Enterprise |
| **Swarms** | Interface מאוחד | Topologies גמישים | Scale |

---

## Checklist: מתי להשתמש בסוכן?

✅ מורכבות גבוהה
✅ כל תת-משימה אפשרית
✅ עלות שגיאה נמוכה
✅ צריך גמישות

❌ משימה פשוטה וקבועה
❌ עלות שגיאה גבוהה
❌ צריך 100% דטרמיניזם

---

*מבוסס על Google DeepMind + Anthropic + Production best practices*
