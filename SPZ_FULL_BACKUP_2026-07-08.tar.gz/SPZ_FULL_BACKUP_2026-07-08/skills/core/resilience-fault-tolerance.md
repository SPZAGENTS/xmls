---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: resilience-fault-tolerance
version: "1.0.0"
description: Resilience ו-fault tolerance - circuit breakers, error handling, והתאוששות מכשלים
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - resilience
  - fault tolerance
  - circuit breaker
  - error handling
  - התאוששות
metadata:
  openclaw:
    emoji: "🛡️"
    tags: [resilience, fault-tolerance, circuit-breaker, error-handling, recovery]
---

# 🛡️ Resilience & Fault Tolerance

> **Treat AI agents like distributed systems**
> 
> Circuit breakers, timeouts, fallbacks = Core safeguards

## למה Fault Tolerance חשוב?

### הבעיה:
```
AI Agents Fail:
├── API rate limits
├── Memory corruption
├── Infinite loops
├── Cost overruns
└── Cascading failures
```

### הפתרון:
```
Resilience Patterns:
├── Circuit breakers
├── Timeouts
├── Fallbacks
├── Retries
└── Graceful degradation
```

---

## Circuit Breakers

### Pattern:
```
CLOSED → OPEN → HALF-OPEN
  ↓       ↓        ↓
Normal  Block   Test
```

### Implementation:
```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failures = 0
        self.state = "CLOSED"
        self.last_failure_time = None
    
    def call(self, func, *args, **kwargs):
        if self.state == "OPEN":
            if self.should_attempt_reset():
                self.state = "HALF-OPEN"
            else:
                raise CircuitBreakerOpen()
        
        try:
            result = func(*args, **kwargs)
            self.on_success()
            return result
        except Exception as e:
            self.on_failure()
            raise
    
    def on_failure(self):
        self.failures += 1
        self.last_failure_time = time.time()
        
        if self.failures >= self.failure_threshold:
            self.state = "OPEN"
    
    def on_success(self):
        self.failures = 0
        self.state = "CLOSED"
    
    def should_attempt_reset(self):
        return time.time() - self.last_failure_time > self.timeout
```

### Use Cases:
- Budget caps ($5/day)
- Token limits
- API failures
- Rate limits

---

## Timeouts

### Hystrix-Style:
```python
@timeout(seconds=5)
def agent_task(task):
    return agent.execute(task)

# If >5s, raise TimeoutError
```

### Between Agent Chains:
```python
for agent in agent_chain:
    try:
        result = agent.process(input, timeout=5)
    except TimeoutError:
        # Fallback
        result = fallback_agent.process(input)
```

---

## Fallbacks

### Strategies:
```python
def execute_with_fallback(primary, fallback, task):
    try:
        return primary.execute(task)
    except Exception:
        return fallback.execute(task)

# Types of fallbacks:
# 1. Simpler model
# 2. Cached result
# 3. Rule-based
# 4. Human handoff
```

---

## Error Handling Layers

### Layer 1: Reversible Actions
```python
def reversible_action(action):
    # Can undo if needed
    checkpoint = create_checkpoint()
    
    try:
        result = action.execute()
        return result
    except Exception:
        checkpoint.rollback()
        raise
```

### Layer 2: Human Approval (Circuit Breaker)
```python
if action.risk_level == "HIGH":
    require_human_approval()

# Trust-building pattern
```

---

## Context & Memory Management

### Hard TTLs:
```python
memory = TTLCache(
    maxsize=1000,
    ttl=3600  # 1 hour
)
```

### Context Drift Monitoring:
```python
def monitor_context_drift(agent):
    current_context = agent.get_context()
    expected_context = agent.get_expected()
    
    if drift_detected(current_context, expected_context):
        trigger_circuit_breaker()
        alert_human()
```

### Breakers for Recursive Loops:
```python
def recursive_task(agent, depth=0):
    if depth > MAX_RECURSION:
        raise CircuitBreakerOpen("Too many recursive calls")
    
    if agent.is_stuck():
        raise CircuitBreakerOpen("Agent appears stuck")
    
    return recursive_task(agent, depth + 1)
```

---

## Handoff Issues

### Locks:
```python
@lock
def handoff(from_agent, to_agent, data):
    # Prevent flooding
    if queue_full(to_agent):
        return retry_later()
    
    return to_agent.process(data)
```

### Parse Failure Protection:
```python
def parse_with_protection(data):
    try:
        return parser.parse(data)
    except ParseError:
        # Don't flood other agents
        log_error()
        return fallback_parsing(data)
```

---

## Cost/Resilience Models

### ROI Checks:
```python
def cost_guard(action):
    estimated_cost = action.estimate_cost()
    
    if estimated_cost > BUDGET_LIMIT:
        raise CircuitBreakerOpen("Over budget")
    
    return action.execute()
```

### Stop-Loss:
```python
class TokenLimiter:
    def __init__(self, daily_limit=100000):
        self.daily_limit = daily_limit
        self.used = 0
    
    def check_and_use(self, tokens):
        if self.used + tokens > self.daily_limit:
            raise CircuitBreakerOpen("Daily token limit exceeded")
        
        self.used += tokens
```

---

## Stress Testing

### Against Failures:
```python
def stress_test(agent):
    scenarios = [
        "api_timeout",
        "rate_limit",
        "memory_full",
        "network_partition",
        "malformed_input"
    ]
    
    for scenario in scenarios:
        result = simulate_failure(agent, scenario)
        assert result.is_resilient()
```

---

## On-Chain Agents

### Pausable:
```python
# Circuit breaker with audit trail
@pausable
@auditable
def execute_on_chain(agent, transaction):
    return agent.execute(transaction)

# Can pause via admin
# Full audit trail
```

---

## Best Practices

### Production Checklist:
- [ ] Circuit breakers configured
- [ ] Timeouts set
- [ ] Fallbacks defined
- [ ] Retry policies
- [ ] Cost guards
- [ ] Memory limits
- [ ] Context monitoring
- [ ] Human escalation
- [ ] Audit trails
- [ ] Stress tested

### Architecture:
```
┌─────────────────────────────────┐
│        Circuit Breaker          │
│  ┌─────────────────────────┐   │
│  │      Timeout Layer      │   │
│  │  ┌─────────────────┐   │   │
│  │  │   Agent Logic   │   │   │
│  │  │  + Fallbacks    │   │   │
│  │  └─────────────────┘   │   │
│  └─────────────────────────┘   │
└─────────────────────────────────┘
```

---

## Real-World Examples

### Battle-Tested:
- Agency-OS
- NemoClaw
- High-token-spend ops ($11k+ failures)

### Lessons:
- Monitor drift
- Enforce timeouts
- Use breakers
- Degrade gracefully

---

## Bottom Line

**Resilience = Production Readiness**

- Distributed systems thinking
- Fail gracefully
- Never cascade
- Always recover

**Circuit breakers = Life savers**

---

*מבוסס על 2025 agent resilience patterns + distributed systems best practices*
