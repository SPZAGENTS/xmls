---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: output-validation
version: "1.0.0"
description: ולידציית פלטים מובנים - Pydantic schemas ואימות תקינות
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - validation
  - pydantic
  - schema
  - אימות
metadata:
  openclaw:
    emoji: "✓"
    tags: [validation, pydantic, schema, output, structured]
---

# ✓ Output Validation

> **אל תסמוך על LLM לייצר JSON תקין תמיד**
> 
> השתמש ב-Pydantic לאימות קשיח

## למה צריך ולידציה?

**בעיה:**
- LLMs מייצרים JSON לא תקין
- שדות חסרים
- טיפוסים לא נכונים
- הזיות בפלט מובנה

**פתרון:**
- Pydantic schemas
- Runtime validation
- Error handling גרייספול

---

## Schema בסיסי

```python
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Any, Dict
from enum import Enum

class ToolCall(BaseModel):
    name: str = Field(..., description="שם הכלי")
    arguments: Dict[str, Any] = Field(..., description="ארגומנטים")

class AgentOutput(BaseModel):
    reasoning: str = Field(..., description="תהליך החשיבה")
    action: str = Field(..., description="tool_call | final_answer")
    tool_calls: Optional[List[ToolCall]] = None
    final_answer: Optional[str] = None
    
    @validator('tool_calls')
    def validate_tool_calls(cls, v, values):
        if values.get('action') == 'tool_call' and not v:
            raise ValueError('tool_calls נדרש כש-action הוא tool_call')
        return v
```

---

## Schema מתקדם

```python
class StatusEnum(str, Enum):
    IN_PROGRESS = "in_progress"
    TOOL_CALL = "tool_call"
    FINAL_ANSWER = "final_answer"
    ERROR = "error"

class ConfidenceLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class Source(BaseModel):
    type: str
    url: Optional[str] = None
    citation_id: Optional[int] = None

class AgentResponse(BaseModel):
    status: StatusEnum
    reasoning: str = Field(..., max_length=2000)
    confidence: ConfidenceLevel = "medium"
    tool_calls: List[ToolCall] = []
    final_answer: Optional[str] = Field(None, max_length=4000)
    sources: List[Source] = []
    metadata: Dict[str, Any] = {}
    
    class Config:
        json_schema_extra = {
            "examples": [{
                "status": "final_answer",
                "reasoning": "ניתוח הושלם",
                "confidence": "high",
                "final_answer": "התשובה היא 42"
            }]
        }
```

---

## Validator Function

```python
import json

def validate_agent_output(raw_output: str, schema: type[BaseModel]) -> AgentResponse:
    """ולידציה ו-parse של פלט סוכן"""
    try:
        # נסה ל-parse כ-JSON
        parsed = json.loads(raw_output)
    except json.JSONDecodeError:
        # Fallback: חלץ JSON מ-code block
        if "```json" in raw_output:
            start = raw_output.find("```json") + 7
            end = raw_output.find("```", start)
            json_str = raw_output[start:end].strip()
            parsed = json.loads(json_str)
        else:
            raise ValueError("לא נמצא JSON תקין")
    
    return schema(**parsed)
```

---

## Framework שלם

```python
from pydantic import ValidationError

class AgentValidator:
    def __init__(self, output_schema: type[BaseModel]):
        self.schema = output_schema
    
    def validate(self, raw_output: str) -> AgentResponse:
        try:
            validated = validate_agent_output(raw_output, self.schema)
            print("✅ פלט תקין")
            return validated
        except ValidationError as e:
            print("❌ שגיאת ולידציה:", e.json())
            return self.handle_error(e, raw_output)
    
    def handle_error(self, error: ValidationError, raw_output: str) -> AgentResponse:
        """טיפול חלק בשגיאות"""
        return AgentResponse(
            status="error",
            reasoning=f"ולידציה נכשלה: {str(error)}",
            confidence="low"
        )
```

---

## OpenAI Function Calling

```python
from openai import OpenAI

def create_openai_function_call(schema: type[BaseModel]):
    """המרת Pydantic לפורמט OpenAI"""
    return {
        "name": "agent_output",
        "description": "פלט מובנה של סוכן",
        "parameters": schema.model_json_schema()
    }

client = OpenAI()
functions = [create_openai_function_call(AgentResponse)]

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "..."}],
    functions=functions,
    function_call={"name": "agent_output"}
)
```

---

## Streaming Validation

```python
class StreamingValidator:
    def __init__(self, schema: type[BaseModel]):
        self.schema = schema
        self.buffer = ""
    
    def validate_stream(self, chunk: str):
        self.buffer += chunk
        
        if "```json" in self.buffer and "```" in self.buffer:
            try:
                start = self.buffer.find("```json") + 7
                end = self.buffer.find("```", start)
                json_str = self.buffer[start:end].strip()
                
                parsed = json.loads(json_str)
                validated = self.schema(**parsed)
                self.buffer = ""  # איפוס
                return validated
            except (json.JSONDecodeError, ValidationError):
                pass
        
        return None
```

---

## Best Practices

### 1. תמיד Validate
```python
# לא טוב
output = json.loads(raw_output)

# טוב
output = AgentResponse(**json.loads(raw_output))
```

### 2. תן fallback
```python
try:
    validated = validate(output)
except ValidationError:
    return default_response()
```

### 3. שמור שגיאות ללמידה
```python
log_validation_error(error, raw_output, context)
```

### 4. הוסף examples
```python
class Config:
    json_schema_extra = {"examples": [...]}
```

### 5. השתמש ב-Enums
```python
class Status(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
```

---

## יתרונות

1. **Type Safety** - ולידציה ב-runtime
2. **Structured Output** - JSON מובטח
3. **Error Handling** - טיפול גרייספול
4. **Documentation** - סכמה אוטומטית
5. **Integration** - עובד עם כל ה-LLMs
6. **Streaming** - תמיכה ב-real-time

---

## תבנית מהירה

```python
from pydantic import BaseModel

class MyOutput(BaseModel):
    answer: str
    confidence: float
    sources: list[str]

# שימוש
try:
    result = MyOutput(**json.loads(llm_output))
    print(result.answer)
except Exception as e:
    print(f"Error: {e}")
```

---

*מבוסס על Pydantic + OpenAI + Production best practices*
