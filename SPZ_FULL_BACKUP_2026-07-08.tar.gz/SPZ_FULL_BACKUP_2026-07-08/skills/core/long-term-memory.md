---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: long-term-memory
version: "1.0.0"
description: זיכרון ארוך טווח - RAG, vector DBs, ו-agentic retrieval מעבר לוקטורים
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - memory
  - RAG
  - זיכרון
  - retrieval
metadata:
  openclaw:
    emoji: "🗄️"
    tags: [memory, RAG, vectors, persistence, retrieval]
---

# 🗄️ Long-Term Memory

> **RAG טהור = outdated**> 
> ASMR (Supermemory): 97-99% על LongMemEval-s

## מבנה הזיכרון

### שלושת סוגי הזיכרון:

**1. Episodic Memory (חוויתי)**
- שיחות קודמות
- אינטראקציות
- אירועים

**2. Semantic Memory (סמנטי)**
- עובדות
- ידע כללי
- העדפות משתמש

**3. Procedural Memory (פרוצדורלי)**
- מיומנויות
- דפוסי עבודה
- כלים ושיטות

---

## גישות 2025-2026

### 1. Vector RAG (המסורתי)

**איך זה עובד:**
```python
# Embeddings
vectors = embed(documents)
store_in_pinecone(vectors)

# Retrieval
query_vector = embed(query)
results = pinecone.search(query_vector, top_k=5)
```

**יתרונות:**
- Scalable
- מוכר (LangChain, LlamaIndex)
- טוב לחיפוש סמנטי

**חסרונות:**
- מתקשה ב-reasoning טמפורלי
- סתירות ו-redundancy
- latency/cost גבוהים ב-scale

**ביצועים:** ~85% על LongMemEval

---

### 2. Agentic Retrieval (המהפכה!)

**Supermemory's ASMR (מרץ 2026)**

**ארכיטקטורה:**
```
Query → 3 Reader Agents → Extract Facts
         ↓
      3 Search Agents → Reason
         ↓
      8-12 Answering Agents → Generate
         ↓
      Aggregator → Final Answer
```

**יתרונות:**
- **97-99%** על LongMemEval-s
- 115k+ tokens, multi-session
- No embeddings/DB
- In-memory

**חסרונות:**
- 14-18 LLM calls ל-query (יקר)
- מורכב ליישום

---

### 3. Hybrid Approaches

**xMemory:**
- היררכי: themes → semantics → episodes
- 50% פחות טוקנים
- 38-50% BLEU על LoCoMo

**GAAMA:**
- Graphs + reflections
- **78.9%** על LoCoMo-10

**Hindsight:**
- Biomimetic (facts/experiences/models)
- Multi-retrieval (semantic/graph/temporal)
- SOTA על LongMemEval

---

## טכניקות מתקדמות

### Forgetting (שכחה מכוונת)
```python
# Ebbinghaus/FSRS
if memory.strength < threshold:
    archive_or_delete(memory)

# Decay
memory.relevance *= decay_factor(time_passed)
```

### File-Based/Markdown
```python
# Memsearch
append_only_logs = load("memory.md")
deduped = remove_duplicates(append_only_logs, method="SHA")
```

### Multi-Agent Sync
```python
# Shared memory across swarms
shared_state = DistributedMemory()
agent1.write(key, value)
agent2.read(key)  # Same value
```

---

## השוואת ביצועים

| גישה | Benchmark | דיוק | עלות |
|------|-----------|------|------|
| Vector RAG | LongMemEval | ~85% | בינונית |
| ASMR (Supermemory) | LongMemEval-s | **97-99%** | גבוהה |
| xMemory | LoCoMo | 38-50% BLEU | נמוכה |
| GAAMA | LoCoMo-10 | **78.9%** | נמוכה |
| Hindsight | LongMemEval | **SOTA** | בינונית |

---

## מימוש מעשי

### Tier 1: פשוט (Vector RAG)
```python
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings

vectorstore = Chroma.from_documents(
    documents=docs,
    embedding=OpenAIEmbeddings()
)

results = vectorstore.similarity_search(query, k=5)
```

### Tier 2: משולב (Hybrid)
```python
# BM25 + SQL + Graphs + Vectors
results = hybrid_search(
    query,
    methods=["bm25", "sql", "graph", "semantic"]
)
```

### Tier 3: Agentic (ASMR-style)
```python
# Multi-agent retrieval
facts = extract_facts_with_agents(query)
context = reason_with_agents(facts)
answer = generate_with_agents(context)
aggregated = aggregate_answers(answers)
```

---

## כלים מומלצים

| כלי | שימוש |
|-----|-------|
| **Letta** | Agent memory |
| **Mem0** | Personal memory |
| **Zep** | Conversation memory |
| **Graphiti** | Graph memory |
| **Pinecone** | Vector DB |
| **Chroma** | Local vectors |
| **Milvus** | Enterprise vectors |

---

## Benchmarks חשובים

- **LongMemEval** - long context, multi-session
- **LoCoMo** - long conversations
- **BEAM10m** - 10 million tokens

---

## טרנדים 2026+

- **Hybrid wins** - וקטורים + גרפים + סוכנים
- **Memory Types** - STM + LTM with read/write
- **Challenges** - multi-agent sync, what to store/forget, scale

---

## Bottom Line

**המעבר מ-RAG טהור ל-Agentic Retrieval**

- Vectors = בסיס, לא מספיק
- Agents = דיוק גבוה, יקר
- Hybrid = האיזון הנכון
- הזיכרון מתפתח מ-static retrieval ל-dynamic reasoning

---

*מבוסס על 2025 memory research + Supermemory ASMR*
