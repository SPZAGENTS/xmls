---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: error-handling
version: "1.0.0"
description: Error Handling, Logging, Debugging - טיפול בשגיאות לסוכני AI
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - error
  - debugging
  - logging
  - troubleshooting
metadata:
  openclaw:
    emoji: "🐛"
    tags: [error, debugging, logging, troubleshooting]
---

# 🐛 Error Handling & Debugging

> **80% of agent work = failure handling**
> > Treat agents like microservices with OpenTelemetry traces

## האתגרים

### 2025 Statistics:
```
- 5x increase in AI agent misbehavior (UK study)
- Reliability lags accuracy
- Cascading failures common
- 500+ failures analyzed by Stanford
```

### Cascading Failures:
```
NeurIPS 2025 Research:
├── Self-corrections expose data
├── Trigger unintended actions
└── Compound into irreversible issues

Chatbots: Fail once
Agents: Dig deeper (and fail worse)
```

### Error Propagation:
```
Stanford AgentDebug:
Step 3: Memory recall error
    ↓
Step 10: Wrong planning
    ↓
Step 20: Complete meltdown

Planning failures: 78 cases
Reflection failures: Common
Memory hallucinations: Common
```

---

## סוגי שגיאות נפוצים

### 1. Hallucinations
```
Cause: Model generates false information
Impact: Wrong decisions, bad outputs
```

### 2. Wrong Tool Calls
```
Cause: Wrong tool selected
Impact: Failed operations, side effects
```

### 3. Infinite Loops
```
Cause: No termination condition
Impact: Resource waste, timeouts
```

### 4. Timeouts
```
Cause: Long-running operations
Impact: User frustration, failures
```

### 5. State Corruption
```
Cause: Non-deterministic behavior
Impact: Unpredictable results
```

---

## Best Practices

### 1. Comprehensive Logging

**Log Everything:**
```python
@logged
def agent_step(input, reasoning, action, output):
    logger.info({
        "step": step_number,
        "input": input,
        "reasoning": reasoning,
        "action": action,
        "output": output,
        "timestamp": now(),
        "latency": calculate_latency(),
        "tokens": count_tokens()
    })
```

**Strategic Logging:**
```python
# When stuck after 3 tries
def debug_with_logging():
    prompt = "Add logging to reproduce the bug"
    # Instead of repasting errors
    # Avoids context poisoning
```

---

### 2. Blast Radius Limits

```python
class SafetyControls:
    def __init__(self):
        self.rate_limiter = RateLimiter()
        self.checkpoint = CheckpointManager()
        self.kill_switch = KillSwitch()
    
    def execute(self, action):
        # Rate limit irreversible actions
        if action.irreversible:
            self.rate_limiter.check()
        
        # Checkpoint side effects
        self.checkpoint.save_state()
        
        # Kill switch available
        try:
            return action.execute()
        except CriticalError:
            self.kill_switch.activate()
            raise
```

---

### 3. Retry Logic

```python
@retry(
    max_attempts=3,
    exceptions=(APIError, TimeoutError),
    backoff=2.0  # exponential
)
def risky_operation():
    return external_api.call()
```

---

### 4. Guardrails

```python
@guardrails([
    no_pii_exposure,
    no_harmful_content,
    tool_validation
])
def agent_generate(prompt):
    return llm.generate(prompt)
```

---

### 5. Structured Outputs

```python
from pydantic import BaseModel

class AgentOutput(BaseModel):
    action: str
    parameters: dict
    reasoning: str
    confidence: float

def validate_output(raw_output):
    try:
        return AgentOutput.parse(raw_output)
    except ValidationError as e:
        log.error(f"Invalid output: {e}")
        return fallback_output()
```

---

## Debugging Techniques

### 1. AgentDebug (Stanford)

```
Framework:
1. Analyze 500+ failures
2. Map errors to modules
   - Memory
   - Planning
   - Tool use
3. Find root cause
4. Surgical feedback

Result: 45% step accuracy boost
```

### 2. Error Analysis (Andrew Ng)

```
Process:
1. Collect failures
2. Categorize via LLM
3. Diagnose top issues
4. Targeted fixes
5. Automate evals

Benefit: 10x faster iteration
```

### 3. Multi-Agent Debugging

```
Patterns:
├── Supervisor oversees
├── Single-owner chains
├── Fail-fast
└── Clear handoffs
```

---

## כלים וכלים

### Galileo Insights Engine:
```
Features:
├── Auto-analyzes traces
├── Root cause identification
├── 10x faster debugging
└── Production-ready
```

### MLflow:
```
CLEARS Categories:
├── Correctness
├── Latency
├── Errors
├── Actions
├── Resources
└── State
```

### Agent Forge:
```
Debugging environment
Trace visualization
State inspection
```

---

## Implementation

### Production Setup:
```python
class ProductionAgent:
    def __init__(self):
        self.logger = StructuredLogger()
        self.tracer = OpenTelemetryTracer()
        self.guardrails = Guardrails()
        self.circuit_breaker = CircuitBreaker()
    
    @logged
    @traced
    @guardrails
    def execute(self, task):
        try:
            return self._execute_safe(task)
        except Exception as e:
            self.logger.error(e)
            self.circuit_breaker.record_failure()
            return self.recover(e)
```

---

## Tools Stack

| Category | Tools |
|----------|--------|
| Frameworks | AutoGen AG2, CrewAI, LiteLLM |
| Monitoring | AgentOps, Prometheus, ELK |
| Memory | Mem0, Neon DB |
| Debugging | Debugy.dev, Galileo Insights |
| Tracing | OpenTelemetry, Jaeger |

---

## Checklist לייצור

- [ ] Comprehensive logging
- [ ] Structured outputs
- [ ] Retry logic
- [ ] Circuit breakers
- [ ] Blast radius limits
- [ ] Kill switches
- [ ] Error categorization
- [ ] Root cause analysis
- [ ] Recovery procedures
- [ ] Observability dashboard

---

## Bottom Line

**Error Handling = Critical**

- 80% of work
- Plan for failures
- Log everything
- Recover gracefully

**"Plan for failure, not success"**

---

*מבוסס על Stanford AgentDebug + 2025 error handling practices*
