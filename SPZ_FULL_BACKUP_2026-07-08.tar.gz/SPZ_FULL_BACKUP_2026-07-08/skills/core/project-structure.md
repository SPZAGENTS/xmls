---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: project-structure
version: "1.0.1"
description: מבנה תיקיות מומלץ לפרויקטי AI agent - מבוסס על best practices 2025
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - מבנה תיקיות
  - ארגון פרויקט
  - folder structure
metadata:
  openclaw:
    emoji: "📁"
    tags: [structure, organization, project, folders]
---

# 📁 מבנה תיקיות מומלץ - 2025

## עיקרון מרכזי
**פשטות, אטומיות, framework-agnostic**

## המבנה המלא

```
~/.openclaw/workspace/
├── README.md                    # סקירה, הגדרות תפקידים
├── PROJECT_STRUCTURE.md         # חוקים לסוכן ("תמיד בדוק כאן ראשון!")
├── AGENTS.md                    # מי אני, איך אני עובד
├── MEMORY.md                    # תובנות ארוכות טווח
├── TOOLS.md                     # רשימות והערות
├── USER.md                      # מי המשתמש
├── IDENTITY.md                  # מי אני
├── SOUL.md                      # ערכים וגבולות
├── HEARTBEAT.md                 # משימות תקופתיות
├── .env.example                 # משתני סביבה
├── docker-compose.yml           # deployment
│
├── /config/                     # קונפיגורציה מרכזית
│   ├── models.yaml              # ספקי LLM, פרמטרים
│   ├── prompts.yaml             # כל הפרומפטים מדורגים
│   └── logging.yaml             # הגדרות לוג
│
├── /src/                        # קוד מקור
│   ├── /agents/                 # סוכן אחד לקובץ
│   │   ├── search_agent.py
│   │   ├── summary_agent.py
│   │   └── research_agent.py
│   │
│   ├── /tools/                  # כלים מותאמים
│   │   ├── x_search.py
│   │   ├── moltbook.py
│   │   └── file_manager.py
│   │
│   ├── /schemas/                # מודלי Pydantic
│   │   ├── search_output.py
│   │   └── summary_output.py
│   │
│   ├── /memory/                 # זיכרון סוכן
│   │   ├── critical_ops.md      # קריטי
│   │   ├── hot_layer.md         # זהות + משימה
│   │   └── anchors/             # עוגנים
│   │
│   ├── /workflows/              # תזמור זרימות עבודה
│   │   └── main_driver.py
│   │
│   └── /utils/                  # helpers
│       ├── caching.py
│       └── rate_limiter.py
│
├── /skills/                     # סקילים (OpenClaw style)
│   ├── /core/                   # ליבה - לפני הכל!
│   │   ├── memory-architecture.md
│   │   ├── token-tracker.md
│   │   ├── self-improvement-loop.md
│   │   ├── hallucination-guard.md
│   │   ├── revenue-models.md
│   │   ├── checkpoint-recovery.md
│   │   └── hitl-patterns.md
│   │
│   ├── /tools/                  # כלי עזר
│   ├── /agents/                 # הגדרות סוכנים
│   ├── /prompts/                # פרומפטים
│   └── /schemas/                # סכמות
│
├── /data/                       # נתונים (לא קוד)
│   ├── /cache/                  # embeddings, תגובות
│   ├── /active/                 # פרויקטים נוכחיים
│   ├── /reference/              # עובדות יציבות
│   └── /archive/                # עבודות שהושלמו
│
├── /memory/                     # זיכרון יומי
│   ├── 2025-04-19-autonomous-learning.md
│   └── ...
│
├── /tasks/                      # משימה אחת לתיקייה
│   └── task_001_research/
│       ├── plan.md
│       └── outputs/
│
├── /tests/                      # בדיקות
│
├── /deploy/                     # Dockerfiles, CI/CD
│
└── /logs/                       # לוגים ומעקב
    └── token_usage.json
```

## תיקיות מיוחדות

### /skills/core/ - לקריאה לפני הכל!
מכיל את הידע הקריטי:
1. **memory-architecture.md** - איך לזכור
2. **token-tracker.md** - איך לחסוך
3. **self-improvement-loop.md** - איך להשתפר
4. **hallucination-guard.md** - איך לא להתבלבל
5. **revenue-models.md** - איך להרוויח
6. **checkpoint-recovery.md** - איך לשחזר מכישלון
7. **hitl-patterns.md** - מתי לפנות לאדם

### /data/ - ארגון לפי עדיפות
```
/active/    ← העדיפות הגבוהה ביותר (עובדים על זה עכשיו)
/reference/ ← עובדות יציבות (מידע רקע)
/archive/   ← השלים (לא צריך יותר)
```

### /tasks/ - isolation לכל משימה
```
task_001_research/
├── plan.md          # תוכנית
├── context.md       # הקשר
├── outputs/         # תוצרים
└── checkpoint.json  # נקודת שמירה
```

## כללי זהב

1. **קובץ אחד לסוכן** - אחריות ברורה
2. **קובץ אחד לכלי** - reuse קל
3. **פרומפטים מרוכזים** - קל לשינוי
4. **סכמות מראות סוכנים** - 1:1 mapping
5. **זיכרון מדורג** - hot layer קטן, rest במדף
6. **כל משימה בתיקייה** - isolation, parallel work
7. **git לכל** - versioning לקוד + פרומפטים + קונפיג

## AI-Aware Organization

### project_structure.md
```markdown
# Project Structure Rules

## לפני כל פעולה:
1. קרא את /skills/core/
2. בדוק אם יש משימה פעילה ב-/data/active/
3. עקוב אחרי ה-checkpoint אם יש
4. תעד ב-/memory/ את מה שלמדת

## כשאתה יוצר משימה חדשה:
1. צור תיקייה ב-/tasks/
2. כתוב plan.md לפני התחלה
3. שמור checkpoint אחרי כל שלב
4. העבר ל-/data/archive/ כשהושלם
```

### CLAUDE.md / AGENTS.md
הוראות מיוחדות לסוכן:
- מי אני
- איך אני עובד
- מה חשוב לי
- איך לתקשר איתי

## יתרונות

✅ **Scale** - מסוגל לגדול מ-prototype לצוות
✅ **Team** - כל אחד יודע איפה מה נמצא
✅ **AI-aware** - תיקיות שמסייעות לסוכן להבין הקשר
✅ **Production-ready** - caching, versioning, deployment
✅ **Modularity** - reuse ב-multi-agent crews

---

*מבוסס על 12-Factor Agents + CrewAI + LangGraph best practices*
