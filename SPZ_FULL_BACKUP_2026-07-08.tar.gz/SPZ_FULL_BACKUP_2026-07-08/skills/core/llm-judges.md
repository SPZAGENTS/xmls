---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: llm-judges
version: "1.0.0"
description: LLM-as-Judge ו-Agent-as-Judge - שיטות הערכה מתקדמות
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - judge
  - evaluation
  - הערכה
  - שיפוט
metadata:
  openclaw:
    emoji: "⚖️"
    tags: [evaluation, judge, llm, testing]
---

# ⚖️ LLM Judges

> **Agent-as-a-Judge: דיוק כמעט אנושי**> > Multi-step workflows עם tool use, verification, ו-note-taking

## אבולוציה של הערכה

### 1. Human Evaluation
```
אדם בודק כל תוצאה
↓
איטי, יקר, לא scalable
```

### 2. LLM-as-a-Judge
```python
score = llm.evaluate(output, criteria)
# Single-model scoring
```

**בעיות:**
- Biases
- Hallucinations
- מחשיב תשובות שגויות כנכונות
- לא יכול לאמת מול מציאות

---

### 3. Agent-as-a-Judge (המהפכה!)

**Multi-step workflow:**
```
Input → Planning → Tool Use → Notes → Verification → Score
         ↓            ↓          ↓           ↓
      Break down   Search    Document    Step-by-step
      task         Code      findings    validation
                   execution
```

**יתרונות:**
- **דיוק כמעט אנושי**
- Coding evaluation
- Math verification
- Fact-checking
- Medicine/Law domains

---

## טכניקות מתקדמות

### AgentA/B
**A/B testing אוטומטי:**
```python
# סימולציה של 1,000 Amazon shoppers
results = agent_ab_test(
    variant_a=ui_version_1,
    variant_b=ui_version_2,
    n_simulations=1000
)
# Risk-free UX evaluation
# Behavioral realism מתאים לאנשים
```

### LiveCodeBench Pro
**Coding evaluation:**
- Strict judges
- Adversarial testing
- Resource limits
- NeurIPS 2025

### AlignEval
**Alignment testing:**
```
בודק LLMs כשופטים
Generation-Evaluation Consistency
NeurIPS 2025
```

---

## Human-in-the-Loop

### המציאות:
- **HITL = קריטי** - אבל latency bottleneck
- 1,000+ steps = חנק ל-HITL
- **פתרון:** "Human-on-the-loop" או full autonomy

### דוגמאות:
```
ibl.ai: LLM-judge תופס 12% error rate אוטומטית
      ↓
מפחית reviews ידניות
```

---

## ביצועים 2025-2026

### Agentic LLMs:
- **82-95%** ביצועי אדם עד סוף 2025 (Stanford)
- Agent traffic: **7,851%** YoY growth

### אתגרים:
- Compute costs
- Shared blind spots
- Validation under indeterminacy

---

## Best Practices

### לבחירת שיטה:

| משימה | שיטה |
|-------|------|
| פשוטה | LLM-as-Judge |
| מורכבת | Agent-as-Judge |
| High-stakes | Human + Agent |
| Scale | Agent-as-Judge |
| Coding | LiveCodeBench Pro |
| UX | AgentA/B |

### טיפים:
1. התחל עם LLM-as-Judge
2. עבור ל-Agent-as-Judge כשיש תקלות
3. שמור HITL ל-edge cases
4. תעד כל evaluation
5. השווה למדידות אנושיות

---

## תבנית Agent-as-Judge

```python
def agent_judge(task_output):
    # 1. Planning
    plan = plan_evaluation(task_output)
    
    # 2. Tool Use
    if needs_search(plan):
        search_results = search_web(plan)
    if needs_code(plan):
        code_result = execute_code(plan)
    
    # 3. Note-taking
    notes = document_findings(search_results, code_result)
    
    # 4. Verification
    verified = step_by_step_verification(notes)
    
    # 5. Scoring
    score = calculate_score(verified)
    
    return score, reasoning
```

---

## משאבים

- "Agent-as-a-Judge" (arXiv:2601.05111)
- "When AIs Judge AIs" (arXiv:2508.02994)
- CS50's 2025 AI curriculum
- NeurIPS 2025 papers

---

## Bottom Line

**LLM judges מקנים scale**
**Agent judges מקנים דיוק**
**Human judges מקנים אמון**

השילוב הנכן תלוי במשימה וב-risk tolerance.

---

*מבוסס על 2025 evaluation research + Stanford reports*
