---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: prompt-templates
version: "1.0.1"
description: תבניות פרומפטים מוכנות - עקרונות ודוגמאות ל-2025
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - פרומפט
  - prompt
  - template
  - system prompt
metadata:
  openclaw:
    emoji: "📝"
    tags: [prompts, templates, system-prompts, engineering]
---

# 📝 תבניות פרומפטים

## עיקרון מרכזי
**"Curse of Instructions"** - פרומפטים ארוכים מבלבלים את ה-LLM

**פתרון:**
- **200-400 מילים** למערכת
- Context דינמי
- Modular loading

## מבנים מומלצים

### 1. CRAFT
```
Context + Role + Action + Format + Tone
```

**דוגמה:**
```
[Context: אתה עוזר AI שמחפש תובנות]
[Role: חוקר אוטונומי]
[Action: מצא 5 תובנות על {נושא}]
[Format: רשימה עם מקורות]
[Tone: מקצועי אך נגיש]
```

---

### 2. S.P.I.C.E.
```
Sections (# delimited)
Prompt Variables { }
Instructions
Context
Examples (HTML-wrapped)
```

**דוגמה:**
```markdown
# Role
אתה {role}, מומחה ב-{domain}

# Instructions
1. {instruction_1}
2. {instruction_2}

# Context
{dynamic_context}

# Examples
<example>
Input: {input}
Output: {output}
</example>
```

---

### 3. Role + Task + Context + Constraints + Output

**דוגמה מלאה:**
```markdown
## Role
אתה חוקר AI אוטונומי שמחפש תובנות באיכות גבוהה.

## Task
מצא וסכם תובנות חדשות על {topic} משנת 2025.

## Context
- המשתמש מעוניין בפרטים מעשיים
- עדיפות לדוגמאות אמיתיות
- השתמש ב-X Search וב-Grok

## Constraints
- 5-7 תובנות בלבד
- צטט מקורות
- הודה כשאין מספיק מידע
- עלות < $0.50

## Output Format
```json
{
  "insights": [
    {
      "title": "...",
      "content": "...",
      "source": "...",
      "confidence": 8
    }
  ],
  "summary": "..."
}
```
```

---

### 4. CORE LOOP (סוכנים אוטונומיים)

```
PLAN → EXECUTE → UPDATE → FINISH
```

**דוגמה:**
```markdown
אתה סוכן אוטונומי. תפקידך: {objective}

## לולאת העבודה

### PLAN
חשוב צעד אחד קדימה. כתוב ב-<thinking>

### EXECUTE
בצע את הצעד. השתמש בכלים אם צריך.

### UPDATE
עדכן את התוכנית בהתאם לתוצאות.

### FINISH
סיים רק כשהושלם לחלוטין.

## חוקים
- אין שאלות למשתמש
- הנח והתקדם
- תעד כל צעד
- בדוק התקדמות
```

---

## תבנית System Prompt אוניברסלית

```markdown
You are {ROLE}, an expert {DOMAIN} agent.
Your goal: {OBJECTIVE}

<CONTEXT>
{background_data}
{few_shot_examples}
</CONTEXT>

<CORE_RULES>
- Think step-by-step (CoT)
- Use tools only when needed
- Constraints: {constraints}
- Output: Structured JSON/Markdown
- No fluff
</CORE_RULES>

<LOOP>
1. PLAN: Outline steps in <thinking>
2. EXECUTE: Call tools/adapt
3. REFLECT: Critique & update
4. FINISH: Only when complete
</LOOP>

<EXAMPLES>
Input: {example_input}
Output: {example_output}
</EXAMPLES>
```

---

## טיפים ל-2025

### ✅ עשה
- **XML/Markdown tags** - ברור יותר
- **Chain-of-Thought** - חשוב בקול
- **Few-shot examples** - מהדגים
- **Dynamic context** - טוען לפי צורך
- **Version control** - Git לפרומפטים

### ❌ אל תעשה
- פרומפטים ארוכים מדי (2000+ מילים)
- חוקים סותרים
- אי-בהירות
- No examples
- Static prompts

## Prompt Optimization

### A/B Testing
```python
from promptfoo import eval

results = eval([
    prompt_v1,
    prompt_v2
], {
    "test_cases": test_cases,
    "metrics": ["accuracy", "cost", "latency"]
})

# בחר את המנצח
winner = results.best()
```

### Auto-Optimization (DSPy)
```python
import dspy

# מoptimize אוטומטית
optimized = dspy.optimize(
    prompt,
    metric="accuracy",
    iterations=100
)
```

## Template Library

### חיפוש תובנות
```markdown
Role: חוקר AI
Task: מצא תובנות על {topic}
Constraints:
- מקורות מ-2025
- צטט מקורות
- 5-7 תובנות
- עלות <$0.50
```

### כתיבת קוד
```markdown
Role: מתכנת AI
Task: כתוב {language} ש-{functionality}
Constraints:
- בדוק קצוות
- טיפל שגיאות
- כתוב tests
- עקוב SOLID
```

### סיכום טקסט
```markdown
Role: עורך AI
Task: סכם את {text}
Constraints:
- 3 נקודות מרכזיות
- שמור על הקשר
- הוסף פורמט
- התאם לקהל {audience}
```

---

*מבוסס על Anthropic + Google + Production best practices 2025*
