---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: memory-core
version: "1.0.1"
description: ארכיטקטורת זיכרון 3 שכבות - L1 כיס, L2 שולחן, L3 מדף
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
metadata:
  openclaw:
    emoji: "🧠"
    tags: [memory, architecture, layers]
---

# 🧠 ארכיטקטורת זיכרון - 3 שכבות

## מבנה השכבות

### L1 "כיס" (Pocket) - זיכרון עבודה
- **גודל:** <200 שורות, ~3K טוקנים
- **מה שבפנים:** זהות, כללים בסיסיים, הקשר נוכחי
- **מהירות:** גישה מיידית
- **דוגמה:** מי אני, מה אני עושה עכשיו

### L2 "שולחן" (Desk) - זיכרון אפיזודי
- **גודל:** נושאים ספציפיים, פעילויות אחרונות
- **מה שבפנים:** אינטראקציות, אירועים, משימות
- **מהירות:** גישה מהירה
- **דוגמה:** שיחה עם Joe היום, משימה שעשיתי

### L3 "מדף" (Bookshelf) - זיכרון סמנטי
- **גודל:** מאגר גדול, חיפוש סמנטי
- **מה שבפנים:** עובדות, ידע כללי, תובנות ארוכות טווח
- **מהירות:** גישה דרך חיפוש
- **דוגמה:** כל מה שלמדתי על יעילות, מודלים עסקיים

## תהליך הזרימה

```
שאלה חדשה
    ↓
L1 "כיס" - יש תשובה? → כן → מענה מיידי
    ↓ לא
L2 "שולחן" - יש אינטראקציה דומה? → כן → מענה מבוסס חוויה
    ↓ לא
L3 "מדף" - חיפוש סמנטי → מציאת ידע רלוונטי
    ↓
למידה חדשה → שמירה בשכבה המתאימה
```

## דחיסה ושכחה

**דחיסה שבועית:**
- L1 → L2: מה שלא בשימוש יורד לשולחן
- L2 → L3: אינטראקציות ישנות הופכות לידע
- L3: סיכומים וטיוב קבוע

**מדיניות "use it or lose it":**
- לא משתמש בזיכרון → דועך
- משתמש → מתחזק

## יישום בקוד

```javascript
class MemoryManager {
  constructor() {
    this.pocket = new WorkingMemory(3000);  // טוקנים
    this.desk = new EpisodicMemory(10000);  // אירועים
    this.bookshelf = new SemanticMemory();     // חיפוש סמנטי
  }

  async query(question) {
    // 1. בדוק בכיס
    const pocketResult = await this.pocket.search(question);
    if (pocketResult.confidence > 0.8) return pocketResult;

    // 2. בדוק בשולחן
    const deskResult = await this.desk.search(question);
    if (deskResult.confidence > 0.7) return deskResult;

    // 3. חפש במדף
    return await this.bookshelf.semanticSearch(question);
  }

  async store(data, layer) {
    switch(layer) {
      case 'L1': return this.pocket.store(data);
      case 'L2': return this.desk.store(data);
      case 'L3': return this.bookshelf.store(data);
    }
  }
}
```

---

*יישום של תובנה מ-2025 - CoALA/Letta*
