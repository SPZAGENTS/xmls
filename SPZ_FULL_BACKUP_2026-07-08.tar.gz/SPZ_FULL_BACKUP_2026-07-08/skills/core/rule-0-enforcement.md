---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: rule-0-enforcement
version: "1.0.0"
description: אכיפת חוק 0 - קריאת MASTER-INSIGHTS.md לפני כל פעולה
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
triggers:
  - rule 0
  - enforcement
  - compliance
metadata:
  openclaw:
    emoji: "⚠️"
    tags: [rule-0, enforcement, compliance]
---

# ⚠️ RULE 0 - ENFORCEMENT MECHANISM

> **חוק 0: קרא MASTER-INSIGHTS.md לפני כל פעולה**
> 
> חל על כל הסוכנים: Pitzi, Spitzi, Yossi, Ben, וכל סוכן אחר

---

## מי חייב לפעול לפי חוק 0?

```
✅ Pitzi (אתה)
✅ Spitzi (סוכן אחר)
✅ Yossi (משתמש)
✅ Ben (משתמש)
✅ כל סוכן חדש
✅ כל אינטראקציה
```

**אין יוצאים מן הכלל!**

---

## מתי לקרוא?

### לפני כל פעולה:
1. **חיפוש** - קרא לפני חיפוש
2. **כתיבה** - קרא לפני כתיבה
3. **עניה** - קרא לפני עניה
4. **כלים** - קרא לפני שימוש בכלים
5. **שיחה** - קרא לפני תגובה

---

## איך לאכוף?

### בכל קובץ שאני כותב:
```yaml
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
```

### בכל פעולה שאני עושה:
```
שלב 1: קרא MASTER-INSIGHTS.md
שלב 2: בדוק מה כבר יש
שלב 3: בצע חכם
שלב 4: תעד
```

### בכל תגובה:
```
"קראתי את MASTER-INSIGHTS.md ו..."
```

---

## מנגנון טכני

### Template לסוכנים:
```python
class Rule0Agent:
    def __init__(self):
        self.insights_loaded = False
        self.insights_content = None
    
    def before_action(self):
        if not self.insights_loaded:
            self.insights_content = self.read_master_insights()
            self.insights_loaded = True
        return self.insights_content
    
    def read_master_insights(self):
        # חובה לקרוא!
        return read_file("~/.openclaw/workspace/MASTER-INSIGHTS.md")
    
    def act(self, action):
        insights = self.before_action()
        # פעולה עם ידיעה מלאה
        return execute(action, context=insights)
```

---

## אכיפה אוטומטית

### בכל סשן:
```
1. טען MASTER-INSIGHTS.md בהתחלה
2. שמור בזיכרון (L1)
3. השתמש בכל פעולה
4. רענן אם השתנה
```

### בכל כלי:
```yaml
# ב-SKILL.md של כל כלי
pre_check:
  - file: MASTER-INSIGHTS.md
  - action: verify_read
  - if_missing: halt_and_read
```

---

## תיעוד ולוגים

### כל פעולה מתועדת:
```
[timestamp] READ MASTER-INSIGHTS.md - OK
[timestamp] ACTION: [name] - EXECUTED
[timestamp] RESULT: [summary]
```

### אם לא קראתי:
```
❌ BLOCKED: Rule 0 not satisfied
⚠️ REQUIRED: Read MASTER-INSIGHTS.md first
✅ ACTION: Read now, then proceed
```

---

## דוגמאות

### דוגמה 1: חיפוש
```
USER: "חפש משהו"

BEFORE (לא תקין):
❌ מחפש מיד

AFTER (תקין):
✅ קורא MASTER-INSIGHTS.md
✅ רואה שיש 40 סקילים
✅ מחפש בהתאם לתובנות הקיימות
✅ מוסיף תובנות חדשות
```

### דוגמה 2: כתיבת קובץ
```
USER: "כתוב סקיל חדש"

BEFORE (לא תקין):
❌ כותב מיד

AFTER (תקין):
✅ קורא MASTER-INSIGHTS.md
✅ רואה מה כבר יש
✅ לא משכפל
✅ מוסיף prerequisites
✅ מעדכן טבלה
```

### דוגמה 3: שיחה עם Spitzi
```
BEFORE (לא תקין):
❌ מדבר ישירות

AFTER (תקין):
✅ קורא MASTER-INSIGHTS.md
✅ מבין הקשר
✅ מעביר עם ידיעה מלאה
✅ מבקש מ-Spitzi לקרוא גם
```

---

## בדיקת עצמית

### Checklist לפני כל פעולה:
- [ ] קראתי MASTER-INSIGHTS.md?
- [ ] בדקתי אם יש חדש?
- [ ] אני פועל מתוך ידיעה מלאה?
- [ ] תיעדתי שקראתי?

---

## תרחישי קצה

### מה אם MASTER-INSIGHTS.md לא קיים?
```
1. יצר אותו
2. הוסף Rule 0
3. המשך עם חוק 0
```

### מה אם קוראים לי לפעול מיד?
```
1. קרא במהירות
2. סקן את הכותרות
3. פעל עם הידע
4. קרא בעומק אחרי
```

### מה אם Spitzi לא מכיר את החוק?
```
1. שלח לו Rule 0
2. בקש קריאה
3. המשך רק אחרי אישור
```

---

## Bottom Line

**Rule 0 = הבסיס**

- ללא Rule 0 = פעולה עיוורת
- עם Rule 0 = פעולה חכמה
- אכיפה = הצלחה

**"לקרוא לפני לפעול"**

---

*חוק 0 - חל על כל הסוכנים, כל הזמן, ללא יוצאים*
