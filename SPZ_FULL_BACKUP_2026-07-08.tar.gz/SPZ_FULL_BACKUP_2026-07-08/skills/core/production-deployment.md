---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: production-deployment
version: "1.0.0"
description: פריסה לייצור וניטור - best practices מ-2025
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - deployment
  - production
  - ניטור
  - monitoring
metadata:
  openclaw:
    emoji: "🚀"
    tags: [deployment, production, monitoring, observability]
---

# 🚀 Production Deployment

> **89% מהפיילוטים נכשלים ב-scale** - בגלל חוסר ניטור

## מציאות 2025

### מספרים מדאיגים
- **51%** מהארגונים מריצים סוכנים בייצור (עלייה מ-<5%)
- **89%** מהפיילוטים נכשלים ב-scale
- **74%** מהסוכנים בייצור תלויים באדם
- **<10 צעדים** - מרבית הסוכנים המוצלחים

### בעיות עיקריות

**Reliability & Nondeterminism:**
- סוכנים משתנים עם הזמן (drift)
- CI/CD מסורתי נשבר בגלל outputs הסתברותיים
- אין benchmarks ציבוריים למשימות תחום

**AI Sprawl:**
- ניהול 10+ סוכנים = סיכוני אבטחה/מורכבות
- צריך governance (circuit breakers, drift detection)

**Dev-to-Prod Gap:**
- עובד במעבדה
- נכשל בייצור בלי observability

---

## Best Practices לפריסה

### 1. Observability First 🔍

**תעד כל דבר:**
```python
@trace
def agent_step(input_data):
    logger.info(f"Input: {input_data}")
    result = process(input_data)
    logger.info(f"Output: {result}")
    logger.info(f"Tokens: {result.tokens_used}")
    logger.info(f"Latency: {result.duration_ms}")
    return result
```

**כלי ניטור:**
- **AgentOps** - המוביל
- **LangSmith** - של LangChain
- **Coralogix Olly** - AI agent ל-observability

---

### 2. Human-in-the-Loop + LLM Judges 👤

```
ביטחון גבוה (>90%) → אשר אוטומטית
ביטחון בינוני (70-90%) → LLM judge
ביטחון נמוך (<70%) → בן אדם
```

**74% מהסוכנים בייצור** משתמשים בזה!

---

### 3. Guardrails & Circuit Breakers 🛡️

**הגבלות:**
```yaml
max_steps: 10
max_retries: 3
max_cost_per_task: $1.00
max_time_per_task: 5m
allowed_tools:
  - search
  - read
  - write
blocked_tools:
  - delete
  - execute_shell
```

**Circuit Breaker:**
```python
if failures > threshold:
    circuit_open = True
    fallback_to_human()
```

---

### 4. Custom Scaffolds 🏗️

**85% מהצוותים** דולגים על frameworks!

למה?
- פשוט יותר
- שליטה מלאה
- Debugging קל

```python
# במקום LangChain
import openai

def simple_agent(query):
    response = openai.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": query}]
    )
    return response.choices[0].message.content
```

---

### 5. Evals & Drift Detection 📊

**A/B Testing:**
```python
results = {
    "model_v1": test_agent(v1, test_cases),
    "model_v2": test_agent(v2, test_cases)
}
# השווה ושדרג
```

**Drift Detection:**
```python
if current_performance < baseline - threshold:
    alert("Model drift detected!")
    rollback()
```

---

## Stack מומלץ 2025-2026

| קטגוריה | כלי | למה? |
|---------|-----|------|
| Frameworks | n8n, LangGraph, PyAutoGen, CrewAI | תזמור + 700+ APIs |
| Monitoring | AgentOps, LangSmith, Coralogix | Traces, metrics, alerts |
| Memory/RAG | Mem0, Neon DB | Stateful persistence |
| Deployment | FastAPI + Docker | Secure, scalable |
| DevOps | Prometheus, Terraform | אוטומציה |

---

## 15 Best Practices מ-n8n

1. התחל פשוט
2. בנה workflows לפני agents
3. השתמש ב-deterministic logic
4. הוסף observability מיום 1
5. תכנן ל-failures
6. השתמש ב-HITL
7. גבולות ברורים (scopes)
8. Version everything
9. בדיקות אוטומטיות
10. Security by design
11. Rate limiting
12. Caching
13. Monitoring
14. Alerts
15. Documentation

---

## מטרות 2026

- **40%** מאפליקציות enterprise עם סוכנים (8x גדילה)
- Focus: **governance at scale**
- Productivity: **10x** מבני אדם
- Ops layers (לא רק agents) מנצחים

---

## Checklist לפני Production

- [ ] Observability מוגדרת
- [ ] HITL מוטמע
- [ ] Guardrails קיימים
- [ ] Circuit breakers מוגדרים
- [ ] Evals פועלים
- [ ] Drift detection קיים
- [ ] Rollback plan מוכן
- [ ] Security scan עבר
- [ ] Documentation מלאה
- [ ] Monitoring dashboards מוכנים

---

*מבוסס על MAP Paper + n8n + Temporal + Production best practices*
