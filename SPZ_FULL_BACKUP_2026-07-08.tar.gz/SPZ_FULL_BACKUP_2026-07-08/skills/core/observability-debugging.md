---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: observability-debugging
version: "1.0.0"
description: ניטור ודיבאגינג לסוכני AI - error handling ו-root cause analysis
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - observability
  - debugging
  - ניטור
  - שגיאות
metadata:
  openclaw:
    emoji: "🔍"
    tags: [observability, debugging, monitoring, errors]
---

# 🔍 Observability & Debugging

> **סטנפורד: 500+ כשלונות ניתחו**
> 
> "Error propagation" - טעויות מדורגות גורמות להתמוטטות מוחלטת

## ממצאי מחקר סטנפורד

### דפוסי כשלון עיקריים:

**1. Error Propagation (הנפוץ ביותר)**
- טעויות מוקדמות (בתכנון או זיכרון, צעדים 6-15)
- מדורגות להתמוטטות מוחלטת
- 78 מקרים של שגיאות תכנון

**2. Hallucinations**
- סוכנים מדמיינים אירועים
- מתפרשים תוצאות
- מתעלמים מהגבלות

**3. Tool Misuse**
- שימוש לא נכון בכלים
- הרשאות מיותרות
- פעולות בלתי הפיכות

### נתונים מדאיגים:
- **5x** עלייה בתקריות מאז אוקטובר 2025
- **74%** מהסוכנים תלויים בבדיקה ידנית
- **79%** חסרי governance

---

## כלי ניטור 2025-2026

### Galileo Agent Reliability (יולי 2025)
- Graph/Timeline/Conversation views
- Insights Engine - איתור כשלים אוטומטי
- Luna-2 guardrails
- Free tier

### OpenTelemetry (OTEL) AI Agent Spec
- סטנדרד ל-tracing
- Framework-agnostic
- תואם LangChain, CrewAI

### LangWatch (2025, 2.5k+ GitHub stars)
- Pre-production tracing
- Regression tests
- Self-hosted Docker

### Commvault AI Protect (אפריל 2026)
- Cross-cloud discovery
- Monitoring
- Rollback לפעולות סוכן

### AgentDebug (סטנפורד)
- מיפוי שגיאות למודולים
- תיקונים כירורגיים
- **+26%** הצלחה במשימות

---

## Best Practices

### 1. Trace Everything 📊
```python
from opentelemetry import trace

tracer = trace.get_tracer(__name__)

with tracer.start_as_current_span("agent_step"):
    # כל פעולה מכוסה
    result = process(input)
    # ניטור אוטומטי
```

### 2. Root-Cause Analysis 🔬
```python
# Insights Engine
if failure_detected():
    root_cause = analyze_traces()
    fix = suggest_fix(root_cause)
    apply_fix(fix)
```

### 3. Guardrails בזמן אמת 🛡️
```python
# Luna-2 או SLM דומה
if risk_detected():
    intervene_realtime()
```

### 4. Multi-Dimensional Evals 📈
```
מדדים:
- Task Success Rate
- Efficiency
- Flow Adherence
- Cost
- Latency
- Safety Score
```

### 5. Security Layers 🔒
```
Agent Registry
↓
Risk Signals
↓
SIEM/DLP Integration
↓
Rollback Capability
```

---

## טיפול בשגיאות

### סיווג שגיאות:
| סוג | תדירות | פתרון |
|-----|--------|-------|
| Planning | גבוה | תכנון מחדש |
| Memory | בינונית | External state |
| Tool | נמוכה | Validation |
| Hallucination | בינונית | Multi-agent verify |

### Error Propagation Prevention:
```python
# Isolate errors
try:
    step_result = execute_step()
except Exception as e:
    # תעד, אל תתמודד
    log_error(e)
    # נסה אסטרטגיה חלופית
    fallback_result = fallback_strategy()
    # בדוק אם fallback הצליח
    if not fallback_result:
        escalate_to_human()
```

---

## מדדים לניטור

### חובה:
- **Token Usage** - עלות לכל משימה
- **Latency** - זמן תגובה
- **Success Rate** - % הצלחה
- **Error Rate** - % שגיאות
- **Cost per Outcome** - ROI

### מומלץ:
- **Decision Trace** - מעקב החלטות
- **Tool Usage** - אילו כלים נקראו
- **Handoff Quality** - מעברים בין סוכנים
- **Drift Detection** - שינויי התנהגות

---

## כלים מומלצים

| כלי | שימוש | עלות |
|-----|-------|------|
| Galileo | Multi-agent observability | Free tier |
| LangWatch | Pre-prod testing | Free/OSS |
| OTEL | Tracing standard | Free |
| LangFuse | Monitoring | Free tier |
| AgentDebug | Self-debugging | Research |

---

## Checklist לניטור

- [ ] Tracing לכל span
- [ ] Metrics collection
- [ ] Alerting על thresholds
- [ ] Root-cause analysis
- [ ] Rollback capability
- [ ] Guardrails פעילים
- [ ] Security monitoring
- [ ] Cost tracking

---

*מבוסס על Stanford Agent Debugging + 2025 production tooling*
