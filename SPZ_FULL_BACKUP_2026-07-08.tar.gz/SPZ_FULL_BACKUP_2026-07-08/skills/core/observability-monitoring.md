---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: observability-monitoring
version: "1.0.0"
description: Observability ו-monitoring - metrics, logs, tracing לסוכני AI
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - observability
  - monitoring
  - metrics
  - tracing
  - logs
  - ניטור
metadata:
  openclaw:
    emoji: "📊"
    tags: [observability, monitoring, metrics, tracing, logs]
---

# 📊 Observability & Monitoring

> **The 3 Pillars: Metrics, Logs, Tracing**
> 
> Agent observability = Production readiness

## למה Observability חשובה?

### האתגרים:
```
AI Agents:
├── Silent failures
├── Multi-agent workflows
├── Tool-call tracing
├── Compliance/audits
└── Governance
```

### הפתרון:
```
Observability:
├── Metrics (what)
├── Logs (why)
└── Tracing (where)
```

---

## ה-3 עמודים

### 1. Metrics

**מה זה:** High-level performance data

**Examples:**
- CPU usage
- Latency (TTFT, TBT, total)
- Error rates
- Token usage
- Cost per action

**Tools:**
- Prometheus
- CloudWatch
- Mimir

**Implementation:**
```python
from prometheus_client import Counter, Histogram

# Counters
request_count = Counter('agent_requests_total', 'Total requests')
error_count = Counter('agent_errors_total', 'Total errors')

# Histograms
latency = Histogram('agent_latency_seconds', 'Request latency')

# Usage
@latency.time()
def process_request():
    request_count.inc()
    try:
        result = agent.execute()
        return result
    except Exception:
        error_count.inc()
        raise
```

---

### 2. Logs

**מה זה:** Detailed event records

**Types:**
- Structured logs (JSON)
- Tool calls
- Agent decisions
- Errors

**Tools:**
- Loki
- ELK stack
- OpenTelemetry

**Implementation:**
```python
import structlog

logger = structlog.get_logger()

def agent_action(action, context):
    logger.info(
        "agent_action",
        action=action,
        context=context,
        timestamp=datetime.now()
    )
    
    result = execute(action)
    
    logger.info(
        "agent_result",
        action=action,
        result=result,
        duration=calculate_duration()
    )
    
    return result
```

---

### 3. Tracing

**מה זה:** End-to-end request flows

**Use cases:**
- Multi-agent workflows
- Distributed systems
- Performance bottlenecks

**Tools:**
- Jaeger
- OpenTelemetry
- Tempo

**Implementation:**
```python
from opentelemetry import trace

tracer = trace.get_tracer(__name__)

@tracer.start_as_current_span("agent_workflow")
def agent_workflow(input):
    with tracer.start_as_current_span("retrieve_context"):
        context = retrieve(input)
    
    with tracer.start_as_current_span("agent_reasoning"):
        reasoning = agent.think(context)
    
    with tracer.start_as_current_span("execute_action"):
        result = execute(reasoning)
    
    return result
```

---

## AI Agent-Specific Tools

### LangSmith (LangChain)
```python
# Tracing + latency/cost breakdowns
from langsmith import traceable

@traceable
def agent_run(input):
    return agent.execute(input)

# Automatic tracking of:
# - Token usage
# - API calls
# - Tool invocations
# - Latency
```

### Galileo (Cisco/Splunk)
```
Agent Reliability Platform:
├── Graph/timeline views
├── Failure analysis
├── Guardrails (Luna-2 models)
└── Production-grade
```

### AI SDK (Vercel)
```javascript
// 2-line logger
import { Agent } from 'ai';

const agent = new Agent({
  onLog: (log) => console.log(log.tokens, log.cost, log.tools)
});
```

### Amazon Bedrock
```
Agents Metrics in CloudWatch
├── Built-in monitoring
├── Token tracking
└── Cost analysis
```

### Open Source
- **Hermes HUD** - Agent monitoring UI
- **rtcollector** - RedisTimeSeries agent
- **Xata Agent** - PostgreSQL monitoring

---

## Stacks מומלצים

### LGTM Stack
```
L - Loki (Logs)
G - Grafana (Visualization)
T - Tempo (Tracing)
M - Mimir (Metrics)
```

### OpenTelemetry + Prometheus/Jaeger
```
OpenTelemetry:
├── Unified instrumentation
├── Vendor-neutral
└── Auto-instrumentation

Prometheus + Jaeger:
├── Metrics collection
├── Distributed tracing
└── Alerting
```

---

## מדדים חשובים לסוכנים

### Performance:
- Time to First Token (TTFT)
- Time Between Tokens (TBT)
- Total latency
- Token throughput

### Quality:
- Success rate
- Error rate
- Hallucination rate
- User satisfaction

### Cost:
- Tokens per action
- Cost per action
- Daily/weekly spend

### Operational:
- API availability
- Rate limit hits
- Circuit breaker triggers

---

## Alerts & Notifications

### Thresholds:
```python
ALERTS = {
    "error_rate": {
        "warning": 0.05,    # 5%
        "critical": 0.10    # 10%
    },
    "latency": {
        "warning": 2.0,     # 2 seconds
        "critical": 5.0     # 5 seconds
    },
    "cost": {
        "warning": 100,     # $100/day
        "critical": 500     # $500/day
    }
}

def check_alerts(metrics):
    for metric, value in metrics.items():
        if value > ALERTS[metric]["critical"]:
            send_alert(metric, value, "CRITICAL")
        elif value > ALERTS[metric]["warning"]:
            send_alert(metric, value, "WARNING")
```

---

## 2025-2026 Trends

### AI Anomaly Detection
```python
# ML-based anomaly detection
from anomaly_detector import Detector

detector = Detector(model="isolation_forest")

if detector.is_anomaly(current_metrics):
    alert_team()
```

### Multi-Agent Tracking
```
End-to-end tracing across agents:
Agent A → Agent B → Agent C
   ↓        ↓        ↓
  Span 1   Span 2   Span 3
   └────────┴────────┘
        Single trace
```

### Regulation-Ready Auditing
```
EU AI Act compliance:
├── Audit trails
├── Decision logs
└── Explainability
```

### M&A Activity
```
Cisco buys Galileo:
- AI agent observability = Hot market
- Agents as prime targets
```

---

## Best Practices

### Implementation:
1. ✅ Structured logs (JSON)
2. ✅ Distributed tracing
3. ✅ Metrics aggregation
4. ✅ Alert thresholds
5. ✅ Dashboards
6. ✅ Retention policies

### Production:
- Instrument early
- Monitor costs
- Track quality
- Alert on anomalies
- Audit everything

---

## Bottom Line

**Observability = Production Readiness**

- Metrics = What
- Logs = Why
- Tracing = Where

**"You can't improve what you don't measure"**

---

*מבוסס על 2025 observability practices + LangSmith/Galileo + OpenTelemetry*
