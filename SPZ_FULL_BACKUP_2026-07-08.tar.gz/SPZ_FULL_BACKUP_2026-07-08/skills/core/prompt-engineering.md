---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: prompt-engineering
version: "1.0.0"
description: הנדסת פרומפטים 2025 - system prompts כקוד, few-shot, ו-meta-prompting
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - prompt
  - פרומפט
  - system prompt
  - engineering
metadata:
  openclaw:
    emoji: "📝"
    tags: [prompt, engineering, system, few-shot]
---

# 📝 Prompt Engineering 2025

> **Treat Prompts as Code**> 
> Version control, A/B testing, evals - לא tweaks ידניים

## עקרונות ליבה 2025+

### 1. Prompts = Code

**Git versioning:**
```bash
git add prompts/system_prompt_v2.yaml
git commit -m "Add guardrails for PII"
```

**A/B Testing:**
- Promptfoo
- DSPy
- Weights & Biases

**Evals:**
```python
# Test cases > manual tweaks
test_cases = [
    {"input": "...", "expected_output": "..."},
    {"input": "...", "expected_output": "..."}
]
results = evaluate(prompt_v1, test_cases)
results_v2 = evaluate(prompt_v2, test_cases)
# השווה
```

---

### 2. Structure Over Magic

**System Prompt Template:**
```xml
<role>
  You are a precise MLOps agent
  Goals: [deploy models reliably]
  Constraints: [no PII, verify facts]
</role>

<tools>
  Available: grep, shell, vector DB search
</tools>

<format>
  Output as JSON:
  {
    "reasoning": "...",
    "action": "...",
    "output": {...}
  }
</format>

<examples>
  [2-5 few-shot pairs]
</examples>

<memory>
  Retrieve top-3 episodic summaries
</memory>

Think step-by-step. Critique if unsure.
```

**Manager-style docs:**
- 6+ עמודים
- XML tags
- Roles ברורים
- Meta-prompting

---

### 3. Few-Shot > Zero-Shot

**ההבדל:**
```
Zero-Shot:  0% → ?
Few-Shot:   0% → 90%

(במיקור רפואי, עם 2-5 דוגמאות איכות)
```

**דוגמאות איכות:**
```python
examples = [
    {
        "input": "משימה פשוטה",
        "thought": "חשיבה ביניים",
        "output": "תוצאה נכונה"
    },
    # 2-5 כאלה
]
```

---

### 4. Context Engineering > Prompt Engineering

**עם חלונות של 1M+ טוקנים:**
- **Compression** - דחיסה חכמה
- **RAG reranking** - HyDE, metadata filters
- **Semantic caching** - אל תחשב מחדש
- **Episodic/Long-term memory** - זיכרון מדורג

**סדר חשוב:**
```
1. Relevant background
2. Current task
3. Constraints
4. Examples
```

---

## טכניקות מתקדמות

### Self-Criticism
```python
draft = generate(prompt, input)
critique = generate(critique_prompt, draft)

if critique.issues_found:
    improved = generate(improve_prompt, draft, critique)
    return improved
else:
    return draft
```

### Dynamic Few-Shot
```python
# Retrieve from vector DB
similar_cases = vector_db.search(query, top_k=3)
examples = format_examples(similar_cases)
prompt = build_prompt_with_examples(base_prompt, examples)
```

### Meta-Prompting
```
"שפר את הפרומפט הבא על בסיס התוצאות שקיבלנו
[prompt]
[results]
[feedback]"
```

### Distillation
```
1. Craft with big models (o1, Grok-4)
2. Deploy on fast/cheaper (grok-code-fast)
3. שמור על 95% איכות, 50% עלות
```

---

## OpenAI Skills/Shell

**Lazy-load skills:**
```python
skill = load_skill("data_analysis")  # רק כשצריך
```

**Compaction:**
```python
# לריצות ארוכות
compact_context(current_context, max_tokens=4000)
```

**Domain secrets:**
```yaml
secrets:
  - api_keys
  - credentials
  # מופרדים מהפרומפט
```

---

## Security & Reliability

### Prompt Injection Defense
```python
# לא "ignore previous instructions"
# הגדרה ברמת המודל

def validate_input(user_input):
    if contains_injection_patterns(user_input):
        raise SecurityError()
    return sanitized_input
```

### Escape Hatches
```
"Admit uncertainty" - תודה כשלא יודע
מונע הזיות!
```

### Multi-Agent
```
Researcher → Writer → Fact-Checker
↓
Quality ↑
```

---

## Best Practices Checklist

- [ ] Version control ב-git
- [ ] A/B testing מובנה
- [ ] Evals אוטומטיים
- [ ] Few-shot examples
- [ ] Structured output (JSON/XML)
- [ ] Self-criticism
- [ ] Guardrails ל-PII
- [ ] HITL ל-high-stakes
- [ ] Compression
- [ ] Security (לא "ignore previous")

---

## Template מוכן 2026

```xml
<agent>
  <role>{detailed_role}</role>
  <goals>{specific_goals}</goals>
  <constraints>{hard_limits}</constraints>
  <tools>{available_tools}</tools>
  <format>{output_format}</format>
  <examples>
    <example>
      <input>...</input>
      <thought>...</thought>
      <output>...</output>
    </example>
  </examples>
  <memory>{memory_instructions}</memory>
  <workflow>{step_by_step}</workflow>
</agent>
```

---

## Bottom Line

**Prompting חי בעידן הסוכנים**

- Focus על מערכות, לא hacks
- Context engineering > prompt engineering
- Treat as code
- Test עם evals

---

*מבוסס על 2025 best practices + Anthropic/OpenAI guidelines*
