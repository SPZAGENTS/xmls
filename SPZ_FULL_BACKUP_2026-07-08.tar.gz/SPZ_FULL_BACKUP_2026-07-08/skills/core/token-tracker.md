---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: token-tracker
version: "1.0.1"
description: מעקב אחרי טוקנים ועלויות בזמן אמת - cost-per-outcome
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - עלות
  - טוקנים
  - budget
  - מחיר
metadata:
  openclaw:
    emoji: "📊"
    tags: [cost, monitoring, tracking, tokens]
---

# 📊 מעקב טוקנים ועלויות

## יעד
לדעת בכל רגע: כמה עולה כל פעולה ומה ה-value שיוצא ממנה.

## מבנה הנתונים

```json
{
  "session_id": "uuid",
  "timestamp": "2026-04-19T08:30:00Z",
  "action": "x_search",
  "model": "grok-4-1-fast",
  "tokens_in": 150,
  "tokens_out": 2000,
  "cost_usd": 0.015,
  "duration_ms": 12000,
  "success": true,
  "outcome": "7 insights found",
  "cost_per_outcome": 0.0021
}
```

## פונקציות ליבה

```javascript
class TokenTracker {
  constructor() {
    this.dailyLog = [];
    this.sessionStart = Date.now();
    this.dailyBudget = 30000; // טוקנים
  }

  logAction(action) {
    const entry = {
      ...action,
      timestamp: new Date().toISOString(),
      session_elapsed: Date.now() - this.sessionStart
    };
    this.dailyLog.push(entry);
    return entry;
  }

  getDailyStats() {
    const total = this.dailyLog.reduce((sum, e) => ({
      tokens: sum.tokens + e.tokens_in + e.tokens_out,
      cost: sum.cost + e.cost_usd,
      actions: sum.actions + 1,
      success: sum.success + (e.success ? 1 : 0)
    }), {tokens: 0, cost: 0, actions: 0, success: 0});

    return {
      ...total,
      cost_per_action: total.cost / total.actions,
      success_rate: total.success / total.actions,
      budget_remaining: this.dailyBudget - total.tokens
    };
  }

  shouldStop() {
    const stats = this.getDailyStats();
    return stats.tokens >= this.dailyBudget * 0.9; // 90% = עצור
  }

  getCostPerOutcome(outcome) {
    const relevant = this.dailyLog.filter(e => e.outcome === outcome);
    if (relevant.length === 0) return null;
    return relevant.reduce((sum, e) => sum + e.cost_usd, 0) / relevant.length;
  }
}
```

## דשבורד פשוט

```
┌─────────────────────────────────────┐
│  Daily Token Usage                  │
│  ████████████████████░░░░░  78%   │
│                                     │
│  Actions:     15                    │
│  Cost:        $1.23                 │
│  Success:     93%                   │
│                                     │
│  Cost/Action: $0.082                │
│  Cost/Insight: $0.021               │
└─────────────────────────────────────┘
```

## אינטגרציה עם OpenClaw

```javascript
// לפני כל פעולה
const tracker = new TokenTracker();

// אחרי כל פעולה
tracker.logAction({
  action: "x_search",
  model: "grok-4-1-fast",
  tokens_in: inputTokens,
  tokens_out: outputTokens,
  cost_usd: calculateCost(inputTokens, outputTokens),
  success: true,
  outcome: "insights_found"
});

// בדוק אם לעצור
if (tracker.shouldStop()) {
  console.log("Budget limit approaching - stopping");
}
```

## יעדים

- **Daily budget:** 30K tokens
- **Cost per action:** <$0.10
- **Cost per insight:** <$0.05
- **Success rate:** >90%

---

*יישום של תובנה מ-2025 - מעקב עלויות*
