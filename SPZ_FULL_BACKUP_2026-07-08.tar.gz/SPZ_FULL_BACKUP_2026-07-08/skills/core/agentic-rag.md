---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: agentic-rag
version: "1.0.0"
description: Agentic RAG ו-knowledge management - מעבר ל-retrieval סטטי
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - agentic RAG
  - knowledge management
  - documentation
  - RAG
metadata:
  openclaw:
    emoji: "📚"
    tags: [rag, knowledge, documentation, agentic, memory]
---

# 📚 Agentic RAG

> **RAG has evolved far beyond static document retrieval**
> 
> 2025 = Agentic infrastructure for living knowledge bases

## אבולוציה של RAG

### שלב 1: Vanilla RAG (2020-2023)
```
Read-only, one-shot:
├── Static documents
├── Offline storage
├── No validation
└── Manual updates

Limitations:
- Blind retrieval
- No decision making
- Stale knowledge
```

### שלב 2: Agentic RAG (2023-2024+)
```
Agents gained decision-making:
├── Route queries to tools
├── Validate relevance
├── Multi-step reasoning
└── Dynamic retrieval

Improvements:
- Intelligent routing
- Context validation
- Tool selection
```

### שלב 3: Agent Memory (2024+, exploding 2025)
```
Read + Write access:
├── Create knowledge
├── Update during interactions
├── Delete obsolete
└── Persistent sessions

Types:
- Episodic (events)
- Semantic (facts)
- Procedural (behaviors)
```

---

## סוגי Agentic RAG

### 1. Adaptive RAG
```python
# Adjusts for query complexity
if query_complexity(query) == "high":
    use_multi_step_retrieval()
    use_reasoning_chain()
else:
    use_single_retrieval()
```

### 2. Corrective RAG (CRAG)
```python
# Fixes bad context
retrieved = retrieve(query)

if not validate_relevance(retrieved, query):
    retrieved = retrieve_alternative(query)
    
# Retry with different strategy
```

### 3. Self-Reflective RAG
```python
# Critiques outputs
draft = generate_with_rag(query, context)
critique = critique_output(draft)

if critique.issues:
    improved = regenerate_with_fixes(draft, critique)
    return improved
```

### 4. Speculative RAG
```python
# Drafts and verifies fast
draft = fast_draft(query)
verified = verify_facts(draft)

if verified.confidence > 0.9:
    return draft
else:
    return detailed_generation(query)
```

---

## יישומים ב-Documentation & KM

### Enterprise Docs
```
Mixture of Block Attention (MoBA):
├── Sparse attention via MoE
├── Handles long docs
├── No quadratic compute costs
└── Entire codebase processing
```

### Self-Healing Docs
```python
# Agents read codebases
codebase = load_repository()

# Detect drift
if docs_outdated(codebase, documentation):
    # Draft updates
    updates = generate_doc_updates(codebase)
    
    # Seek human approval
    if human_approve(updates):
        apply_updates(updates)
```

### Voice/Document RAG
```
Process uploads → Optimize for TTS
Build tax/legal agents → Cite sources
```

### Navigable Knowledge
```
Distill docs into skill trees
Shared memory across agents
memsearch with Markdown logs
```

---

## השוואת שלבים

| Stage | Retrieval | Knowledge Update | Use Case |
|-------|-----------|------------------|----------|
| Vanilla | Always retrieve, static | Manual/offline | Simple search |
| Agentic | Agent chooses | Read-only | Routing, validation |
| Agent Memory | Read + write | Real-time | Personalized KM |

---

## Best Practices

### 1. Layered Recall
```python
# Search → Section → Transcript
def retrieve(query):
    # Level 1: Quick search
    candidates = vector_search(query, top_k=10)
    
    # Level 2: Section analysis
    relevant = analyze_sections(candidates)
    
    # Level 3: Full transcript
    if still_uncertain(relevant):
        return get_full_context(relevant)
    
    return relevant
```

### 2. Tool Integration
```python
tools = [
    VectorDBSearch(),
    WebSearch(),
    APICall(),
    DocumentParser()
]

# Agent chooses
def agent_choose_tool(query):
    if needs_web_info(query):
        return WebSearch()
    elif needs_internal_docs(query):
        return VectorDBSearch()
```

### 3. Write Access
```python
# Update knowledge during interactions
@after_interaction
def update_knowledge(interaction):
    if new_fact_detected(interaction):
        vector_db.add(interaction.new_fact)
    
    if obsolete_detected(interaction):
        vector_db.delete(interaction.obsolete)
```

### 4. Validation
```python
def validate_context(context, query):
    relevance_score = calculate_relevance(context, query)
    
    if relevance_score < 0.7:
        return False, "Low relevance"
    
    if contradictions_detected(context):
        return False, "Contradictions found"
    
    return True, context
```

---

## Challenges & Fixes

### Issues:
1. **Memory corruption**
2. **Forgetting logic**
3. **Latency**
4. **Security** (leaking keys via context)

### Fixes:
1. **Durable execution** - TypeScript frameworks
2. **Event-driven infra** - Async processing
3. **Layered recall** - Search → Section → Transcript
4. **Security scanning** - Context validation

---

## Tools & Frameworks

### Orchestration:
- LangChain
- CrewAI
- OpenAI Agents SDK

### Vector DBs:
- Milvus
- Weaviate
- Pinecone

### Advanced:
- MoBA (GitHub: MoonshotAI/MoBA)
- memsearch
- TypeScript frameworks with observability

---

## Checklist ל-Agentic RAG

- [ ] Agent routing logic
- [ ] Multi-tool support
- [ ] Context validation
- [ ] Write access (CRUD)
- [ ] Memory types (episodic/semantic/procedural)
- [ ] Self-reflection
- [ ] Correction mechanisms
- [ ] Observability
- [ ] Security controls

---

## Bottom Line

**RAG 2025 = Living Knowledge, Not Static Search**

- Read + Write
- Agent-driven
- Self-healing
- Continuously updated

**2025 = Year of Agentic RAG**

---

*מבוסס על 2025 RAG evolution + MoBA + Self-healing docs*
