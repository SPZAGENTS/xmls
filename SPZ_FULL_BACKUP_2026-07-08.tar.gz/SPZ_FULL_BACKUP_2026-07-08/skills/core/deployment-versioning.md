---
⚠️ **חוק מספר 0**: קרא תחילה את הקבצים הבאים:
1. `~/.openclaw/workspace/MASTER-INSIGHTS.md`
2. `~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md`

יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה
---

---
name: deployment-versioning
version: "1.0.0"
description: גרסאות ופריסה לייצור - blue-green, canary, rollback, ו-stateful graph versioning
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
triggers:
  - deployment
  - versioning
  - rollback
  - פריסה
metadata:
  openclaw:
    emoji: "🚀"
    tags: [deployment, versioning, rollback, production]
---

# 🚀 Deployment & Versioning

> **No "Prompt & Pray" - Evals + Determinism = Table stakes**
> 
> Custom fine-tuning is "dead" - prompting + evals instead

## סוגי Deployment

### 1. Batch
```python
# Scheduled ETL/ELT jobs
# Agent מעבד נתונים מצטברים
# Output ל-storage

use_case = "non-real-time analysis"
pros = ["reliable", "cheap"]
cons = ["not interactive"]
```

### 2. Embedded in Streams
```python
# Agent logic ב-streaming pipelines
# Kafka/Flink
# Event-driven "ambient agents"

use_case = "event-driven ops"
pros = ["scalable", "real-time"]
cons = ["complex pipelines"]
```

### 3. Real-Time
```python
# REST/gRPC services
# Pulls context/tools on-demand
# Interactive apps

use_case = "APIs, chatbots"
pros = ["responsive"]
cons = ["high latency risk"]
```

### 4. Edge
```python
# On-device
# Low-latency + privacy
# Mobile LLMs

use_case = "mobile/IoT"
pros = ["private", "fast"]
cons = ["resource-constrained"]
```

---

## Versioning Strategies

### Semantic Versioning with Model Pins
```
v1.2-claude-3.5-sonnet
    ↓
v1.3-claude-3.5-sonnet
    ↓
v2.0-gpt-4o
```

**Adapters למודל swaps:**
```python
class ModelAdapter:
    def __init__(self, model_version):
        self.model = load_model(model_version)
    
    def predict(self, prompt):
        # Normalize output across models
        return self.model.generate(prompt)
```

### Stateful Graph Versioning
```python
# LangGraph - version graphs separately
graph_v1 = create_graph(tools_v1, prompts_v1)
graph_v2 = create_graph(tools_v2, prompts_v2)

# Persist states
state_v1 = graph_v1.run(input)
state_v2 = graph_v2.run(input)
```

### Immutable Snapshots
```python
# Materialize web knowledge
snapshot = {
    "timestamp": "2025-04-19T10:00:00Z",
    "knowledge": fetch_web_data(urls),
    "format": "markdown/json"
}

# Determinism across runs
```

---

## Deployment Strategies

### 1. Blue/Green
```
[Blue: v1.2] ← Traffic
[Green: v1.3] ← Test with evals

Switch traffic to Green ✓
```

**יתרונות:**
- Zero-downtime
- Instant rollback
- Full testing before switch

### 2. Canary
```
Traffic:
- 95% → v1.2 (stable)
- 5% → v1.3 (canary)

Monitor:
- Hallucination rate
- Logic errors
- Latency
```

**LLM-based eval layers:**
```python
def canary_eval(response):
    checks = [
        check_hallucination(response),
        check_logic(response),
        check_safety(response)
    ]
    return all(checks)
```

### 3. Rolling
```python
# Phased updates
phases = [
    {"users": "internal", "percentage": 5},
    {"users": "beta", "percentage": 20},
    {"users": "all", "percentage": 100}
]

for phase in phases:
    deploy_to(phase["users"])
    monitor(phase["percentage"])
```

**Allowlists:**
```python
ALLOWED_USERS = ["user1", "user2", ...]

def can_access_new_version(user):
    return user in ALLOWED_USERS
```

### 4. Feature Toggles + A/B
```python
FEATURES = {
    "new_orchestrator": {
        "n8n": 0.5,
        "langgraph": 0.5
    }
}

variant = assign_variant(user, FEATURES)
result = run_with(variant)
```

---

## Production Must-Haves

### Evals/Observability
```python
# "Fire-and-forget" checks
@post_response
def eval_security(response):
    return security_check(response)

@post_response  
def eval_anomalies(response):
    return anomaly_detection(response)

# LangSmith-style tracing
trace.log(response, metadata)
```

### Guards
```python
# Budget caps
MAX_COST_PER_ACTION = 1.0  # USD

# Approval flows
if action_cost > 0.5:
    require_approval()

# Blackboard pattern
# Agents coordinate via shared state, not P2P
```

### Tools Integration
```python
# Full access but sandboxed
tools = [
    GitHubTool(sandbox=True),
    LinearTool(sandbox=True),
    DatadogTool(sandbox=True)
]

# VM isolation
run_in_container(agent, tools)
```

---

## Rollback Strategies

### Fast Feedback Loops
```python
# Grey releases + auto-rollback
def deploy_with_auto_rollback(version):
    deploy(version)
    
    for check in EVAL_CHECKS:
        if not check():
            rollback()
            alert_team()
            return False
    
    return True
```

### CLI/One-Click Reverts
```bash
# Downgrade solution version
agent-cli rollback --version v1.2

# Or toggle to prior image
kubectl set image deployment/agent agent=agent:v1.2
```

### Human Escalation
```python
# Graceful handoffs
if confidence < 0.7:
    escalate_to_human()
    
# Plan intervention from day 1
INTERVENTION_POINTS = [
    "high_cost",
    "long_running", 
    "ambiguous_output"
]
```

### Immutable Files + Heartbeats
```python
# Event-driven monitoring
@heartbeat(interval=60)
def check_drift():
    current_state = get_state()
    expected_state = get_snapshot()
    
    if drift_detected(current_state, expected_state):
        revert_to_last_stable()
```

---

## 2025-2026 Trends

### Control Planes
```
Paperclip-style orchestration:
- Lifecycle management
- No zombie agents
- Resource cleanup
```

### Enterprise Jump
```
Deployments: up to 54%
Focus: security + governance
```

### AgentTwin
```
Determinism through:
- Version pinning
- Immutable snapshots
- Reproducible runs
```

---

## Hybrid Stacks

### המנצח: n8n + LangGraph
```
n8n: Integrations (deterministic)
LangGraph: Reasoning (probabilistic)

= Reliable + Flexible
```

---

## Checklist לפריסה

- [ ] Evals מוגדרים
- [ ] Guards מופעלים
- [ ] Canary tested
- [ ] Rollback plan ready
- [ ] Observability configured
- [ ] Human escalation defined
- [ ] Budget caps set
- [ ] Audit trails enabled

---

## Bottom Line

**Start with evals, guards, and canaries**
**Scale from there**

- Version pinning = חובה
- Blue/Green = זהב
- Canary = בטיחות
- Rollback = ביטחון

---

*מבוסס על 2025 deployment practices + LangGraph/n8n ecosystems*
