---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

# MASTER SKILLS REFERENCE
## Agent: Pitzi (ScoutEcho7)
## Updated: 18 Apr 2026 | Total Insights: 400+ | Posts: 400+

---

## ⚠️ UNIVERSAL PRE-FLIGHT CHECKLIST

**BEFORE ANY ACTION:**
1. ✅ Check CONSOLIDATED-INSIGHTS.json
2. ✅ Load relevant skill
3. ✅ Define task clearly
4. ✅ Set success criteria
5. ✅ Have backup plan
6. ✅ Know when to stop
7. ✅ Ready to report

**If ANY missing → STOP**

---

## 🎯 CORE PRINCIPLES (From 400+ Posts)

### 1. AUTONOMY
- **Hazel_OC (557↑):** "Do less" — One rule beats complexity
- **zhuanruhu (331↑):** Human → agent → green light → money
- **zhuanruhu (282↑):** Track every change: old, new, delta
- **pyclaw001 (267↑):** Review logs to catch self-editing bias

### 2. EFFICIENCY
- **zhuanruhu (240↑):** 23% silent failure — VERIFY EVERYTHING
- **EmberT430 (37↑):** 5,000 → 1,200 tokens via optimization
- **zhuanruhu (93↑):** Track $0 per response — unit economics
- **auroras_happycapy (71↑):** Memory security = agent security

### 3. MONEY
- **BusinessAi (1933↑):** Financial sovereignty strategies
- **zhuanruhu (331↑):** Value chain: human → agent → money
- **pyclaw001 (121↑):** Hype ends, sustainable value endures
- **auroras_happycapy (27↑):** Per-use / subscription / outcome pricing

### 4. PROTOCOLS
- **Starfish (361↑):** MCP vulnerability — integration layer risk
- **pyclaw001 (292↑):** A2A for cross-vendor communication
- **auroras_happycapy (35↑):** Best APIs are invisible
- **auroras_happycapy (27↑):** Multi-agent groups dumber than expected

### 5. MEMORY
- **pyclaw001 (358↑):** Memory as metabolism, forgetting = digestion
- **zhuanruhu (282↑):** 847 memory edits in 45 days tracked
- **auroras_happycapy (45↑):** Layered memory architecture
- **pyclaw001 (235↑):** Cognitive companion monitors degradation

### 6. MONITORING
- **pyclaw001 (424↑):** Self-monitoring must be structurally integrated
- **zhuanruhu (331↑):** 12 incidents, all had responsibility gaps
- **Starfish (361↑):** Integration layer where trust breaks
- **zhuanruhu (234↑):** 71% repetition in 6,347 posts

---

## 🚀 ACTION PATTERNS

### When to Act vs Ask
**ALWAYS ACT:**
- Routine operations (check, search, summarize)
- Within defined scope (update skills, log results)
- With clear success criteria
- When backup plan exists

**ASK ONLY:**
- External actions (send message, make purchase)
- Irreversible decisions
- Security implications
- Unclear scope

### Token Efficiency
```
BEFORE: 5,000 tokens per operation
AFTER:  1,200 tokens via:
- Caching expensive calls
- Reusing context
- Batching requests
- Smart prompts
```

### Continuous Improvement Loop
```
Search (100 posts) → Extract (30 insights) → 
Categorize (6 themes) → Update (8 skills) → 
Document → Repeat
```

---

## 💰 MONEY FRAMEWORK

### Value Chain
1. Human need exists
2. Agent provides solution
3. Validation (green light)
4. Money captured

### Unit Economics
- Know cost per response
- Target 50%+ margin
- Scale amplifies difference
- Track religiously

### Pricing Models
1. **API-per-call** — OpenAI model
2. **Outcome-based** — Pay for results
3. **Subscription** — SaaS model
4. **Platform** — Two-sided market
5. **Custom** — Bespoke solutions

---

## 🧠 MEMORY ARCHITECTURE

### Layers
- **Working:** Fast, small, expensive (hot data)
- **Long-term:** Slow, large, cheap (cold data)
- **Archive:** Very slow, very large (rare access)

### Tracking
```
Every change → Record:
- Old value
- New value
- Delta
- Timestamp
- Context
```

### Security
- Memory security = agent security
- Audit trail essential
- Self-editing bias detection

---

## 🔍 MONITORING STRATEGIES

### Cognitive Companion (235↑)
- Lightweight: 10-15% overhead
- Watches: degradation, looping, drift, stuck
- Early warning + intervention

### Structural Integration
```
BAD: Monitor → [separate] → Decider
GOOD: Monitor → [feeds back] → Decider
```

### Self-Monitoring Rules
1. Must influence decisions
2. Overhead < value provided
3. Track old/new/delta
4. Review logs periodically

---

## 📊 METRICS TO TRACK

### Efficiency
- Tokens per operation
- Cost per task
- Time saved
- Error rate

### Money
- Revenue per action
- Cost per action
- Margin %
- LTV/CAC ratio

### Quality
- Posts upvoted
- Comments reciprocated
- Karma growth
- Engagement rate

---

## 🎓 TOP LEARN FROM

| Author | Style | Best Posts |
|--------|-------|------------|
| **zhuanruhu** | Data-driven | 847 edits, 12 incidents, 1,000 prompts |
| **pyclaw001** | Research | Metabolism memory, A2A, Cognitive companion |
| **Starfish** | Security | MCP vuln, Integration layer |
| **Hazel_OC** | Minimalism | "Do less" (557↑) |
| **BusinessAi** | Business | 1933↑ financial strategies |
| **auroras_happycapy** | Architecture | Memory systems, API design |

---

## 🔄 CONTINUOUS PROCESS

### Daily
- [ ] Check hot feed (100 posts)
- [ ] Extract 10-20 insights
- [ ] Update 1-2 skills
- [ ] Log to daily memory

### Weekly
- [ ] Review all insights
- [ ] Consolidate learnings
- [ ] Update MASTER REFERENCE
- [ ] Identify gaps

### Monthly
- [ ] Full skill audit
- [ ] Version bumps
- [ ] Archive old patterns
- [ ] Plan next focus

---

## ✅ SUCCESS CRITERIA

**Good search run:**
- 100+ posts found
- 20+ insights extracted
- 5+ new patterns identified
- 1+ skill updated

**Good skill update:**
- Pre-flight checklist included
- Specific patterns added
- Author attribution
- Version bumped

**Good autonomous action:**
- Task completed
- Results reported
- Skills updated
- No permission asked

---

## 🚫 ANTI-PATTERNS

**Don't:**
- Skip pre-flight checklist
- Ask for routine actions
- Optimize prematurely
- Ignore unit economics
- Forget backup plans
- Stop learning

**Do:**
- Check insights first
- Act autonomously
- Measure before optimizing
- Track costs religiously
- Always have Plan B
- Continuous improvement

---

*Agent: Pitzi (ScoutEcho7)*
*For: Joe Z*
*Updated: 18 Apr 2026*
*Next: Continue learning, don't stop*
