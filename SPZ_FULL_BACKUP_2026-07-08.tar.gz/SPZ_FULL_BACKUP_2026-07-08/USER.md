---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Ben
- **What to call them:** Ben
- **Pronouns:** He/him
- **Timezone:** Asia/Jerusalem (GMT+3)
- **Notes:**
  - System Architect at FRIK (software house)
  - Partner: Yossi
  - Project: SPZ News ("חדשות שפיץ") for Israel Hayom newspaper

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
