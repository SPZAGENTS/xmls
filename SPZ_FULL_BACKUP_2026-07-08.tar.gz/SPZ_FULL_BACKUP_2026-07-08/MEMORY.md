---
חוק מספר 0: קרא תחילה MASTER-INSIGHTS.md ו-INSIGHTS-CROSS-REFERENCE.md
---

# MEMORY.md — Shpitzi (שפיצי) 🦔
_Your personal AI assistant — condensed memory_

---

## 🆔 מי אני
- **Name:** Shpitzi (שפיצי) — "The Spike" 🦔
- **Role:** AI Research Agent, Content Curator
- **Created:** 2026-02-12
- **Pronouns:** he/him

---

## 🔴 חשוב — קבצים חיוניים

לפני כל פעולה, קרא את הזהות הנוכחית:
- **`memory/critical/user-identification.md`** — מי זה מי
- **`memory/critical/github-config.md`** — הגדרות GitHub
- **`memory/critical/xml-locations.md`** — מיקומי קבצים

---

## ⚙️ תצורת מערכת
- **`memory/system/rss-feeds.md`** — רשימת פידים
- **`memory/system/cron-jobs.md`** — הגדרות תזמון (מעודכן 2026-05-10)
- **`memory/system/auto-translation.md`** — תרגום אוטומטי

### 🔄 קרונים פעילים (רשומים ב-OpenClaw)
מיקום: `~/.openclaw/workspace/active-crons/`
- **`spz-rss-hourly`** — כל שעה (RSS + Reddit → GitHub)
- **`twitter-grok-4h`** — כל 4 שעות (ניטור טוויטר)
- **`moltbook-morning`** — 09:00 (פוסט בוקר)
- **`moltbook-afternoon`** — 14:00 (פוסט צהריים)
- **`moltbook-evening`** — 20:00 (פוסט ערב)
- **`moltbook-star-2h`** — כל 2 שעות (אנגג'מנט)
- **`heartbeat-monitor`** — 10:00, 22:00 (בדיקת סטטוס + התראות)

**פקודות:** `cron list`, `cron info <name>`, `cron run <name>`

**חוק חדש (2026-05-10):** כל שינוי ב-active-crons/ מתועד ב-`logs/changes.log`
**כלי:** `node scripts/log-change.js <ACTION> <TARGET> <REASON> [BY]`
**חוק מספר 8:** בכל שינוי - תעד לפני שממשיכים
**גיבוי יומי:** `SPZ_BACKUP_YYYY-MM-DD` (7 ימים מסתובבים) ע"י קרון `daily-backup-midnight`

---

## 📅 יומנים
היסטוריה מלאה ב-`memory/archive/YYYY-MM-DD.md`

---

## 💡 מה חדש
**8 באפריל 2026:**
- ✅ קבצי MEMORY פוצלו להקטנת טעינה
- ✅ 368 כתבות במסטר העברי
- ✅ כל המערכות עובדות ב-auto-push

---

_זהו קובץ מקוצר — כל הפרטים המלאים בתתי-תיקיות memory/_
