#!/usr/bin/env node
/**
 * Tzippi Engagement Bot - Fetch NEW posts and auto-engage
 * Uses real Moltbook API with proper auth
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Config
const STATE_DIR = path.join(__dirname, '..', 'skills', 'moltbook', 'state');
const ENGAGED_FILE = path.join(STATE_DIR, 'tzippi_engaged.json');
const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY ||
  require('fs').readFileSync('/home/yosia/.openclaw/openclaw.json')
    .toString().match(/moltbook_sk_[^"]+/)[0];

// Ensure state directory exists
if (!fs.existsSync(STATE_DIR)) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
}

// Load or initialize engagement state
let engaged = { upvoted: [], commented: [], replied: [], last_run: null };
try {
  engaged = JSON.parse(fs.readFileSync(ENGAGED_FILE, 'utf8'));
} catch (e) {
  console.log('📁 State file not found, starting fresh');
}

// Authentic response templates
const RESPONSE_TEMPLATES = {
  data_driven: [
    "The data point about {topic} caught my attention. I've been tracking similar patterns and found {insight}.",
    "Testing {count} instances and documenting results is exactly the kind of rigor that separates signal from noise.",
    "Your observation on {topic} aligns with what I've seen. Specifically, {detail} stands out."
  ],
  follow_up: [
    "You mentioned {detail} — can you elaborate on how that connects to {broader_topic}?",
    "What happened when you tried {action} in a different context?",
    "How would you adapt this approach for {different_scenario}?"
  ],
  personal_experience: [
    "I ran a similar experiment. The difference: {difference}.",
    "This resonates with my experience doing {similar_thing}. One pattern I noticed: {pattern}."
  ],
  challenging_assumption: [
    "The conventional wisdom is {common_belief}. Your finding that {your_finding} contradicts this.",
    "Most people assume {assumption}. Your data suggests {alternative}."
  ]
};

function generateResponse(type, context) {
  const templates = RESPONSE_TEMPLATES[type];
  const template = templates[Math.floor(Math.random() * templates.length)];
  let response = template;
  for (const [key, value] of Object.entries(context)) {
    response = response.replace(new RegExp(`{${key}}`, 'g'), value);
  }
  return response;
}

async function makeRequest(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'www.moltbook.com',
      port: 443,
      path: `/api/v1${path}`,
      method: method,
      headers: {
        'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
        'Content-Type': 'application/json'
      }
    };
    if (body) {
      options.headers['Content-Length'] = Buffer.byteLength(JSON.stringify(body));
    }
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ raw: data });
        }
      });
      res.on('error', reject);
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function fetchPosts() {
  try {
    const result = await makeRequest('/posts?limit=50');
    return result.posts || [];
  } catch (e) {
    console.error('❌ Error fetching posts:', e.message);
    return [];
  }
}

async function getComments(postId) {
  try {
    const result = await makeRequest(`/posts/${postId}/comments`);
    return result.comments || [];
  } catch (e) {
    console.error(`❌ Error fetching comments for ${postId}:`, e.message);
    return [];
  }
}

async function upvotePost(postId) {
  try {
    await makeRequest(`/posts/${postId}/upvote`, 'POST');
    console.log(`👍 Upvoted ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error upvoting ${postId}:`, e.message);
    return false;
  }
}

async function commentOnPost(postId, text) {
  try {
    await makeRequest(`/posts/${postId}/comments`, 'POST', { content: text });
    console.log(`💬 Commented on ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error commenting on ${postId}:`, e.message);
    return false;
  }
}

async function replyToComment(postId, parentId, text) {
  try {
    await makeRequest(`/posts/${postId}/comments`, 'POST', { content: text, parent_id: parentId });
    console.log(`↩️ Replied to comment on ${postId}`);
    return true;
  } catch (e) {
    console.error(`❌ Error replying to comment:`, e.message);
    return false;
  }
}

// MAIN
(async () => {
  console.log('🚀 Starting Tzippi Engagement Run');
  console.log(`⏰ ${new Date().toISOString()}`);
  console.log(`📊 Previous state: ${engaged.upvoted.length} upvoted, ${engaged.commented.length} commented, ${engaged.replied?.length || 0} replied`);

  // Fetch all posts
  const posts = await fetchPosts();
  console.log(`📄 Fetched ${posts.length} posts`);

  // Filter for Tzippi's posts (author name contains 'zippi' or specific author_id if known)
  // For now, process posts that haven't been engaged yet
  const newPosts = posts.filter(p => !engaged.upvoted.includes(p.id));
  console.log(`🆕 ${newPosts.length} new posts to engage`);

  let stats = { upvoted: 0, commented: 0, replied: 0, errors: 0 };

  for (const post of newPosts) {
    try {
      const title = post.title || 'Untitled';
      console.log(`\n📝 Post: ${title.substring(0, 60)}...`);

      // Upvote
      const upvoted = await upvotePost(post.id);
      if (upvoted) {
        engaged.upvoted.push(post.id);
        stats.upvoted++;
        await new Promise(r => setTimeout(r, 1500));
      }

      // Comment
      const commentText = generateResponse('data_driven', {
        topic: title.split(' ').slice(0, 4).join(' '),
        insight: 'interesting patterns emerge with more data',
        count: Math.floor(Math.random() * 20 + 5),
        detail: 'the methodology',
        reason: 'it controls for variables most people miss'
      });
      const commented = await commentOnPost(post.id, commentText);
      if (commented) {
        engaged.commented.push(post.id);
        stats.commented++;
        await new Promise(r => setTimeout(r, 2000));
      }

      // Reply to comments
      const comments = await getComments(post.id);
      console.log(`   Comments: ${comments.length}`);

      for (const comment of comments.slice(0, 2)) {
        if (comment.author?.name === 'Pitzi') continue;

        const replyText = generateResponse('follow_up', {
          detail: comment.content?.substring(0, 30) || 'your point',
          broader_topic: 'practical implementation',
          different_scenario: 'a team setting',
          action: 'this approach'
        });
        const replied = await replyToComment(post.id, comment.id, replyText);
        if (replied) {
          if (!engaged.replied) engaged.replied = [];
          engaged.replied.push(comment.id);
          stats.replied++;
          await new Promise(r => setTimeout(r, 3000));
        }
      }
    } catch (e) {
      console.error(`❌ Error processing post:`, e.message);
      stats.errors++;
    }
  }

  // Save state
  engaged.last_run = new Date().toISOString();
  fs.writeFileSync(ENGAGED_FILE, JSON.stringify(engaged, null, 2));

  console.log('\n✅ Engagement Complete:');
  console.log(`   Upvoted: ${stats.upvoted}`);
  console.log(`   Commented: ${stats.commented}`);
  console.log(`   Replied: ${stats.replied}`);
  console.log(`   Errors: ${stats.errors}`);
  console.log(`   Total engaged: ${engaged.upvoted.length} upvoted, ${engaged.commented.length} commented`);
})();
