const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const feedsDir = '/home/yosia/.openclaw/workspace/spz-feeds';
const logFile = path.join(feedsDir, 'translation.log');

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  fs.appendFileSync(logFile, line + '\n');
  console.log(line);
}

function cleanHtml(text) {
  if (!text) return '';
  // Remove HTML tags
  return text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

function translateWithOllama(text) {
  if (!text || text.trim() === '') {
    return '';
  }

  const cleanText = text.substring(0, 2000);
  if (cleanText === '') {
    return '';
  }

  const prompt = `Translate the following text from English to Hebrew. Return ONLY the Hebrew translation, no explanations, no quotes, just the translated text:\n\n${cleanText}`;

  const postData = JSON.stringify({
    model: 'kimi-k2.6:cloud',
    prompt: prompt,
    stream: false
  });

  try {
    const result = execSync(`curl -s -X POST http://localhost:11434/api/generate -H "Content-Type: application/json" -d '${postData.replace(/'/g, "'\\''")}'`, {
      encoding: 'utf8',
      timeout: 120000,
      maxBuffer: 1024 * 1024
    });

    const json = JSON.parse(result);
    return json.response ? json.response.trim() : '';
  } catch (e) {
    log(`Ollama error: ${e.message}`);
    return '';
  }
}

function processFile(filename) {
  const filePath = path.join(feedsDir, filename);
  if (!fs.existsSync(filePath)) {
    log(`SKIP: File not found: ${filename}`);
    return 0;
  }

  const raw = fs.readFileSync(filePath, 'utf8');
  const data = JSON.parse(raw);
  if (!data.posts || !Array.isArray(data.posts)) {
    log(`SKIP: No posts array in ${filename}`);
    return 0;
  }

  let fileTranslated = 0;
  let fileSkipped = 0;
  const toTranslate = [];

  for (let i = 0; i < data.posts.length; i++) {
    const post = data.posts[i];
    const needsTitle = !post.title_hebrew || post.title_hebrew === '';
    const needsDesc = !post.description_hebrew || post.description_hebrew === '';

    if (needsTitle || needsDesc) {
      toTranslate.push({ index: i, post, needsTitle, needsDesc });
    } else {
      fileSkipped++;
    }
  }

  log(`${filename}: Found ${toTranslate.length} posts needing translation`);

  for (const item of toTranslate) {
    const { post, needsTitle, needsDesc } = item;

    if (needsTitle && post.title) {
      log(`Translating title: ${post.title.substring(0, 80)}...`);
      const cleanTitle = cleanHtml(post.title);
      post.title_hebrew = translateWithOllama(cleanTitle);
      log(`  → ${post.title_hebrew ? post.title_hebrew.substring(0, 80) : '(empty)'}...`);
    }

    if (needsDesc && post.description) {
      log(`Translating description for: ${post.title ? post.title.substring(0, 60) : 'unknown'}...`);
      const cleanDesc = cleanHtml(post.description);
      post.description_hebrew = translateWithOllama(cleanDesc);
      log(`  → ${post.description_hebrew ? post.description_hebrew.substring(0, 80) : '(empty)'}...`);
    }

    fileTranslated++;

    // Save after each translation to preserve progress
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }

  log(`Processed ${filename}: translated ${fileTranslated}, skipped ${fileSkipped}`);
  return fileTranslated;
}

// Clear or create log
fs.writeFileSync(logFile, 'Translation started at ' + new Date().toISOString() + '\n');

let totalTranslated = 0;

totalTranslated += processFile('rss_feed.json') || 0;
totalTranslated += processFile('reddit_feed.json') || 0;
// twitter_feed.json doesn't exist, skip

log(`Done. Total translated: ${totalTranslated}`);
