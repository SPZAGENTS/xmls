#!/usr/bin/env node
/**
 * SPZ Twitter Monitor v4 - xurl Native API
 * Uses xurl CLI for direct X API access (no Grok credits needed)
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CONFIG = {
    output_dir: '/home/yosia/.openclaw/workspace/spz-feeds',
    xml_filename: 'twitter-xurl-feed.xml',
    json_filename: 'twitter-xurl-feed.json',
    repo_dir: '/home/yosia/.openclaw/workspace/spz-repo',
    max_results: 20,
    time_window_hours: 4
};

// Search queries for each category
const SEARCH_QUERIES = [
    {
        name: 'אנטישמיות',
        query: 'antisemitism OR "synagogue attack" OR "jewish attacked" OR "campus antisemitism" -is:retweet',
        priority: 1
    },
    {
        name: 'איום איסלאמי באירופה',
        query: '"sharia patrol" OR "muslim patrol" OR "islamic threat" OR "no go zone" -is:retweet',
        priority: 2
    },
    {
        name: 'תומכי טרור',
        query: 'hamas supporter OR "terror supporter" OR "free gaza" antisemitism -is:retweet',
        priority: 2
    },
    {
        name: 'פרו-ישראל',
        query: '"stand with israel" OR "support israel" OR "zionism" OR "jewish state" -is:retweet',
        priority: 3
    },
    {
        name: 'פוליטיקאים',
        query: 'Kemi Badenoch OR Poilievre OR Meloni antisemitism -is:retweet',
        priority: 3
    }
];

// Run xurl search
function xurlSearch(query, maxResults = 10) {
    try {
        // Escape single quotes in query for shell safety
        const safeQuery = query.replace(/'/g, "'\"'\"'");
        const cmd = `xurl search '${safeQuery}' -n ${maxResults}`;
        console.log(`  🔍 Searching...`);
        const result = execSync(cmd, { 
            encoding: 'utf-8', 
            timeout: 30000,
            shell: '/bin/bash'
        });
        return JSON.parse(result);
    } catch (e) {
        console.error(`  ❌ Search failed: ${e.message}`);
        if (e.stderr) {
            const stderrStr = e.stderr.toString();
            if (stderrStr.includes('401') || stderrStr.includes('Unauthorized')) {
                console.error(`  🔑 Authentication error - need to run: xurl auth oauth2`);
            }
        }
        return null;
    }
}

// Convert X API tweet to our format
function normalizeTweet(tweet, category) {
    return {
        id: tweet.id,
        username: tweet.author_id ? `@user_${tweet.author_id}` : '@unknown',
        display_name: tweet.author_id || 'Unknown',
        text: tweet.text || '',
        hebrew_translation: '', // Would need translation service
        date: tweet.created_at || new Date().toISOString(),
        likes: tweet.public_metrics?.like_count || 0,
        retweets: tweet.public_metrics?.retweet_count || 0,
        replies: tweet.public_metrics?.reply_count || 0,
        url: `https://x.com/i/web/status/${tweet.id}`,
        has_media: !!(tweet.attachments?.media_keys?.length),
        media_type: 'text', // Would need media lookup
        media_urls: [],
        relevance_score: 50 + (category.priority * 10),
        category: category.name,
        category_name: category.name,
        search_method: 'xurl'
    };
}

// Generate RSS XML
function generateXML(posts) {
    const now = new Date().toISOString();
    
    let xml = `<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
  <channel>
    <title>SPZ Twitter Feed - xurl Monitor</title>
    <description>אנטישמיות, איום איסלאמי, פרו-ישראל - מוניטור Twitter</description>
    <link>https://github.com/SPZAGENTS/xmls</link>
    <lastBuildDate>${now}</lastBuildDate>
    <language>he</language>
`;

    for (const post of posts) {
        const title = (post.text || 'ללא כותרת').substring(0, 100).replace(/\n/g, ' ');
        xml += `    <item>
      <title>[${post.relevance_score}] ${escapeXml(title)}${title.length > 100 ? '...' : ''}</title>
      <link>${post.url}</link>
      <description>${escapeXml(post.text)}</description>
      <pubDate>${post.date}</pubDate>
      <source>twitter-${escapeXml(post.username)}</source>
      <category>${escapeXml(post.category)}</category>
    </item>
`;
    }
    
    xml += `  </channel>
</rss>`;
    return xml;
}

function escapeXml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

// Save files
function saveFiles(posts, xml) {
    const jsonPath = path.join(CONFIG.output_dir, CONFIG.json_filename);
    const jsonData = {
        metadata: {
            agent: 'twitter-xurl',
            version: '4.0',
            timestamp: new Date().toISOString(),
            total_posts: posts.length
        },
        posts: posts
    };
    
    fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2), 'utf-8');
    console.log(`✅ JSON: ${jsonPath}`);
    
    const xmlPath = path.join(CONFIG.output_dir, CONFIG.xml_filename);
    fs.writeFileSync(xmlPath, xml, 'utf-8');
    console.log(`✅ XML: ${xmlPath}`);
    
    return { jsonPath, xmlPath };
}

// Push to git
function pushToGit(files, postCount) {
    try {
        const repoJson = path.join(CONFIG.repo_dir, CONFIG.json_filename);
        const repoXml = path.join(CONFIG.repo_dir, CONFIG.xml_filename);
        
        fs.copyFileSync(files.jsonPath, repoJson);
        fs.copyFileSync(files.xmlPath, repoXml);
        
        execSync(`git -C ${CONFIG.repo_dir} pull origin main`, { captureOutput: true, timeout: 60000 });
        execSync(`git -C ${CONFIG.repo_dir} add .`, { captureOutput: true, timeout: 30000 });
        
        const ts = new Date().toISOString().substring(0, 16).replace('T', ' ');
        execSync(`git -C ${CONFIG.repo_dir} commit -m "Twitter xurl ${ts} (${postCount} posts)"`, { captureOutput: true, timeout: 30000 });
        execSync(`git -C ${CONFIG.repo_dir} push origin main`, { captureOutput: true, timeout: 60000 });
        
        console.log('✅ Pushed to GitHub');
        return true;
    } catch (e) {
        console.log('⚠️ Git issue:', e.message);
        return false;
    }
}

// Main
async function main() {
    console.log('🚀 SPZ Twitter Monitor v4 - xurl Native API');
    console.log('============================================');
    console.log(`⏰ ${new Date().toISOString()}`);
    
    const allPosts = [];
    
    for (const category of SEARCH_QUERIES) {
        console.log(`\n🔍 ${category.name}...`);
        const result = xurlSearch(category.query, CONFIG.max_results);
        
        if (result && result.data) {
            const posts = result.data.map(t => normalizeTweet(t, category));
            allPosts.push(...posts);
            console.log(`   ✅ ${posts.length} posts`);
        } else {
            console.log(`   ⚠️ No results`);
        }
        
        // Rate limit protection
        if (SEARCH_QUERIES.indexOf(category) < SEARCH_QUERIES.length - 1) {
            console.log('   ⏳ Waiting 5s...');
            await new Promise(r => setTimeout(r, 5000));
        }
    }
    
    console.log(`\n📊 Total posts: ${allPosts.length}`);
    
    if (allPosts.length === 0) {
        console.log('⚠️ No posts found - xurl may not be authenticated');
        console.log('💡 Run: xurl auth oauth2 (outside agent session)');
        return;
    }
    
    // Generate and save
    console.log('\n📝 Generating XML...');
    const xml = generateXML(allPosts);
    const files = saveFiles(allPosts, xml);
    
    // Push
    console.log('\n📤 Pushing to GitHub...');
    pushToGit(files, allPosts.length);
    
    console.log('\n✅ Done!');
}

main().catch(console.error);
