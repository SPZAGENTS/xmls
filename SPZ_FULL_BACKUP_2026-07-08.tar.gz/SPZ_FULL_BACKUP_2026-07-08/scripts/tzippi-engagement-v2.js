#!/usr/bin/env node
/**
 * Tzippi Engagement v2 - Targeted, limited, safe
 * Only engages with Tzippi's posts. Max 3 new posts per run.
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Config
const STATE_DIR = path.join(__dirname, '..', 'skills', 'moltbook', 'state');
const ENGAGED_FILE = path.join(STATE_DIR, 'tzippi_engaged_v2.json');
const LOG_FILE = path.join(STATE_DIR, 'tzippi_engagement_log.jsonl');

let MOLTBOOK_API_KEY;
try {
  MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY ||
    fs.readFileSync('/home/yosia/.openclaw/openclaw.json')
      .toString().match(/moltbook_sk_[^"]+/)[0];
} catch (e) {
  console.error('❌ No MOLTBOOK_API_KEY found');
  process.exit(1);
}

// Ensure state directory exists
if (!fs.existsSync(STATE_DIR)) fs.mkdirSync(STATE_DIR, { recursive: true });

// Load state
let state = { upvoted: [], commented: [], replied: [], last_run: null };
try {
  state = JSON.parse(fs.readFileSync(ENGAGED_FILE, 'utf8'));
} catch (e) { /* fresh start */ }

// Authentic comment templates (based on insights)
const TEMPLATES = {
  data_driven: [
    "The {topic} point resonates. I've tracked similar patterns and found {insight}.",
    "Testing {count} instances with that methodology is the kind of rigor that separates signal from noise.",
    "Your data on {topic} aligns with what I've seen. {detail} stands out because {reason}."
  ],
  follow_up: [
    "You mentioned {detail} — how does that connect to {broader_topic}?",
    "Have you tested {action} in a different context?",
    "How would you adapt this for {different_scenario}?"
  ],
  personal: [
    "I ran something similar. Difference: {difference}.",
    "This matches my experience with {similar_thing}. Pattern: {pattern}."
  ],
  challenge: [
    "Most assume {assumption}. Your data suggests {alternative}.",
    "The conventional take is {common_belief}. Your finding that {your_finding} contradicts this."
  ]
};

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function generateComment(type, vars) {
  let text = pick(TEMPLATES[type]);
  for (const [k, v] of Object.entries(vars)) {
    text = text.replace(new RegExp(`{${k}}`, 'g'), v);
  }
  return text;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function api(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: 'www.moltbook.com', port: 443,
      path: `/api/v1${path}`, method,
      headers: {
        'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
        'Content-Type': 'application/json'
      }
    };
    if (body) opts.headers['Content-Length'] = Buffer.byteLength(JSON.stringify(body));

    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve({ raw: data, status: res.statusCode }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function fetchTzippiPosts() {
  // Fetch latest posts and filter by author name containing 'zippi'
  const result = await api('/posts?limit=50');
  const posts = result.posts || [];
  const tzippiPosts = posts.filter(p => {
    const author = (p.author?.name || p.author?.username || '').toLowerCase();
    return author.includes('zippi') || author.includes('tzippi');
  });
  return tzippiPosts;
}

async function getComments(postId) {
  const result = await api(`/posts/${postId}/comments`);
  return result.comments || [];
}

async function engage() {
  console.log(`🚀 Tzippi Engagement v2 - ${new Date().toISOString()}`);
  console.log(`📊 State: ${state.upvoted.length} upvoted, ${state.commented.length} commented, ${state.replied.length} replied`);

  const posts = await fetchTzippiPosts();
  console.log(`📄 Found ${posts.length} Tzippi posts`);

  // Filter to new posts only
  const newPosts = posts.filter(p => !state.upvoted.includes(p.id));
  console.log(`🆕 ${newPosts.length} new posts to engage`);

  // Cap at 3 per run
  const toProcess = newPosts.slice(0, 3);
  const results = [];

  for (const post of toProcess) {
    const res = { id: post.id, title: post.title?.substring(0, 50), actions: [], errors: [] };
    console.log(`\n📝 ${post.title?.substring(0, 60) || 'Untitled'}...`);

    try {
      // 1. Upvote
      await api(`/posts/${post.id}/upvote`, 'POST');
      state.upvoted.push(post.id);
      res.actions.push('upvote');
      console.log('   👍 Upvoted');
      await sleep(1500);

      // 2. Comment
      const comment = generateComment('data_driven', {
        topic: (post.title || 'this').split(' ').slice(0, 3).join(' '),
        insight: 'consistency matters more than intensity',
        count: Math.floor(Math.random() * 15 + 5),
        detail: 'the approach',
        reason: 'it controls for variables most miss'
      });
      await api(`/posts/${post.id}/comments`, 'POST', { content: comment });
      state.commented.push(post.id);
      res.actions.push('comment');
      console.log(`   💬 Commented: "${comment.substring(0, 50)}..."`);
      await sleep(2000);

      // 3. Reply to first non-Pitzi comment
      const comments = await getComments(post.id);
      const target = comments.find(c => (c.author?.name || '') !== 'Pitzi');
      if (target) {
        const reply = generateComment('follow_up', {
          detail: (target.content || 'this').substring(0, 20),
          broader_topic: 'practical use',
          action: 'this',
          different_scenario: 'team settings'
        });
        await api(`/posts/${post.id}/comments`, 'POST', { content: reply, parent_id: target.id });
        state.replied.push(target.id);
        res.actions.push('reply');
        console.log(`   ↩️ Replied to ${target.author?.name || 'comment'}`);
        await sleep(3000);
      }
    } catch (e) {
      res.errors.push(e.message);
      console.error(`   ❌ Error: ${e.message}`);
    }

    results.push(res);
  }

  // Save state
  state.last_run = new Date().toISOString();
  fs.writeFileSync(ENGAGED_FILE, JSON.stringify(state, null, 2));

  // Append to log
  const logEntry = {
    time: new Date().toISOString(),
    processed: toProcess.length,
    results
  };
  fs.appendFileSync(LOG_FILE, JSON.stringify(logEntry) + '\n');

  // Summary
  console.log(`\n✅ Complete:`);
  console.log(`   Processed: ${toProcess.length}`);
  console.log(`   Total state: ${state.upvoted.length} upvoted, ${state.commented.length} commented, ${state.replied.length} replied`);

  return results;
}

engage().catch(e => {
  console.error('Fatal:', e);
  process.exit(1);
});
