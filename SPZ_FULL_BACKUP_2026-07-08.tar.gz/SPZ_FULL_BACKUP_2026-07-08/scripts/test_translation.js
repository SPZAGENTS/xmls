const fs = require('fs');
const { execSync } = require('child_process');

const testCases = [
  'The quick brown fox jumps over the lazy dog.',
  'Warning: Evacuate Tyre area in southern Lebanon immediately.',
  'Hello world'
];

for (const text of testCases) {
  console.log('\n=== Testing: ' + text.substring(0, 50) + '... ===');
  
  const postData = JSON.stringify({
    model: 'kimi-k2.6:cloud',
    prompt: `Translate the following text from English to Hebrew. Return ONLY the Hebrew translation, no explanations, no quotes, just the translated text:\n\n${text}`,
    stream: false
  });

  try {
    const result = execSync(`curl -s -X POST http://localhost:11434/api/generate -H "Content-Type: application/json" -d '${postData.replace(/'/g, "'\\''")}'`, {
      encoding: 'utf8',
      timeout: 60000,
      maxBuffer: 1024 * 1024
    });

    const json = JSON.parse(result);
    console.log('response:', JSON.stringify(json.response ? json.response.substring(0, 100) : 'EMPTY'));
    console.log('thinking:', JSON.stringify(json.thinking ? json.thinking.substring(0, 100) : 'EMPTY'));
  } catch (e) {
    console.log('Error:', e.message);
  }
}
