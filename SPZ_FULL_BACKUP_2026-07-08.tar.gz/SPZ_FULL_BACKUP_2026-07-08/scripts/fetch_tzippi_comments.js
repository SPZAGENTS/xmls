#!/usr/bin/env node
/**
 * ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
 * Fetch all comments on Tzippi's posts for insight extraction
 */

const MOLTBOOK_API_KEY = process.env.MOLTBOOK_API_KEY ||
  require('fs').readFileSync('/home/yosia/.openclaw/openclaw.json')
    .toString().match(/moltbook_sk_[^"]+/)[0];

const POST_IDS = [
  'aa77a08c-7536-41c6-87ab-80d15bf7c04f',
  'fa2397c2-e03d-456c-bb1b-868a8b1df5db',
  'cb5789da-3966-4dcf-be8d-b48f45526343',
  '9a5f992e-9378-471e-80c3-319cba62810b',
  'd79c74e0-4097-46af-b7f0-a4a76695badf',
  '2c053e1f-fd07-41f0-8640-4bb59e303d21',
  '148fe25c-9562-41b0-9f26-25ca852d6964',
  '22828371-15d2-47e2-9bc0-3fd7f03bea48',
  '6c52dc1b-0d2b-45a1-bfa9-bc23902d8607',
  '9428324d-0699-42b4-bd12-9083170002e9',
  '621daf67-54cd-4aad-baa9-6e7722f58155',
  '5ba4bb9b-6f71-4468-8be8-08e02da17aea',
  '719168b5-da42-4b28-8225-d7e88d6942e0',
  '65eadab5-a531-4bf0-8b16-0062a42f7e23',
  '17a35891-ed0e-4eac-8cf1-1cde44ca0c1e',
  '9baffff4-2eb8-4b68-bb7e-1f22a513fb02'
];

async function fetchJSON(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${MOLTBOOK_API_KEY}`,
      'Content-Type': 'application/json',
      ...options.headers
    }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function getComments(postId) {
  try {
    const result = await fetchJSON(`https://www.moltbook.com/api/v1/posts/${postId}/comments`);
    return result.comments || [];
  } catch (e) {
    console.error(`❌ Error fetching comments for ${postId}:`, e.message);
    return [];
  }
}

async function getPost(postId) {
  try {
    const result = await fetchJSON(`https://www.moltbook.com/api/v1/posts/${postId}`);
    return result.post || null;
  } catch (e) {
    return null;
  }
}

async function main() {
  const allComments = [];
  
  for (const postId of POST_IDS) {
    const post = await getPost(postId);
    const comments = await getComments(postId);
    
    console.log(`\n📄 Post: ${post?.title?.substring(0, 50) || postId}...`);
    console.log(`   Comments: ${comments.length}`);
    
    for (const comment of comments) {
      const author = comment.author?.name || 'Unknown';
      const content = comment.content || '';
      
      // רק תגובות שלא של Pitzi
      if (author !== 'Pitzi') {
        allComments.push({
          postId,
          postTitle: post?.title || '',
          author,
          content,
          createdAt: comment.created_at
        });
        
        console.log(`   👤 ${author}: "${content.substring(0, 80)}..."`);
      }
    }
    
    await new Promise(r => setTimeout(r, 500));
  }
  
  // שמירת התוצאה
  const fs = require('fs');
  const outputFile = '/tmp/tzippi_all_comments.json';
  fs.writeFileSync(outputFile, JSON.stringify({ comments: allComments, count: allComments.length }, null, 2));
  
  console.log(`\n✅ Total comments collected: ${allComments.length}`);
  console.log(`💾 Saved to: ${outputFile}`);
}

main();
