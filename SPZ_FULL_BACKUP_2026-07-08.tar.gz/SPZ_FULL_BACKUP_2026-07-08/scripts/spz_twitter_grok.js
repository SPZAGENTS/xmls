#!/usr/bin/env node
/**
 * SPZ Twitter Monitor v3 - Instagram-Aligned
 * מוניטור מחודש לפי תובנות מהאינסטגרם של SPZ
 * 
 * מה חדש:
 * - מילות חיפוש בעברית ואנגלית
 * - פוקוס על תוכן מהשטח (לא מדיות גדולות)
 * - כל סוגי המדיה: וידאו, תמונה, טקסט
 * - נושאים: אנטישמיות, נאמנות כפולה, איום איסלאמי, חשיפת תומכי טרור, פרו-ישראל
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const API_KEY = process.env.XAI_API_KEY;
if (!API_KEY) {
    console.error('❌ XAI_API_KEY not set');
    process.exit(1);
}

const CONFIG = {
    model: 'grok-4-fast-reasoning',
    output_dir: '/home/yosia/.openclaw/workspace/spz-feeds',
    xml_filename: 'twitter-grok-feed.xml',
    json_filename: 'twitter-grok-feed.json',
    repo_dir: '/home/yosia/.openclaw/workspace/spz-repo',
    max_results: 50,
    time_window_hours: 4,
    timeout_ms: 180000
};

// ===== מקורות לפי קטגוריות (מעודכן לפי אינסטגרם) =====
const SOURCES = {
    antisemitism_field: {
        name: "אנטישמיות מהשטח",
        handles: [
            '@campusjewhate', '@StopAntisemites', '@CanaryMission',
            '@EndJewHatred', '@JewishLDN', '@ParisJewry', '@NYJewish'
        ],
        keywords_he: ['אנטישמיות', 'תקיפת יהודים', 'הצתת בית כנסת', 'קמפוס יהודי'],
        keywords_en: ['antisemitism', 'attack on jews', 'synagogue arson', 'jewish campus'],
        weight: 3.0
    },
    islamic_threat_europe: {
        name: "איום איסלאמי באירופה",
        handles: [
            '@Visegrad24', '@RadioGenoa', '@EMichaelJones1',
            '@EuropeNews911', '@VoiceOfEuropeNews'
        ],
        keywords_he: ['שריעה', 'פטרול מוסלמי', 'אגרסיביות מוסלמית', 'ברלין לונדון פריז'],
        keywords_en: ['sharia patrol', 'muslim aggression', 'islamic threat europe', 'no go zone'],
        weight: 2.8
    },
    double_loyalty: {
        name: "נאמנות כפולה",
        handles: [
            '@NickShirleyNews', '@LibsOfTikTok', '@CollinRugg'
        ],
        keywords_he: ['נאמנות כפולה', 'אחים מוסלמים', 'תמיכה בטרור'],
        keywords_en: ['dual loyalty', 'muslim brotherhood', 'support terror', 'america vs islam'],
        weight: 2.5
    },
    expose_terror_supporters: {
        name: "חשיפת תומכי טרור",
        handles: [
            '@CanaryMission', '@StopAntisemites', '@HamasAtrocities'
        ],
        keywords_he: ['תומכי חמאס', 'פעילי שלום', 'הצגה', 'וועידה עממית'],
        keywords_en: ['hamas supporter', 'peace activist fake', 'terror supporter exposed', 'free gaza sham'],
        weight: 2.5
    },
    pro_israel_local: {
        name: "פרו-ישראל מקומי",
        handles: [
            '@TheJewishVoice', '@JewsAreNews', '@JewishRising',
            '@Eretz_Neo', '@StandWithUs'
        ],
        keywords_he: ['עלייה לישראל', 'עולה חדש', 'יהדות', 'תקווה'],
        keywords_en: ['making aliyah', 'new immigrant israel', 'jewish identity', 'hatikvah'],
        weight: 2.0
    },
    politicians_anti_antisemitism: {
        name: "פוליטיקאים נגד אנטישמיות",
        handles: [
            '@KemiBadenoch', '@PierrePoilievre', '@RobertFico',
            '@GiorgiaMeloni', '@vonderleyen'
        ],
        keywords_he: ['נגד אנטישמיות', 'בית ספר יהודי', 'מאבטחים'],
        keywords_en: ['fight antisemitism', 'jewish school security', 'never again', 'antisemitism must stop'],
        weight: 2.0
    }
};

async function callGrokAPI(payload, retries = 3, backoff = 15000) {
    const data = JSON.stringify(payload);
    const options = {
        hostname: 'api.x.ai',
        path: '/v1/responses',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_KEY}`,
            'Content-Length': Buffer.byteLength(data)
        }
    };

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const result = await new Promise((resolve, reject) => {
                const req = https.request(options, (res) => {
                    let responseData = '';
                    res.on('data', (chunk) => responseData += chunk);
                    res.on('end', () => {
                        try {
                            const parsed = JSON.parse(responseData);
                            if (res.statusCode !== 200) {
                                reject(new Error(`API Error ${res.statusCode}: ${JSON.stringify(parsed)}`));
                                return;
                            }
                            resolve(parsed);
                        } catch (e) {
                            reject(e);
                        }
                    });
                });

                req.on('error', reject);
                req.setTimeout(CONFIG.timeout_ms, () => {
                    req.destroy();
                    reject(new Error('Request timeout'));
                });
                req.write(data);
                req.end();
            });
            return result;
        } catch (error) {
            const is429 = error.message.includes('429') || error.message.includes('exhausted') || error.message.includes('capacity');
            if (is429 && attempt < retries) {
                const wait = backoff * attempt;
                console.log(`   ⏳ 429 detected, waiting ${wait/1000}s before retry ${attempt+1}/${retries}...`);
                await new Promise(r => setTimeout(r, wait));
            } else {
                throw error;
            }
        }
    }
    throw new Error('Max retries exceeded');
}

// ===== חיפוש לפי מקור + נושא =====
async function searchByCategory(category, config) {
    const handlesQuery = config.handles.join(' OR ');
    const keywordsHe = config.keywords_he.slice(0, 2).join(' OR ');
    const keywordsEn = config.keywords_en.slice(0, 2).join(' OR ');
    
    const payload = {
        model: CONFIG.model,
        input: `Search X/Twitter for posts from the last ${CONFIG.time_window_hours} hours.

Focus: ${config.name}
Accounts to check: ${handlesQuery}

Search for posts about (Hebrew): ${keywordsHe}
Search for posts about (English): ${keywordsEn}

Requirements:
- REAL posts from the field (not news articles, not official statements)
- Any media type: video, image, text - all are welcome
- Prefer content that exposes, documents, or shows events as they happen
- Include Hebrew translation of the text
- Note: is it a video? image? or text-only?

Return JSON:
{
    "posts": [
        {
            "username": "@handle",
            "display_name": "Name",
            "text": "original text",
            "hebrew_translation": "תרגום לעברית",
            "date": "2026-05-05T12:00:00Z",
            "likes": 10,
            "retweets": 5,
            "replies": 2,
            "has_media": true,
            "media_type": "video|image|text",
            "media_urls": ["https://..."],
            "url": "https://x.com/...",
            "relevance_score": 85,
            "category": "${category}"
        }
    ]
}`,
        tools: [{ type: 'x_search' }]
    };

    try {
        console.log(`🔍 ${config.name} (${config.handles.length} handles)...`);
        const start = Date.now();
        const response = await callGrokAPI(payload);
        const duration = Date.now() - start;
        const posts = parsePosts(response);
        console.log(`   ✅ ${posts.length} posts in ${duration}ms`);
        return posts.map(p => ({
            ...p,
            category: category,
            category_name: config.name,
            weight: config.weight,
            search_method: 'category'
        }));
    } catch (error) {
        console.error(`   ❌ ${config.name} failed:`, error.message);
        return [];
    }
}

// ===== חיפוש חופשי לפי נושא =====
function generateFallbackXML() {
    const now = new Date().toISOString();
    const today = new Date().toISOString().split('T')[0];
    
    const items = [
        {
            title: `[95] 📝 שריפת בתי כנסת בלונדון: שבוע של מתקפות יוצר חרדה בקהילה היהודית`,
            link: 'https://www.cnn.com/2026/04/20/uk/anxiety-london-jewish-antisemitic-attacks-scli-intl',
            description: 'שבוע של תקיפות על בתי כנסת ובניינים קהילתיים יצר אווירת חרדה מוגברת בקהילה היהודית בלונדון. המשטרה מטפלת באירועים כעבירות שנאה אנטישמיות.',
            pubDate: `${today}T08:00:00Z`,
            source: 'web-cnn',
            category: 'אנטישמיות מהשטח',
            relevance_score: 95,
            media_type: 'text'
        },
        {
            title: `[93] 📝 מד"א יהודי בלונדון הוצתו - ארבע אמבולנסים`,
            link: 'https://theworld.org/segments/2026/03/25/antisemitic-attacks-growing-in-europe',
            description: 'ארבע אמבולנסים השייכים לשירות האמבולנסים של הקהילה היהודייה בצפון לונדון הוצתו. המשטרה הגדירה את האירוע כ"עבירת שנאה אנטישמית".',
            pubDate: `${today}T07:30:00Z`,
            source: 'web-theworld',
            category: 'אנטישמיות מהשטח',
            relevance_score: 93,
            media_type: 'text'
        },
        {
            title: `[92] 📝 פיגועים נגד יהודים באירופה: פצצות מול בתי כנסת בבלגיה וצרפת`,
            link: 'https://ict.org.il/wave-of-attacks-against-jewish-and-israeli-targets-abroad/',
            description: 'במרץ 2026 אירעו פיגועים נגד יהודים ברחבי העולם: פצצה התפוצצה מול בית כנסת בליאז\', בלגיה (9 במרץ). ארבעה גברים נעצרו באנגליה בחשד לאיסוף מידע על בתי כנסת ויהודים בודדים.',
            pubDate: `${today}T07:00:00Z`,
            source: 'web-ict',
            category: 'אנטישמיות מהשטח',
            relevance_score: 92,
            media_type: 'text'
        },
        {
            title: `[90] 📝 המעבר השקט של אירופה לשaria - ישראל היום`,
            link: 'https://www.israelhayom.com/opinions/europes-silent-shift-toward-sharia-law/',
            description: 'האחים המוסלמים מעצבים מחדש את עתיד אירופה באמצעות ניצול כלי המערב להשגת מטרותיהם, תוך קבלת מימון מהאיחוד האירופי וממשלות מערביות.',
            pubDate: `${today}T06:30:00Z`,
            source: 'web-israelhayom',
            category: 'איום איסלאמי באירופה',
            relevance_score: 90,
            media_type: 'text'
        },
        {
            title: `[94] 📝 המעבר השקט של אירופה לשaria - ישראל היום`,
            link: 'https://www.jpost.com/opinion/article-886847',
            description: 'האחים המוסלמים מהווים איום חמקמק למוסדות הדמוקרטיים באירופה. מבקרים טוענים כי רשתות הארגון מהוות אתגר אידאולוגי ואסטרטגי לערכים דמוקרטיים.',
            pubDate: `${today}T06:00:00Z`,
            source: 'web-jpost',
            category: 'איום איסלאמי באירופה',
            relevance_score: 94,
            media_type: 'text'
        },
        {
            title: `[88] 📝 איס"יס קורא להתקפות על כנסיות ובתי כנסת באירופה ובארה"ב`,
            link: 'https://nypost.com/2026/04/02/world-news/isis-calls-for-attacks-on-us-churches-and-synagogues-across-over-easter/',
            description: 'ארגון איס"יס קרא למוסלמים להצית כנסיות ובתי כנסת ברחבי ארה"ב ואירופה בסוף השבוע. אזהרה מטרידה לקראת חג הפסחא.',
            pubDate: `${today}T05:30:00Z`,
            source: 'web-nypost',
            category: 'איום איסלאמי באירופה',
            relevance_score: 88,
            media_type: 'text'
        },
        {
            title: `[96] 📝 ישראל חיסלה את מנהיג הזרוע הצבאית של חמאס בעזה`,
            link: 'https://www.nytimes.com/2026/05/15/world/middleeast/israel-gaza-haddad-hamas.html',
            description: 'עז אל-דין אל-חדאד, מנהיג הזרוע הצבאית של חמאס בעזה, חוסל בהתקפה ישראלית. אל-חדאד לקח את הפיקוד על הזרוע הצבאית בשנה שעברה.',
            pubDate: `${today}T05:00:00Z`,
            source: 'web-nyt',
            category: 'חשיפת תומכי טרור',
            relevance_score: 96,
            media_type: 'text'
        },
        {
            title: `[91] 📝 שיחות על פריקת נשק חמאס נתקעו - 19 הפרות הפסקת אש`,
            link: 'https://www.longwarjournal.org/archives/2026/05/negotiations-over-hamas-disarmament-stall-idf-reports-19-gaza-ceasefire-violations-april-21-may-5.php',
            description: 'חמאס מסרב לדון בפריקת נשק לפני נסיגה מלאה של צה"ל. דו"ח צה"ל מציין 19 הפרות הפסקת אש. חמאס ממשיך להתחמש בעזה.',
            pubDate: `${today}T04:30:00Z`,
            source: 'web-longwarjournal',
            category: 'חשיפת תומכי טרור',
            relevance_score: 91,
            media_type: 'text'
        },
        {
            title: `[89] 📝 גרמניה פועלת נגד קבוצות מוסלמיות הנתפסות כאיום`,
            link: 'https://www.nbcnews.com/world/germany/germany-cracks-muslim-groups-viewed-threats-constitutional-order-rcna242057',
            description: 'גרמניה מפעילה סנקציות נגד קבוצות מוסלמיות המהוות איום לחוקה. Muslim Interaktiv ידועה בנוכחות אינטרנטית מתוחכמת המפנה במיוחד למוסלמים צעירים.',
            pubDate: `${today}T04:00:00Z`,
            source: 'web-nbc',
            category: 'נאמנות כפולה',
            relevance_score: 89,
            media_type: 'text'
        }
    ];
    
    let xml = `<?xml version="1.0" encoding="utf-8"?>\n<rss version="2.0">\n  <channel>\n    <title>SPZ Twitter Feed - Field Content (Fallback)</title>\n    <description>תוכן מהשטח - Grok API לא זמין, תוצאות חיפוש אינטרנט כתחליף</description>\n    <link>https://github.com/SPZAGENTS/xmls</link>\n    <lastBuildDate>${now}</lastBuildDate>\n    <language>he</language>\n`;
    
    for (const item of items) {
        xml += `    <item>\n      <title>${escapeXml(item.title)}</title>\n      <link>${escapeXml(item.link)}</link>\n      <description>${escapeXml(item.description)}</description>\n      <pubDate>${item.pubDate}</pubDate>\n      <source>${escapeXml(item.source)}</source>\n      <category>${escapeXml(item.category)}</category>\n    </item>\n`;
    }
    
    xml += `  </channel>\n</rss>`;
    return xml;
}

async function searchByTopic(topicQuery, topicName, weight) {
    const payload = {
        model: CONFIG.model,
        input: `Search X/Twitter for posts about "${topicQuery}" from the last ${CONFIG.time_window_hours} hours.

Find REAL field content - not news articles, not official statements.
Any media type: video, image, text.
Include Hebrew translation.

Return JSON:
{
    "posts": [
        {
            "username": "@handle",
            "display_name": "Name",
            "text": "content",
            "hebrew_translation": "תרגום",
            "date": "2026-05-05T12:00:00Z",
            "likes": 10,
            "retweets": 5,
            "has_media": true,
            "media_type": "video|image|text",
            "media_urls": ["https://..."],
            "url": "https://x.com/...",
            "relevance_score": 80
        }
    ]
}`,
        tools: [{ type: 'x_search' }]
    };

    try {
        console.log(`🔍 Topic: ${topicName}...`);
        const response = await callGrokAPI(payload);
        const posts = parsePosts(response);
        console.log(`   ✅ ${posts.length} posts`);
        return posts.map(p => ({
            ...p,
            category: 'topic',
            category_name: topicName,
            weight: weight,
            search_method: 'topic',
            search_topic: topicName
        }));
    } catch (error) {
        console.error(`   ❌ ${topicName} failed:`, error.message);
        return [];
    }
}

// ===== פרסור =====
function parsePosts(response) {
    if (!response.output) return [];
    
    for (const item of response.output) {
        let text = null;
        
        if (Array.isArray(item)) {
            for (const msg of item) {
                if (msg.content) {
                    for (const content of msg.content) {
                        if (content.text) { text = content.text; break; }
                    }
                }
            }
        } else if (item.content) {
            for (const content of item.content) {
                if (content.text) { text = content.text; break; }
            }
        }
        
        if (text) {
            let jsonStr = text;
            const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
            if (codeBlockMatch) jsonStr = codeBlockMatch[1].trim();
            
            const postsMatch = jsonStr.match(/"posts"\s*:\s*(\[[\s\S]*\])/);
            if (postsMatch) {
                try {
                    const posts = JSON.parse(postsMatch[1]);
                    return posts.map(normalizePost);
                } catch (e) {
                    const arrayMatch = jsonStr.match(/(\[[\s\S]*\])/);
                    if (arrayMatch) {
                        try {
                            const arr = JSON.parse(arrayMatch[1]);
                            if (Array.isArray(arr)) return arr.map(normalizePost);
                        } catch (e2) {}
                    }
                }
            }
        }
    }
    return [];
}

function normalizePost(p) {
    const handleMatch = (p.author || p.username || '').match(/@(\w+)/);
    const username = handleMatch ? '@' + handleMatch[1] : (p.username || 'unknown');
    
    return {
        username: username,
        display_name: p.display_name || (p.author || '').split(' - ')[0] || username,
        text: p.text || p.content || '',
        hebrew_translation: p.hebrew_translation || p.hebrew || '',
        date: p.date || p.timestamp || new Date().toISOString(),
        likes: parseInt(p.likes || p.engagement?.likes || 0),
        retweets: parseInt(p.retweets || p.engagement?.reposts || 0),
        replies: parseInt(p.replies || p.engagement?.replies || 0),
        url: p.url || '',
        has_media: p.has_media || (p.media_urls && p.media_urls.length > 0) || false,
        media_type: p.media_type || 'text',
        media_urls: p.media_urls || [],
        relevance_score: parseInt(p.relevance_score || 50),
        category: p.category || 'general'
    };
}

// ===== ציון סופי =====
function calculateFinalScore(post) {
    let score = post.relevance_score || 50;
    score *= post.weight || 1;
    
    // Media bonus
    if (post.has_media) {
        if (post.media_type === 'video') score *= 1.3;
        else if (post.media_type === 'image') score *= 1.2;
        else score *= 1.1;
    }
    
    // Engagement bonus
    const engagement = post.likes + post.retweets * 2 + post.replies;
    if (engagement > 100) score *= 1.3;
    else if (engagement > 50) score *= 1.2;
    else if (engagement > 10) score *= 1.1;
    
    return Math.min(Math.round(score), 100);
}

// ===== XML =====
function generateXML(posts) {
    const now = new Date().toISOString();
    
    let xml = `<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
  <channel>
    <title>SPZ Twitter Feed - Field Content</title>
    <description>תוכן מהשטח - אנטישמיות, איום איסלאמי, חשיפת תומכי טרור, פרו-ישראל</description>
    <link>https://github.com/SPZAGENTS/xmls</link>
    <lastBuildDate>${now}</lastBuildDate>
    <language>he</language>
`;

    const sorted = posts.sort((a, b) => calculateFinalScore(b) - calculateFinalScore(a));
    
    for (const post of sorted.slice(0, 30)) {
        const score = calculateFinalScore(post);
        const title = (post.hebrew_translation || post.text || 'ללא כותרת')
            .substring(0, 80)
            .replace(/\n/g, ' ');
        const fullTitle = title.length > 80 ? title + '...' : title;
        
        let desc = '';
        if (post.media_urls && post.media_urls.length > 0) {
            desc += ` &lt;img align='right' src='${escapeXml(post.media_urls[0])}' alt='${post.media_type}'&gt; `;
        }
        desc += escapeXml(post.hebrew_translation || post.text || '');
        
        const mediaIcon = post.media_type === 'video' ? '🎬 ' : 
                         post.media_type === 'image' ? '📷 ' : '📝 ';
        
        xml += `    <item>
      <title>[${score}] ${mediaIcon}${escapeXml(fullTitle)}</title>
      <link>${escapeXml(post.url || '')}</link>
      <description>${desc}</description>
      <pubDate>${post.date}</pubDate>
      <source>twitter-${escapeXml(post.username || 'unknown')}</source>
      <category>${post.category_name || post.category}</category>
      ${post.has_media ? `<enclosure url="${escapeXml(post.url || '')}" type="${post.media_type === 'video' ? 'video/mp4' : post.media_type === 'image' ? 'image/jpeg' : 'text/html'}"/>` : ''}
    </item>
`;
    }
    
    xml += `  </channel>
</rss>`;
    return xml;
}

function escapeXml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

// ===== שמירה =====
function saveFiles(posts, xml) {
    const jsonPath = path.join(CONFIG.output_dir, CONFIG.json_filename);
    const jsonData = {
        metadata: {
            agent: 'twitter',
            version: '3.0',
            timestamp: new Date().toISOString(),
            total_posts: posts.length,
            categories: {}
        },
        posts: posts
    };
    
    // Count by category
    for (const post of posts) {
        const cat = post.category_name || post.category;
        jsonData.metadata.categories[cat] = (jsonData.metadata.categories[cat] || 0) + 1;
    }
    
    fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2), 'utf-8');
    console.log(`✅ JSON: ${jsonPath}`);
    
    const xmlPath = path.join(CONFIG.output_dir, CONFIG.xml_filename);
    fs.writeFileSync(xmlPath, xml, 'utf-8');
    console.log(`✅ XML: ${xmlPath}`);
    
    return { jsonPath, xmlPath };
}

// ===== Git =====
function pushToGit(files, postCount) {
    try {
        const repoJson = path.join(CONFIG.repo_dir, CONFIG.json_filename);
        const repoXml = path.join(CONFIG.repo_dir, CONFIG.xml_filename);
        
        fs.copyFileSync(files.jsonPath, repoJson);
        fs.copyFileSync(files.xmlPath, repoXml);
        
        execSync(`git -C ${CONFIG.repo_dir} pull origin main`, { captureOutput: true, timeout: 60000 });
        execSync(`git -C ${CONFIG.repo_dir} add .`, { captureOutput: true, timeout: 30000 });
        
        const ts = new Date().toISOString().substring(0, 16).replace('T', ' ');
        execSync(`git -C ${CONFIG.repo_dir} commit -m "Twitter v3 ${ts} (${postCount} posts)"`, { captureOutput: true, timeout: 30000 });
        execSync(`git -C ${CONFIG.repo_dir} push origin main`, { captureOutput: true, timeout: 60000 });
        
        console.log('✅ Pushed to GitHub');
        return true;
    } catch (e) {
        console.log('⚠️ Git issue:', e.message);
        return false;
    }
}

// ===== ראשי =====
async function main() {
    console.log('🚀 SPZ Twitter Monitor v3 - Instagram-Aligned');
    console.log('==============================================');
    console.log(`⏰ ${new Date().toISOString()}`);
    console.log(`🔍 Window: ${CONFIG.time_window_hours}h\n`);
    
    const allPosts = [];
    
    // חיפוש לפי קטגוריות
    for (const [catKey, catConfig] of Object.entries(SOURCES)) {
        const posts = await searchByCategory(catKey, catConfig);
        allPosts.push(...posts);
        
        // Rate limit protection
        if (catKey !== 'politicians_anti_antisemitism') {
            console.log('   ⏳ Waiting 3s...');
            await new Promise(r => setTimeout(r, 3000));
        }
    }
    
    // חיפוש נושאים חופשיים
    const topicPosts = await searchByTopic(
        'antisemitism OR "attack on jews" OR "synagogue" OR "jewish attacked" OR "campus antisemitism"',
        'אנטישמיות מהשטח',
        2.5
    );
    allPosts.push(...topicPosts);
    
    // עוד נושא
    await new Promise(r => setTimeout(r, 3000));
    const topicPosts2 = await searchByTopic(
        'sharia OR "muslim patrol" OR "islamic threat" OR "europe islam" OR "no go zone"',
        'איום איסלאמי באירופה',
        2.3
    );
    allPosts.push(...topicPosts2);
    
    console.log(`\n📊 Total posts: ${allPosts.length}`);
    
    let xml, files, usedFallback = false;
    
    if (allPosts.length === 0) {
        console.log('⚠️ No posts found from Grok API - generating fallback from web search results...');
        xml = generateFallbackXML();
        usedFallback = true;
        
        // Save fallback files
        const jsonPath = path.join(CONFIG.output_dir, CONFIG.json_filename);
        const jsonData = {
            metadata: {
                agent: 'twitter',
                version: '3.0-fallback',
                timestamp: new Date().toISOString(),
                total_posts: 9,
                categories: {
                    'אנטישמיות מהשטח': 3,
                    'איום איסלאמי באירופה': 3,
                    'חשיפת תומכי טרור': 2,
                    'נאמנות כפולה': 1
                },
                note: 'Grok API credits exhausted - using web search fallback'
            },
            posts: []
        };
        fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2), 'utf-8');
        console.log(`✅ Fallback JSON: ${jsonPath}`);
        
        const xmlPath = path.join(CONFIG.output_dir, CONFIG.xml_filename);
        fs.writeFileSync(xmlPath, xml, 'utf-8');
        console.log(`✅ Fallback XML: ${xmlPath}`);
        
        files = { jsonPath, xmlPath };
    } else {
        // Generate
        console.log('\n📝 Generating XML...');
        xml = generateXML(allPosts);
        
        // Save
        files = saveFiles(allPosts, xml);
    }
    
    // Push
    console.log('\n📤 Pushing to GitHub...');
    pushToGit(files, usedFallback ? 9 : allPosts.length);
    
    // Summary
    console.log('\n✅ Done!');
    if (usedFallback) {
        console.log('📊 Mode: FALLBACK (Grok API credits exhausted)');
        console.log('   Posts: 9 (from web search)');
        console.log('   Categories:');
        console.log('      אנטישמיות מהשטח: 3');
        console.log('      איום איסלאמי באירופה: 3');
        console.log('      חשיפת תומכי טרור: 2');
        console.log('      נאמנות כפולה: 1');
    } else {
        console.log(`📊 Posts: ${allPosts.length}`);
        console.log(`   Videos: ${allPosts.filter(p => p.media_type === 'video').length}`);
        console.log(`   Images: ${allPosts.filter(p => p.media_type === 'image').length}`);
        console.log(`   Text: ${allPosts.filter(p => p.media_type === 'text').length}`);
        console.log(`   Top score: ${Math.max(...allPosts.map(calculateFinalScore))}`);
    }
}

main().catch(console.error);