#!/usr/bin/env python3
"""
SPZ Fast Title Translator
Only translates titles (no descriptions) for speed.
Uses Ollama API with individual calls and timeouts.
Skips failed translations immediately.
"""
import json
import os
import re
import time
import urllib.request
from datetime import datetime

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.2:3b"

def is_hebrew(text):
    return text and any('\u0590' <= c <= '\u05FF' for c in str(text))

def translate_title(title, timeout=30):
    """Translate a single title"""
    if not title or len(title.strip()) < 3:
        return ""
    
    prompt = f"""You are a Hebrew news translator.
RULES:
1. Translate to Hebrew
2. Return ONLY Hebrew translation
3. No English, no explanations, no quotes
4. Keep news style concise

Title: {title}
Hebrew:"""
    
    data = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.1}
    }
    
    try:
        req = urllib.request.Request(
            OLLAMA_URL,
            data=json.dumps(data).encode('utf-8'),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            response = result.get('response', '').strip().strip('"\'').strip()
            return response if is_hebrew(response) else ""
    except Exception:
        return ""

def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {msg}\n")
    print(f"  {msg}")

def process_file(filename):
    filepath = os.path.join(FEEDS_DIR, filename)
    if not os.path.exists(filepath):
        log(f"SKIP {filename}: not found")
        return 0, 0
    
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    posts = data.get('posts', [])
    untranslated = [p for p in posts if not p.get('title_hebrew')]
    
    if not untranslated:
        log(f"SKIP {filename}: all {len(posts)} translated")
        return 0, len(posts)
    
    log(f"START {filename}: {len(untranslated)} to translate")
    print(f"\n📄 {filename}: {len(untranslated)} articles")
    
    translated = 0
    failed = 0
    
    for i, post in enumerate(untranslated):
        title = post.get('title', '')
        if not title:
            continue
        
        print(f"  [{i+1}/{len(untranslated)}] {title[:50]}...", end=" ", flush=True)
        
        start = time.time()
        he = translate_title(title)
        elapsed = time.time() - start
        
        if he:
            post['title_hebrew'] = he
            translated += 1
            print(f"✓ ({elapsed:.1f}s)")
        else:
            failed += 1
            print(f"✗ ({elapsed:.1f}s)")
        
        # Save every 5 articles
        if (i + 1) % 5 == 0:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
    
    # Final save
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    log(f"DONE {filename}: {translated} OK, {failed} fail")
    print(f"  ✓ Saved: {translated} OK, {failed} failed")
    return translated, len(posts)

def main():
    print("=" * 60)
    print("SPZ Fast Title Translator")
    print("=" * 60)
    
    log("=== FAST TRANSLATION SESSION START ===")
    
    total = 0
    for fname in ['rss_feed.json', 'reddit_feed.json', 'twitter_feed.json']:
        t, p = process_file(fname)
        total += t
    
    print(f"\n{'='*60}")
    print(f"DONE: {total} titles translated")
    print(f"{'='*60}")
    log(f"=== END: {total} translated ===")

if __name__ == "__main__":
    main()
