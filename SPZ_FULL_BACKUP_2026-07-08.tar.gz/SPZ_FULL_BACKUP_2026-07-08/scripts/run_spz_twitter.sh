#!/bin/bash
# SPZ Twitter Monitor - Cron Job (xurl version - no Grok credits needed)
# Updated: 2026-05-15 - Switched from Grok API to native X API via xurl

LOG_FILE="$HOME/.openclaw/workspace/logs/twitter_grok.log"
mkdir -p "$HOME/.openclaw/workspace/logs"

echo "========================================" >> "$LOG_FILE"
echo "$(date): Starting SPZ Twitter Monitor (xurl)" >> "$LOG_FILE"

# Check xurl authentication first
if ! xurl auth status > /dev/null 2>&1; then
    echo "$(date): ❌ xurl not authenticated - run: xurl auth oauth2" >> "$LOG_FILE"
    exit 1
fi

# Run the monitor
node "$HOME/.openclaw/workspace/scripts/spz_twitter_xurl.js" >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "$(date): ✅ Success" >> "$LOG_FILE"
else
    echo "$(date): ❌ Failed with exit code $?" >> "$LOG_FILE"
fi

echo "========================================" >> "$LOG_FILE"
