#!/usr/bin/env python3
"""
Translate untranslated articles in SPZ feeds to Hebrew using Gemini CLI.
For each article without 'title_hebrew': translate title and description.
Then run GitHub sync.
"""
import json, subprocess, sys, re, html
from datetime import datetime
from pathlib import Path

WORKSPACE = Path("/home/yosia/.openclaw/workspace")
FEEDS_DIR = WORKSPACE / "spz-feeds"
LOG_FILE = FEEDS_DIR / "translation.log"
SYNC_SCRIPT = WORKSPACE / "active-crons" / "01-spz-rss-hourly" / "spz_github_sync.py"

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def clean_html(text):
    if not text:
        return ""
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    # Decode HTML entities
    text = html.unescape(text)
    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def translate_text(text, batch_num=0, item_num=0):
    """Translate text to Hebrew using Gemini CLI."""
    if not text or len(text.strip()) < 3:
        return ""
    
    # Truncate very long descriptions to save tokens
    if len(text) > 1500:
        text = text[:1500] + "..."
    
    prompt = (
        "Translate the following English news text to natural, fluent Hebrew. "
        "Keep proper nouns (names, places) as commonly used in Israeli media. "
        "Return ONLY the Hebrew translation, nothing else.\n\n"
        f"Text: {text}\n\nHebrew translation:"
    )
    
    try:
        result = subprocess.run(
            ["gemini", "--output-format", "text", prompt],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            hebrew = result.stdout.strip()
            # Clean up any extra quotes or prefixes
            hebrew = re.sub(r'^["\']|["\']$', '', hebrew).strip()
            return hebrew
        else:
            log(f"  ERROR gemini stderr: {result.stderr[:200]}")
            return ""
    except subprocess.TimeoutExpired:
        log(f"  TIMEOUT on batch {batch_num} item {item_num}")
        return ""
    except Exception as e:
        log(f"  EXCEPTION on batch {batch_num} item {item_num}: {e}")
        return ""

def process_feed(filename):
    filepath = FEEDS_DIR / filename
    if not filepath.exists():
        log(f"SKIP: {filename} not found")
        return 0, 0
    
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    posts = data.get("posts", [])
    if not posts:
        log(f"SKIP: {filename} has no posts")
        return 0, 0
    
    to_translate = [p for p in posts if "title_hebrew" not in p]
    already_done = len(posts) - len(to_translate)
    
    log(f"{filename}: {len(posts)} total, {already_done} already translated, {len(to_translate)} to translate")
    
    translated_count = 0
    batch_size = 5  # Process in small batches
    
    for i, post in enumerate(to_translate):
        title = post.get("title", "").strip()
        desc = clean_html(post.get("description", ""))
        
        if not title:
            continue
        
        log(f"  Translating [{i+1}/{len(to_translate)}] from {post.get('source','?')}: {title[:60]}...")
        
        # Translate title
        title_he = translate_text(title, batch_num=i//batch_size, item_num=i)
        if title_he:
            post["title_hebrew"] = title_he
        
        # Translate description (only if meaningful)
        if desc and len(desc) > 10:
            desc_he = translate_text(desc, batch_num=i//batch_size, item_num=i)
            if desc_he:
                post["description_hebrew"] = desc_he
        
        if title_he:
            translated_count += 1
        
        # Save progress every batch
        if (i + 1) % batch_size == 0:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"  Saved progress after {i+1} items")
    
    # Final save
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    log(f"{filename}: DONE - translated {translated_count}/{len(to_translate)} items")
    return translated_count, len(to_translate)

def run_github_sync():
    if not SYNC_SCRIPT.exists():
        log(f"SKIP: sync script not found at {SYNC_SCRIPT}")
        return False
    
    log("Running GitHub sync script...")
    try:
        result = subprocess.run(
            [sys.executable, str(SYNC_SCRIPT)],
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(SYNC_SCRIPT.parent)
        )
        log(f"Sync stdout: {result.stdout[:500]}")
        if result.stderr:
            log(f"Sync stderr: {result.stderr[:500]}")
        log(f"Sync return code: {result.returncode}")
        return result.returncode == 0
    except Exception as e:
        log(f"Sync failed: {e}")
        return False

def main():
    log("=" * 60)
    log("SPZ Translation & Sync Started")
    log("=" * 60)
    
    total_translated = 0
    total_to_translate = 0
    
    for filename in ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]:
        done, total = process_feed(filename)
        total_translated += done
        total_to_translate += total
    
    log(f"\nSUMMARY: {total_translated}/{total_to_translate} articles translated")
    
    # Run GitHub sync
    sync_ok = run_github_sync()
    log(f"GitHub sync: {'SUCCESS' if sync_ok else 'FAILED'}")
    
    log("=" * 60)
    log("SPZ Translation & Sync Complete")
    log("=" * 60)
    
    return 0 if sync_ok else 1

if __name__ == "__main__":
    sys.exit(main())
