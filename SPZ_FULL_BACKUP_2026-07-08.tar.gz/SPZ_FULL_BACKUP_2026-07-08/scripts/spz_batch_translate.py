#!/usr/bin/env python3
"""
SPZ Batch Translator v4 - Ollama API
Translates article titles to Hebrew using Ollama API with strict prompts.
"""
import json
import os
import subprocess
import re
import time
from datetime import datetime
import urllib.request
import urllib.error

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.2:3b"

def is_hebrew(text):
    if not text:
        return False
    return any('\u0590' <= c <= '\u05FF' for c in str(text))

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'https?://\S+', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:300]

def ollama_generate(prompt, temperature=0.1, timeout=60):
    """Call Ollama API directly"""
    data = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": temperature}
    }
    try:
        req = urllib.request.Request(
            OLLAMA_URL,
            data=json.dumps(data).encode('utf-8'),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            return result.get('response', '').strip()
    except Exception as e:
        return f"__ERROR__: {e}"

def translate_batch_titles(titles):
    """Translate multiple titles in one call"""
    if not titles:
        return []
    
    titles_text = "\n".join([f"{i+1}. {t}" for i, t in enumerate(titles)])
    
    prompt = f"""You are a professional Hebrew news translator.
STRICT RULES:
1. Translate each numbered line to Hebrew
2. Return ONLY numbered Hebrew translations
3. NO English words, explanations, or notes
4. NO quotes, markdown, or special formatting
5. Keep news style - concise and accurate

Lines to translate:
{titles_text}

Hebrew translations:"""
    
    response = ollama_generate(prompt, temperature=0.1, timeout=90)
    
    if response.startswith("__ERROR__"):
        print(f"    API error: {response}")
        return [""] * len(titles)
    
    # Parse numbered responses
    translations = []
    lines = [l.strip() for l in response.split('\n') if l.strip()]
    
    for i in range(len(titles)):
        expected_num = i + 1
        found = ""
        for line in lines:
            # Match "1. " or "1) " or just "1"
            match = re.match(rf"^{expected_num}[\.\)\s]+(.+)$", line)
            if match:
                found = match.group(1).strip()
                break
        
        # Fallback: if no numbered match, try positional
        if not found and i < len(lines):
            raw = lines[i]
            found = re.sub(r"^\d+[\.\)\s]+", "", raw).strip()
        
        # Clean quotes
        found = found.strip('"\'').strip()
        
        # Validate
        if is_hebrew(found):
            translations.append(found)
        else:
            translations.append("")
    
    return translations

def translate_single(text, timeout=60):
    """Translate a single text string"""
    if not text or len(text.strip()) < 3:
        return ""
    
    prompt = f"""You are a professional Hebrew news translator.
STRICT RULES:
1. Translate to Hebrew
2. Return ONLY the Hebrew translation
3. NO English words, explanations, or notes
4. NO quotes or special formatting
5. Keep news style - concise and accurate

Text: {text}

Hebrew:"""
    
    response = ollama_generate(prompt, temperature=0.1, timeout=timeout)
    
    if response.startswith("__ERROR__"):
        return ""
    
    response = response.strip('"\'').strip()
    if is_hebrew(response):
        return response
    return ""

def log_action(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")

def process_file(filename, batch_size=5):
    filepath = os.path.join(FEEDS_DIR, filename)
    if not os.path.exists(filepath):
        log_action(f"SKIP {filename}: not found")
        return 0, 0
    
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    posts = data.get('posts', [])
    untranslated = [p for p in posts if not p.get('title_hebrew')]
    
    if not untranslated:
        log_action(f"SKIP {filename}: all {len(posts)} translated")
        return 0, len(posts)
    
    log_action(f"START {filename}: {len(untranslated)}/{len(posts)} to translate")
    print(f"\n📄 {filename}: {len(untranslated)} articles to translate")
    
    translated = 0
    failed = 0
    total_batches = (len(untranslated) + batch_size - 1) // batch_size
    
    for i in range(0, len(untranslated), batch_size):
        batch = untranslated[i:i+batch_size]
        batch_num = i // batch_size + 1
        
        titles = [p.get('title', '') for p in batch]
        print(f"  Batch {batch_num}/{total_batches}: translating {len(batch)} titles...", end=" ", flush=True)
        
        start = time.time()
        hebrew_titles = translate_batch_titles(titles)
        elapsed = time.time() - start
        
        ok_count = sum(1 for h in hebrew_titles if h)
        print(f"({ok_count}/{len(batch)} OK, {elapsed:.1f}s)")
        
        for post, he_title in zip(batch, hebrew_titles):
            if he_title:
                post['title_hebrew'] = he_title
                translated += 1
                
                # Also translate description
                desc = clean_text(post.get('description', ''))
                if desc and len(desc) > 15:
                    desc_he = translate_single(desc, timeout=60)
                    if desc_he:
                        post['description_hebrew'] = desc_he
            else:
                failed += 1
                log_action(f"FAIL title: {post.get('title','')[:60]}")
        
        # Save progress after each batch
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        time.sleep(0.3)
    
    log_action(f"DONE {filename}: {translated} OK, {failed} fail")
    print(f"  ✓ Saved: {translated} translated, {failed} failed")
    return translated, len(posts)

def main():
    print("=" * 60)
    print("SPZ Batch Translator v4 - Ollama API")
    print("=" * 60)
    
    if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 1024*1024:
        os.rename(LOG_FILE, LOG_FILE + ".old")
    
    log_action("=== TRANSLATION SESSION START ===")
    
    # Quick test
    print("\n🔧 Testing translation...")
    test = translate_single("Hello world")
    print(f"  Test: '{test}'")
    if not test:
        print("  ✗ Translation failed, aborting")
        log_action("ABORT: test failed")
        return
    print("  ✓ Test passed")
    
    total_translated = 0
    total_posts = 0
    
    for fname in ['rss_feed.json', 'reddit_feed.json', 'twitter_feed.json']:
        t, p = process_file(fname, batch_size=5)
        total_translated += t
        total_posts += p
    
    print(f"\n{'='*60}")
    print(f"SUMMARY: {total_translated} translated / {total_posts} total")
    print(f"{'='*60}")
    log_action(f"=== END: {total_translated}/{total_posts} ===")

if __name__ == "__main__":
    main()
