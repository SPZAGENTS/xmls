# ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
# ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
# 
# יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה

#!/usr/bin/env python3

"""
⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
⚠️ Rule 0: Read ~/.openclaw/workspace/MASTER-INSIGHTS.md first

בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות
Check if there are insights we learned that can be used in the action I'm about to take
"""

"""
SPZ RSS Agent - News Aggregator
Scrapes RSS feeds from Israeli and Jewish news sources
"""

import json
import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
import os
import re

# Configuration
OUTPUT_DIR = "spz-feeds"
OUTPUT_FILE = "rss_feed.json"

# RSS Sources with weights (higher = more important)
RSS_SOURCES = {
    "Times of Israel": {
        "url": "https://www.timesofisrael.com/feed/",
        "weight": 1.2,
        "type": "israeli"
    },
    "Jerusalem Post": {
        "url": "https://www.jpost.com/rss/rssfeedsfrontpage.aspx",
        "weight": 1.1,
        "type": "israeli"
    },
    "Ynet": {
        "url": "https://www.ynet.co.il/Integration/StoryRss1854.xml",
        "weight": 1.0,
        "type": "israeli"
    },
    "BBC World": {
        "url": "http://feeds.bbci.co.uk/news/world/rss.xml",
        "weight": 0.9,
        "type": "international"
    },
    "Reuters": {
        "url": "https://www.reuters.com/world/middle-east/rss.xml",
        "weight": 0.95,
        "type": "international"
    },
    "Guardian World": {
        "url": "https://www.theguardian.com/world/rss",
        "weight": 0.85,
        "type": "international"
    },
    "France24": {
        "url": "https://www.france24.com/en/middle-east/rss",
        "weight": 0.9,
        "type": "international"
    },
    "Israel Hayom": {
        "url": "https://www.israelhayom.com/feed/",
        "weight": 1.0,
        "type": "israeli"
    },
    "Washington Post": {
        "url": "https://feeds.washingtonpost.com/rss/world",
        "weight": 0.85,
        "type": "international"
    },
    "NPR World": {
        "url": "https://feeds.npr.org/1001/rss.xml",
        "weight": 0.8,
        "type": "international"
    },
    "NYT World": {
        "url": "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
        "weight": 0.9,
        "type": "international"
    },
    "Fox News": {
        "url": "https://moxie.foxnews.com/google-publisher/world.xml",
        "weight": 0.8,
        "type": "international"
    },
    "ABC News": {
        "url": "https://abcnews.go.com/abcnews/internationalheadlines",
        "weight": 0.8,
        "type": "international"
    },
    "CBC World": {
        "url": "https://www.cbc.ca/cmlink/rss-world",
        "weight": 0.75,
        "type": "international"
    },
    "Geektime": {
        "url": "https://www.geektime.co.il/feed/",
        "weight": 1.3,
        "type": "israeli"
    }
}

# Keywords for filtering and scoring
PRIORITY_KEYWORDS = [
    "israel", "gaza", "hamas", "idf", "netanyahu",
    "iran", "hezbollah", "palestine", "jewish", "judaism",
    "tel aviv", "jerusalem", "west bank", "hostage",
    "iron dome", "iron swords", "middle east",
    "antisemitism", "holocaust", "rocket", "missile",
    "tunnel", "ceasefire", "aliyah", "kibbutz"
]

SECONDARY_KEYWORDS = [
    "war", "conflict", "peace", "negotiation",
    "settlement", "knesset", "election"
]

class RSSAgent:
    def __init__(self):
        self.posts = []
        self.seen_urls = set()
        
        # Create output directory
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        # Load existing URLs to avoid duplicates
        self._load_existing_urls()
    
    def _load_existing_urls(self):
        """Load previously seen URLs from output file"""
        output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
        if os.path.exists(output_path):
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for post in data.get('posts', []):
                        self.seen_urls.add(post.get('url', ''))
            except Exception as e:
                print(f"[WARNING] Could not load existing URLs: {e}")
    
    def fetch_feed(self, source_name, source_config):
        """Fetch and parse RSS feed"""
        print(f"\n[RSS] Fetching {source_name}...")
        
        try:
            headers = {
                'User-Agent': 'SPZ-NewsAggregator/1.0 (Research Project)'
            }
            response = requests.get(
                source_config['url'],
                headers=headers,
                timeout=30
            )
            response.raise_for_status()
            
            # Parse XML
            root = ET.fromstring(response.content)
            
            # Handle RSS 2.0 and Atom formats
            items = []
            if root.tag == 'rss':
                channel = root.find('channel')
                if channel is not None:
                    items = channel.findall('item')
            elif root.tag.endswith('feed'): # Atom
                items = root.findall('.//{http://www.w3.org/2005/Atom}entry')
            
            print(f"[OK] {source_name}: Found {len(items)} items")
            return items
            
        except requests.RequestException as e:
            print(f"[ERROR] {source_name} request failed: {e}")
            return []
        except ET.ParseError as e:
            print(f"[ERROR] {source_name} XML parse error: {e}")
            return []
        except Exception as e:
            print(f"[ERROR] {source_name} unexpected error: {e}")
            return []
    
    def parse_item(self, item, source_name, source_config):
        """Parse RSS item into post dict"""
        try:
            # Extract fields based on RSS/Atom format
            title = ""
            url = ""
            description = ""
            pub_date = None
            
            # Try RSS 2.0 format first
            title_elem = item.find('title')
            if title_elem is not None:
                title = title_elem.text or ""
            
            link_elem = item.find('link')
            if link_elem is not None:
                url = link_elem.text or ""
            
            desc_elem = item.find('description')
            if desc_elem is not None:
                description = desc_elem.text or ""
            
            date_elem = item.find('pubDate')
            if date_elem is not None and date_elem.text:
                pub_date = self._parse_date(date_elem.text)
            
            # Try Atom format if RSS fields not found
            if not title:
                ns = {'atom': 'http://www.w3.org/2005/Atom'}
                title_elem = item.find('atom:title', ns)
                if title_elem is not None:
                    title = title_elem.text or ""
            
            if not url:
                ns = {'atom': 'http://www.w3.org/2005/Atom'}
                link_elem = item.find('atom:link', ns)
                if link_elem is not None:
                    url = link_elem.get('href', '')
            
            if not pub_date:
                ns = {'atom': 'http://www.w3.org/2005/Atom'}
                date_elem = item.find('atom:updated', ns) or item.find('atom:published', ns)
                if date_elem is not None and date_elem.text:
                    pub_date = self._parse_date(date_elem.text)
            
            # Skip if missing critical fields
            if not title or not url:
                return None
            
            # Check for duplicates
            if url in self.seen_urls:
                return None
            
            # Calculate importance
            importance = self._calculate_importance(
                title, description, source_config
            )
            
            # Filter by relevance (minimum importance threshold)
            if importance < 15:
                return None
            
            # Extract image URL BEFORE truncating description
            image_url = self._extract_image_url(item, description, source_name, url)
            
            return {
                "title": title.strip(),
                "url": url.strip(),
                "permalink": url.strip(),
                "source": source_name,
                "source_type": source_config.get('type', 'unknown'),
                "description": description[:500] if description else "",
                "imageUrl": image_url,
                "importance": importance,
                "source_weight": source_config.get('weight', 1.0),
                "created_date": pub_date.isoformat() if pub_date else datetime.now(timezone.utc).isoformat(),
                "source_agent": "rss",
                "keywords_matched": self._extract_keywords(title + " " + description)
            }
            
        except Exception as e:
            print(f"[WARNING] Error parsing item: {e}")
            return None
    
    def _parse_date(self, date_string):
        """Parse various date formats"""
        formats = [
            '%a, %d %b %Y %H:%M:%S %z',  # RSS standard
            '%a, %d %b %Y %H:%M:%S %Z',  # RSS with timezone name
            '%Y-%m-%dT%H:%M:%S%z',       # ISO 8601
            '%Y-%m-%dT%H:%M:%SZ',        # ISO 8601 UTC
            '%Y-%m-%d %H:%M:%S',         # Simple format
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_string.strip(), fmt)
            except ValueError:
                continue
        
        return None
    
    def _calculate_importance(self, title, description, source_config):
        """Calculate importance score (0-100)"""
        score = 0
        text = (title + " " + description).lower()
        
        # Source weight bonus (max 20 points)
        weight = source_config.get('weight', 1.0)
        score += int(weight * 15)
        
        # Priority keywords (10 points each, max 50)
        priority_matches = 0
        for keyword in PRIORITY_KEYWORDS:
            if keyword in text:
                priority_matches += 1
        score += min(50, priority_matches * 10)
        
        # Secondary keywords (5 points each, max 20)
        secondary_matches = 0
        for keyword in SECONDARY_KEYWORDS:
            if keyword in text:
                secondary_matches += 1
        score += min(20, secondary_matches * 5)
        
        # Breaking news boost
        breaking_words = ['breaking', 'urgent', 'update', 'live', 'now']
        if any(word in title.lower() for word in breaking_words):
            score += 15
        
        return min(100, score)
    
    def _extract_image_url(self, item, description, source_name="", item_url=""):
        """Extract image URL from RSS item - checks media:thumbnail, media:content, enclosure, and img tags in description
        Also fetches og:image for sources that don't provide images in RSS"""
        import re
        import urllib.request
        
        ns = {'media': 'http://search.yahoo.com/mrss/'}
        
        # Check media:thumbnail (Yahoo Media RSS)
        thumb = item.find('media:thumbnail', ns)
        if thumb is not None:
            url = thumb.get('url', '')
            if url:
                return url
        
        # Check media:content (Guardian etc.)
        content = item.find('media:content', ns)
        if content is not None:
            url = content.get('url', '')
            if url:
                return url
        
        # Check enclosure (must be image type)
        enclosure = item.find('enclosure')
        if enclosure is not None:
            enc_url = enclosure.get('url', '')
            enc_type = enclosure.get('type', '')
            if enc_url and enc_type.startswith('image/'):
                return enc_url
        
        # Check for <img src="..."> in description
        if description:
            match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', description)
            if match:
                return match.group(1)
        
        return None
    
    def _extract_keywords(self, text):
        """Extract matched keywords from text"""
        text = text.lower()
        matched = []
        for keyword in PRIORITY_KEYWORDS:
            if keyword in text:
                matched.append(keyword)
        return matched
    
    def run(self):
        """Main execution"""
        print("="*60)
        print("SPZ RSS Agent - Starting")
        print("="*60)
        
        total_new_posts = 0
        
        for source_name, source_config in RSS_SOURCES.items():
            items = self.fetch_feed(source_name, source_config)
            
            for item in items[:20]:  # Limit to 20 items per source
                post = self.parse_item(item, source_name, source_config)
                if post:
                    self.posts.append(post)
                    self.seen_urls.add(post['url'])
                    total_new_posts += 1
        
        # Sort by importance
        self.posts.sort(key=lambda x: x['importance'], reverse=True)
        
        # Save output
        output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
        output_data = {
            "metadata": {
                "agent": "rss",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "total_posts": len(self.posts),
                "sources_checked": len(RSS_SOURCES)
            },
            "posts": self.posts
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)
        
        print("\n" + "="*60)
        print(f"[DONE] RSS Agent completed")
        print(f"[DONE] Total new posts: {total_new_posts}")
        print(f"[DONE] Output saved to: {output_path}")
        print("="*60)
        
        return output_data

if __name__ == "__main__":
    agent = RSSAgent()
    agent.run()
