#!/usr/bin/env python3
"""
SPZ Translation with Google Gemini API
Uses the installed google.generativeai library
"""

import json
import os
import sys
import re
import html
import time
from datetime import datetime

# Paths
FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
FEED_FILES = ["rss_feed.json", "reddit_feed.json", "twitter-grok-feed.json"]
MAX_PER_RUN = 100

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    text = ' '.join(text.split())
    return text.strip()

def is_hebrew(text):
    if not text:
        return False
    return any('\u0590' <= c <= '\u05FF' for c in text)

def translate_with_gemini(texts, api_key):
    """Translate texts using Google Gemini API via google.generativeai"""
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        
        model = genai.GenerativeModel('gemini-2.0-flash')
        
        results = []
        for text in texts:
            if not text or len(text.strip()) < 3:
                results.append("")
                continue
            
            prompt = f"""Translate the following text to Hebrew. Return ONLY the Hebrew translation, nothing else:

Text: {text}"""
            
            try:
                response = model.generate_content(prompt)
                translation = response.text.strip()
                
                # Validate it's actually Hebrew
                if is_hebrew(translation):
                    results.append(translation)
                else:
                    # Retry with stronger instruction
                    prompt2 = f"""Translate EXACTLY to Hebrew (עברית). Do NOT explain, do NOT add notes, return ONLY Hebrew text:

{text}"""
                    response2 = model.generate_content(prompt2)
                    translation2 = response2.text.strip()
                    if is_hebrew(translation2):
                        results.append(translation2)
                    else:
                        results.append("")
                
                time.sleep(0.5)  # Rate limit
            except Exception as e:
                log(f"  Gemini error on text: {str(e)[:80]}")
                results.append("")
        
        return results
    except ImportError:
        log("ERROR: google.generativeai not installed")
        return None
    except Exception as e:
        log(f"ERROR: Gemini translation failed: {e}")
        return None

def translate_batch(titles, descriptions, api_key):
    """Translate a batch of titles and descriptions"""
    log(f"  Translating {len(titles)} titles...")
    translated_titles = translate_with_gemini(titles, api_key)
    if translated_titles is None:
        return None, None
    
    # Small delay between batches
    time.sleep(1)
    
    log(f"  Translating {len(descriptions)} descriptions...")
    translated_descs = translate_with_gemini(descriptions, api_key)
    if translated_descs is None:
        return None, None
    
    return translated_titles, translated_descs

def process_feed(filepath, feed_name, api_key, max_translations=50):
    if not os.path.exists(filepath):
        log(f"SKIP: {feed_name} not found: {filepath}")
        return 0, 0

    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    posts = data.get("posts", data if isinstance(data, list) else [])
    total = len(posts)
    
    # Find untranslated posts
    untranslated = []
    for i, post in enumerate(posts):
        if not post.get("title_hebrew") or not is_hebrew(post.get("title_hebrew", "")):
            untranslated.append((i, post))
    
    count = len(untranslated)
    log(f"{feed_name}: {total} total, {count} untranslated")
    
    if count == 0:
        log(f"{feed_name}: All translated ✓")
        return 0, total
    
    # Limit per run
    to_translate = untranslated[:max_translations]
    log(f"  Will translate {len(to_translate)} this run")
    
    # Prepare batches
    batch_size = 10
    translated_count = 0
    failed_count = 0
    
    for batch_start in range(0, len(to_translate), batch_size):
        batch = to_translate[batch_start:batch_start + batch_size]
        
        titles = []
        descs = []
        indices = []
        
        for idx, post in batch:
            title = clean_text(post.get("title", ""))
            desc = clean_text(post.get("description", ""))[:300]  # Limit length
            
            if title:
                titles.append(title)
                descs.append(desc)
                indices.append(idx)
        
        if not titles:
            continue
        
        log(f"  Batch {batch_start//batch_size + 1}/{(len(to_translate)-1)//batch_size + 1} ({len(titles)} items)...")
        
        translated_titles, translated_descs = translate_batch(titles, descs, api_key)
        
        if translated_titles is None:
            log(f"  Batch failed completely")
            failed_count += len(batch)
            continue
        
        # Update posts
        for i, idx in enumerate(indices):
            if i < len(translated_titles) and translated_titles[i]:
                posts[idx]["title_hebrew"] = translated_titles[i]
                if i < len(translated_descs) and translated_descs[i]:
                    posts[idx]["description_hebrew"] = translated_descs[i]
                posts[idx]["_translated_at"] = datetime.now().isoformat()
                posts[idx]["_translator"] = "gemini-2.0-flash"
                translated_count += 1
            else:
                failed_count += 1
        
        # Save progress after each batch
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        time.sleep(1)  # Brief pause between batches
    
    log(f"{feed_name}: {translated_count} translated, {failed_count} failed")
    return translated_count, total

def main():
    log("=" * 50)
    log("SPZ Translation with Gemini")
    log("=" * 50)
    
    # Get API key from environment
    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        # Try loading from env file
        env_file = os.path.join(os.path.dirname(__file__), ".env")
        if os.path.exists(env_file):
            with open(env_file, "r") as f:
                for line in f:
                    if line.startswith("GEMINI_API_KEY="):
                        api_key = line.strip().split("=", 1)[1].strip().strip('"')
                        break
    
    if not api_key:
        log("ERROR: No GEMINI_API_KEY found. Set it in .env or environment.")
        return 1
    
    log(f"API Key: {api_key[:8]}...{api_key[-4:]}")
    
    total_translated = 0
    total_posts = 0
    
    for feed_file in FEED_FILES:
        filepath = os.path.join(FEEDS_DIR, feed_file)
        translated, total = process_feed(filepath, feed_file, api_key, MAX_PER_RUN // len(FEED_FILES))
        total_translated += translated
        total_posts += total
    
    log("=" * 50)
    log(f"SUMMARY: {total_translated} translated / {total_posts} total")
    log("=" * 50)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
