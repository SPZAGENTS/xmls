#!/usr/bin/env python3
"""
SPZ Translate & Sync - FIXED
Translates untranslated articles to Hebrew, then runs GitHub sync.
Uses CORRECT feeds directory.
"""

import json
import os
import sys
import time
import re
import html
from datetime import datetime
import subprocess
import urllib.request
import urllib.error

# CORRECT paths - the main workspace feeds
FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = "/home/yosia/.openclaw/workspace/spz-feeds/translation.log"
SYNC_SCRIPT = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"

# API key from .env file
OPENAI_API_KEY = "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"
API_URL = "https://api.openai.com/v1/chat/completions"


def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    text = text.replace('\n', ' ').strip()
    text = re.sub(r'\s+', ' ', text)
    return text[:500]


def translate_single(title, description):
    """Translate one article using OpenAI API."""
    title_clean = clean_text(title)
    desc_clean = clean_text(description)

    prompt = f"""Translate this news article from English to Hebrew.

ENGLISH TITLE: {title_clean}
ENGLISH DESCRIPTION: {desc_clean}

Return EXACTLY two lines, nothing else:
HEBREW_TITLE: <Hebrew translation of the title>
HEBREW_DESC: <Hebrew translation of the description>

Rules:
- Use natural, modern Hebrew
- Keep proper names in common Hebrew transliteration
- Make the headline concise and impactful
- Output ONLY the two lines above"""

    payload = json.dumps({
        "model": "gpt-4.1-nano",
        "messages": [
            {"role": "system", "content": "You are a professional news translator from English to Hebrew."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.1,
        "max_tokens": 300
    }).encode('utf-8')

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {OPENAI_API_KEY}"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
        content = data['choices'][0]['message']['content'].strip()

        ht = hd = ""
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("HEBREW_TITLE:"):
                ht = line[len("HEBREW_TITLE:"):].strip()
            elif line.startswith("HEBREW_DESC:"):
                hd = line[len("HEBREW_DESC:"):].strip()

        # Validate Hebrew content
        if ht and any('\u0590' <= c <= '\u05FF' for c in ht):
            return ht, hd or ""
        return None, None
    except Exception as e:
        log(f"    OpenAI error: {str(e)[:120]}")
        return None, None


def process_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    posts = data.get("posts", [])
    # Find posts that need translation
    untranslated = []
    for post in posts:
        th = post.get("title_hebrew", "")
        if not th or not any('\u0590' <= c <= '\u05FF' for c in str(th)):
            untranslated.append(post)

    if not untranslated:
        log(f"{os.path.basename(filepath)}: all {len(posts)} already translated")
        return 0, 0

    log(f"{os.path.basename(filepath)}: {len(posts)} total, {len(untranslated)} to translate")
    ok = fail = 0

    for i, post in enumerate(untranslated, 1):
        title = post.get("title", "")
        desc = post.get("description", "")

        ht, hd = translate_single(title, desc)

        if ht:
            post["title_hebrew"] = ht
            post["description_hebrew"] = hd or ""
            ok += 1
            log(f"  [{i}/{len(untranslated)}] OK {ht[:70]}")
        else:
            fail += 1
            log(f"  [{i}/{len(untranslated)}] FAIL {str(title)[:60]}...")

        # Save progress every 5 articles
        if i % 5 == 0:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"  Progress saved: {ok}/{len(untranslated)} done")

        time.sleep(0.3)

    # Final save
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    log(f"{os.path.basename(filepath)}: DONE. Translated {ok}, failed {fail}")
    return ok, len(untranslated)


def run_github_sync():
    if not os.path.exists(SYNC_SCRIPT):
        log(f"Sync script not found: {SYNC_SCRIPT}")
        return False
    log("Running GitHub sync...")
    result = subprocess.run(
        [sys.executable, SYNC_SCRIPT],
        capture_output=True, text=True, timeout=300,
        cwd="/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly"
    )
    log(f"  Sync stdout: {result.stdout[:500]}")
    if result.stderr:
        log(f"  Sync stderr: {result.stderr[:500]}")
    log(f"  Sync return code: {result.returncode}")
    return result.returncode == 0


def main():
    log("=" * 60)
    log("SPZ Translate & Sync (FIXED) started")
    log("=" * 60)
    log(f"FEEDS_DIR: {FEEDS_DIR}")

    total_ok = total_fail = 0
    for fname in ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]:
        fp = os.path.join(FEEDS_DIR, fname)
        if os.path.exists(fp):
            ok, total = process_file(fp)
            total_ok += ok
            total_fail += (total - ok)
            time.sleep(1)
        else:
            log(f"{fname}: file not found")

    log(f"\nSummary: {total_ok} translated, {total_fail} failed")

    if total_ok > 0:
        success = run_github_sync()
        if success:
            log("GitHub sync completed successfully")
        else:
            log("GitHub sync failed")
    else:
        log("No translations made, skipping sync")

    log("=" * 60)
    log("SPZ Translate & Sync (FIXED) finished")
    log("=" * 60)


if __name__ == "__main__":
    main()
