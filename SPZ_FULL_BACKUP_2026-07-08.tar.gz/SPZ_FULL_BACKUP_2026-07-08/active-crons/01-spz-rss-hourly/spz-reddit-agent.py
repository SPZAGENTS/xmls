# ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
# ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
#
# יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה

#!/usr/bin/env python3
"""
---
name: spz-reddit-agent
version: "2.0.0"
description: SPZ Reddit Agent - Using RSS feeds (no credentials needed)
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
---
"""
"""
SPZ Reddit Agent - RSS Version (no credentials needed)
Fetches Israeli/Jewish related subreddits via RSS feeds
"""

import feedparser
import json
import os
from datetime import datetime
from collections import defaultdict

# Reddit RSS sources (no credentials needed!)
REDDIT_SOURCES = {
    "reddit-israel": {
        "url": "https://www.reddit.com/r/Israel/new/.rss",
        "weight": 1.2,
        "type": "reddit"
    },
    "reddit-judaism": {
        "url": "https://www.reddit.com/r/Judaism/new/.rss",
        "weight": 1.1,
        "type": "reddit"
    },
    "reddit-jewish": {
        "url": "https://www.reddit.com/r/Jewish/new/.rss",
        "weight": 1.0,
        "type": "reddit"
    },
    "reddit-zionism": {
        "url": "https://www.reddit.com/r/Zionism/new/.rss",
        "weight": 0.9,
        "type": "reddit"
    },
    "reddit-worldnews": {
        "url": "https://www.reddit.com/r/WorldNews/new/.rss",
        "weight": 0.85,
        "type": "reddit"
    },
    "reddit-middleeast": {
        "url": "https://www.reddit.com/r/MiddleEast/new/.rss",
        "weight": 0.9,
        "type": "reddit"
    },
    "reddit-geopolitics": {
        "url": "https://www.reddit.com/r/geopolitics/new/.rss",
        "weight": 0.8,
        "type": "reddit"
    },
    "reddit-news": {
        "url": "https://www.reddit.com/r/news/new/.rss",
        "weight": 0.75,
        "type": "reddit"
    },
    "reddit-israel-palestine": {
        "url": "https://www.reddit.com/r/IsraelPalestine/new/.rss",
        "weight": 0.85,
        "type": "reddit"
    },
    "reddit-military": {
        "url": "https://www.reddit.com/r/Military/new/.rss",
        "weight": 0.7,
        "type": "reddit"
    }
}

# Keywords for filtering and scoring
PRIORITY_KEYWORDS = [
    "israel", "gaza", "hamas", "idf", "netanyahu", "palestine", "jewish", "judaism",
    "tel aviv", "jerusalem", "west bank", "hostage", "iron dome", "iron swords",
    "antisemitism", "kibbutz", "golan", "hezbollah", "iran", "lebanon",
    "hamas leader", "terrorist", "rocket", "missile", "ceasefire", "war"
]

def calculate_importance(title, content=""):
    """Calculate importance score based on keywords"""
    text = (title + " " + content).lower()
    score = 50  # Base score

    for keyword in PRIORITY_KEYWORDS:
        if keyword in text:
            score += 10

    return min(score, 100)

def fetch_reddit_rss(source_name, config):
    """Fetch posts from Reddit RSS feed"""
    posts = []

    try:
        print(f"[REDDIT] Fetching {source_name}...")

        # Add User-Agent to avoid being blocked
        import urllib.request
        opener = urllib.request.build_opener()
        opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')]
        urllib.request.install_opener(opener)

        feed = feedparser.parse(config["url"])

        for entry in feed.entries[:25]:  # Max 25 posts
            title = entry.get("title", "")
            url = entry.get("link", "")

            # Skip if no title or url
            if not title or not url:
                continue

            # Extract date
            date_str = entry.get("published", "")
            try:
                pub_date = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S+00:00") if date_str else datetime.now()
            except:
                pub_date = datetime.now()

            # Extract image URL
            image_url = None
            # Try media thumbnail
            if 'media_thumbnail' in entry:
                image_url = entry.media_thumbnail[0].get('url')
            # Try content for img tags
            content = entry.get("content", [{}])[0].get("value", "")
            if not image_url and content:
                import re
                match = re.search(r'<img[^\u003e]+src="([^"]+)"', content)
                if match:
                    image_url = match.group(1)
            
            # Calculate importance
            importance = calculate_importance(title)

            post = {
                "title": title,
                "url": url,
                "permalink": url,
                "source": source_name,
                "source_type": "reddit",
                "description": entry.get("summary", "")[:300],
                "imageUrl": image_url,
                "importance": importance,
                "source_weight": config["weight"],
                "created_date": pub_date.isoformat(),
                "source_agent": "reddit"
            }
            posts.append(post)

        print(f"[OK] {source_name}: Found {len(posts)} items")
        return posts

    except Exception as e:
        print(f"[ERROR] {source_name}: {e}")
        return []

def main():
    """Main function"""
    print("="*60)
    print("SPZ Reddit Agent - RSS Version - Starting")
    print("="*60)

    all_posts = []

    # Fetch from all Reddit RSS feeds
    for source_name, config in REDDIT_SOURCES.items():
        posts = fetch_reddit_rss(source_name, config)
        all_posts.extend(posts)

    # Sort by importance
    all_posts.sort(key=lambda x: x["importance"], reverse=True)

    # Deduplicate by URL
    seen_urls = set()
    unique_posts = []
    for post in all_posts:
        if post["url"] not in seen_urls:
            seen_urls.add(post["url"])
            unique_posts.append(post)

    # Save results
    output_dir = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz-feeds"
    os.makedirs(output_dir, exist_ok=True)

    # JSON output
    output = {
        "metadata": {
            "agent": "reddit",
            "timestamp": datetime.now().isoformat(),
            "total_posts": len(unique_posts),
            "sources_checked": len(REDDIT_SOURCES)
        },
        "posts": unique_posts
    }

    json_path = os.path.join(output_dir, "reddit_feed.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"[DONE] Reddit Agent completed")
    print(f"[DONE] Total posts: {len(unique_posts)}")
    print(f"[DONE] Output: {json_path}")
    print(f"{'='*60}")

    return unique_posts

if __name__ == "__main__":
    main()
