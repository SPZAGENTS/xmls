#!/usr/bin/env python3
"""
SPZ Translate & Sync
Translates untranslated articles to Hebrew, then runs GitHub sync.
"""

import json
import os
import sys
import time
from datetime import datetime
import subprocess
import urllib.request
import urllib.error

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = "/home/yosia/.openclaw/workspace/spz-feeds/translation.log"
SYNC_SCRIPT = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"

XAI_API_KEY = os.environ.get("XAI_API_KEY", "xai-zesycAgCOo8Rm4FjlhnsYZhBmxswrp83RgDK7qAsGRiVZO9HEI2BKnMyglrCHVzBexXtf68OK7hkNGKs")


def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def translate_text(text: str, is_title: bool = False) -> str:
    """Translate English text to Hebrew using xAI Grok API."""
    if not text or len(text.strip()) < 2:
        return text

    prompt_type = "title" if is_title else "description"
    max_len = 150 if is_title else 2000
    truncated = text[:max_len]

    system_msg = (
        "You are a professional news translator. "
        "Translate the following English news text to natural, fluent Hebrew. "
        "Preserve the tone and meaning. Return ONLY the Hebrew translation, no explanations."
    )

    payload = {
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": f"Translate this news {prompt_type} to Hebrew:\n\n{truncated}"}
        ],
        "model": "grok-4.3",
        "stream": False,
        "temperature": 0.3
    }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api.x.ai/v1/chat/completions",
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {XAI_API_KEY}"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            translated = result["choices"][0]["message"]["content"].strip()
            # Clean up common wrapper text
            for prefix in ["תרגום:", "Hebrew:", "**", '"']:
                if translated.startswith(prefix):
                    translated = translated[len(prefix):].strip()
            return translated
    except Exception as e:
        log(f"  Translation error: {e}")
        return ""


def process_feed(filename):
    filepath = os.path.join(FEEDS_DIR, filename)
    if not os.path.exists(filepath):
        log(f"Feed not found: {filepath}")
        return 0, 0

    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    posts = []
    if isinstance(data, list):
        posts = data
    elif isinstance(data, dict) and "posts" in data:
        posts = data["posts"]
    elif isinstance(data, dict) and "entries" in data:
        posts = data["entries"]
    else:
        log(f"Unknown structure in {filename}, keys: {list(data.keys()) if isinstance(data, dict) else 'list'}")
        return 0, 0

    untranslated = [p for p in posts if not p.get("title_hebrew")]
    total = len(posts)
    to_translate = len(untranslated)

    log(f"{filename}: {total} total, {to_translate} to translate")

    if to_translate == 0:
        return 0, 0

    translated_count = 0
    for i, post in enumerate(untranslated, 1):
        title = post.get("title", "")
        desc = post.get("description", "")
        log(f"  [{i}/{to_translate}] Translating: {title[:80]}...")

        title_he = translate_text(title, is_title=True)
        time.sleep(0.5)
        desc_he = translate_text(desc, is_title=False)

        if title_he:
            post["title_hebrew"] = title_he
            translated_count += 1
        if desc_he:
            post["description_hebrew"] = desc_he

        time.sleep(0.3)  # Rate limit

    # Save back preserving original structure
    if isinstance(data, list):
        data_to_save = posts
    elif isinstance(data, dict) and "posts" in data:
        data_to_save = data
    elif isinstance(data, dict) and "entries" in data:
        data_to_save = data
    else:
        data_to_save = posts

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data_to_save, f, ensure_ascii=False, indent=2)

    log(f"  Saved {filename} with {translated_count} new translations")
    return to_translate, translated_count


def run_sync():
    log("Running GitHub sync script...")
    result = subprocess.run(
        [sys.executable, SYNC_SCRIPT],
        capture_output=True,
        text=True,
        timeout=300,
        cwd="/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly"
    )
    log(f"  Sync stdout: {result.stdout[:500]}")
    if result.stderr:
        log(f"  Sync stderr: {result.stderr[:500]}")
    log(f"  Sync return code: {result.returncode}")
    return result.returncode == 0


def main():
    log("=" * 60)
    log("SPZ Translate & Sync started")
    log("=" * 60)

    total_to_translate = 0
    total_translated = 0

    for feed_file in ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]:
        to_translate, translated = process_feed(feed_file)
        total_to_translate += to_translate
        total_translated += translated
        if to_translate > 0:
            time.sleep(1)  # Breather between feeds

    log(f"\nSummary: {total_translated}/{total_to_translate} articles translated")

    if total_translated > 0:
        success = run_sync()
        if success:
            log("GitHub sync completed successfully")
        else:
            log("GitHub sync failed - check logs above")
    else:
        log("No translations needed, skipping sync")

    log("=" * 60)
    log("SPZ Translate & Sync finished")
    log("=" * 60)


if __name__ == "__main__":
    main()
