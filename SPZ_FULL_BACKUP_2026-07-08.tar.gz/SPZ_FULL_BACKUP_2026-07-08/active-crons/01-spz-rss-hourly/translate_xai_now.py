#!/usr/bin/env python3
"""Translate untranslated SPZ feed articles to Hebrew using xAI API."""

import json
import os
import re
import html
import urllib.request
import time
import subprocess
from datetime import datetime
from pathlib import Path

FEEDS_DIR = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
SYNC_SCRIPT = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"
API_KEY = "xai-zesycAgCOo8Rm4FjlhnsYZhBmxswrp83RgDK7qAsGRiVZO9HEI2BKnMyglrCHVzBexXtf68OK7hkNGKs"
API_URL = "https://api.x.ai/v1/chat/completions"
MODEL = "grok-3"

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    text = text.replace('\n', ' ').strip()
    text = re.sub(r'\s+', ' ', text)
    return text[:400]

def translate_single(title, description):
    """Translate one article using xAI. Returns (hebrew_title, hebrew_desc) or (None, None)."""
    title_clean = clean_text(title)
    desc_clean = clean_text(description)
    
    prompt = f"""Translate this news article from English to Hebrew.

ENGLISH TITLE: {title_clean}
ENGLISH DESCRIPTION: {desc_clean}

Return EXACTLY two lines, nothing else:
HEBREW_TITLE: <Hebrew translation of the title>
HEBREW_DESC: <Hebrew translation of the description>

Rules:
- Use natural, modern Hebrew
- Keep proper names in common Hebrew transliteration
- Make the headline concise and impactful
- Output ONLY the two lines above"""
    
    payload = json.dumps({
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 256
    }).encode('utf-8')
    
    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {API_KEY}"},
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
        
        content = data['choices'][0]['message']['content'].strip()
        
        ht = hd = None
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("HEBREW_TITLE:"):
                ht = line[len("HEBREW_TITLE:"):].strip()
            elif line.startswith("HEBREW_DESC:"):
                hd = line[len("HEBREW_DESC:"):].strip()
        
        # Validate title has Hebrew characters
        if ht and any('\u0590' <= c <= '\u05FF' for c in ht):
            return ht, hd or ""
        return None, None
    except Exception as e:
        log(f"    xAI error: {str(e)[:120]}")
        return None, None

def process_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    posts = data.get("posts", [])
    untranslated = [p for p in posts if "title_hebrew" not in p or not p["title_hebrew"]]
    
    if not untranslated:
        log(f"{filepath.name}: all {len(posts)} already translated")
        return 0, 0
    
    log(f"{filepath.name}: {len(posts)} total, {len(untranslated)} to translate")
    ok = fail = 0
    
    for i, post in enumerate(untranslated, 1):
        title = post.get("title", "")
        desc = post.get("description", "")
        
        ht, hd = translate_single(title, desc)
        
        if ht:
            post["title_hebrew"] = ht
            post["description_hebrew"] = hd or ""
            ok += 1
            log(f"  [{i}/{len(untranslated)}] ✓ {ht[:70]}")
        else:
            fail += 1
            log(f"  [{i}/{len(untranslated)}] ✗ Failed: {str(title)[:60]}...")
        
        # Save every 5 articles
        if i % 5 == 0:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"  Progress saved: {ok}/{len(untranslated)} done")
        
        time.sleep(0.3)  # brief pause between requests
    
    # Final save
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    log(f"{filepath.name}: DONE. Translated {ok}, failed {fail}")
    return ok, len(untranslated)

def run_github_sync():
    if not os.path.exists(SYNC_SCRIPT):
        log(f"Sync script not found: {SYNC_SCRIPT}")
        return False
    log("Running GitHub sync...")
    try:
        r = subprocess.run(["python3", SYNC_SCRIPT], capture_output=True, text=True, timeout=300,
                           cwd=os.path.dirname(SYNC_SCRIPT))
        log(f"Sync exit code: {r.returncode}")
        for line in (r.stdout or "").strip().split("\n")[:20]:
            log(f"  sync-out: {line}")
        return r.returncode == 0
    except Exception as e:
        log(f"Sync failed: {e}")
        return False

def main():
    log("=" * 60)
    log("SPZ TRANSLATE (xAI) START")
    log("=" * 60)
    
    total_ok = total_n = 0
    files = [
        ("rss", os.path.join(FEEDS_DIR, "rss_feed.json")),
        ("reddit", os.path.join(FEEDS_DIR, "reddit_feed.json")),
        ("twitter", os.path.join(FEEDS_DIR, "twitter_feed.json")),
    ]
    
    for name, path in files:
        if not os.path.exists(path):
            log(f"{name}: not found, skipping")
            continue
        ok, n = process_file(Path(path))
        total_ok += ok
        total_n += n
    
    log("=" * 60)
    log(f"TOTAL TRANSLATED: {total_ok}/{total_n}")
    log("=" * 60)
    
    sync_ok = run_github_sync()
    log(f"GitHub sync: {'SUCCESS' if sync_ok else 'FAILED'}")
    log("ALL DONE")
    return total_ok

if __name__ == "__main__":
    main()
