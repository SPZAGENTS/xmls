#!/usr/bin/env python3
"""
SPZ Bulk Translate & Sync
Uses Google Translate (deep-translator) for fast free translation of all untranslated articles,
then runs the GitHub sync script.
"""
import json
import os
import sys
import time
import re
import html
from datetime import datetime
import subprocess
from deep_translator import GoogleTranslator

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
SYNC_SCRIPT = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    text = text.replace('\n', ' ').strip()
    text = re.sub(r'\s+', ' ', text)
    return text[:500]

def translate_single(translator, title, description):
    title_clean = clean_text(title)
    desc_clean = clean_text(description)
    try:
        ht = translator.translate(title_clean) if title_clean else ""
        hd = translator.translate(desc_clean) if desc_clean else ""
        if ht and any('\u0590' <= c <= '\u05FF' for c in ht):
            return ht, hd or ""
        return None, None
    except Exception as e:
        log(f"    Translate error: {str(e)[:120]}")
        return None, None

def process_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    posts = data.get("posts", [])
    untranslated = []
    for post in posts:
        th = post.get("title_hebrew", "")
        if not th or not any('\u0590' <= c <= '\u05FF' for c in str(th)):
            untranslated.append(post)

    if not untranslated:
        log(f"{os.path.basename(filepath)}: all {len(posts)} already translated")
        return 0, 0

    log(f"{os.path.basename(filepath)}: {len(posts)} total, {len(untranslated)} to translate")
    translator = GoogleTranslator(source='en', target='iw')
    ok = fail = 0

    for i, post in enumerate(untranslated, 1):
        title = post.get("title", "")
        desc = post.get("description", "")
        ht, hd = translate_single(translator, title, desc)

        if ht:
            post["title_hebrew"] = ht
            post["description_hebrew"] = hd or ""
            ok += 1
            log(f"  [{i}/{len(untranslated)}] OK: {ht[:80]}")
        else:
            fail += 1
            log(f"  [{i}/{len(untranslated)}] FAIL: {str(title)[:60]}...")

        # Save progress every 10 articles
        if i % 10 == 0:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"  Progress saved: {ok}/{len(untranslated)} done")

        time.sleep(0.2)  # small delay to be polite to the free API

    # Final save
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    log(f"{os.path.basename(filepath)}: DONE. Translated {ok}, failed {fail}")
    return ok, len(untranslated)

def run_github_sync():
    if not os.path.exists(SYNC_SCRIPT):
        log(f"Sync script not found: {SYNC_SCRIPT}")
        return False
    log("Running GitHub sync...")
    result = subprocess.run(
        [sys.executable, SYNC_SCRIPT],
        capture_output=True, text=True, timeout=300,
        cwd="/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly"
    )
    log(f"  Sync stdout: {result.stdout[:800]}")
    if result.stderr:
        log(f"  Sync stderr: {result.stderr[:800]}")
    log(f"  Sync return code: {result.returncode}")
    return result.returncode == 0

def main():
    log("=" * 60)
    log("SPZ Bulk Translate & Sync started")
    log("=" * 60)

    total_ok = total_fail = 0
    for fname in ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]:
        fp = os.path.join(FEEDS_DIR, fname)
        if os.path.exists(fp):
            ok, total = process_file(fp)
            total_ok += ok
            total_fail += (total - ok)
            time.sleep(1)
        else:
            log(f"{fname}: file not found")

    log(f"\nSummary: {total_ok} translated, {total_fail} failed")

    if total_ok > 0:
        success = run_github_sync()
        if success:
            log("GitHub sync completed successfully")
        else:
            log("GitHub sync failed")
    else:
        log("No translations made, skipping sync")

    log("=" * 60)
    log("SPZ Bulk Translate & Sync finished")
    log("=" * 60)

if __name__ == "__main__":
    main()
