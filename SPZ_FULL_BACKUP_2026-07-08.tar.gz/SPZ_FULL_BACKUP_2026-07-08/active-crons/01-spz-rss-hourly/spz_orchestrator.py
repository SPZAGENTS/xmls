# ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
# ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md
# 
# יש לקרוא את שני הקבצים לפני כל פעולה כדי להבין איך לבצע אותה בצורה הכי חכמה

#!/usr/bin/env python3
"""
SPZ Orchestrator v2.0 - Enhanced
Central Brain with SQLite State, Parallel Execution, Cross-Agent Deduplication

---
name: spz-orchestrator
description: SPZ News Aggregator - מערכת איסוף חדשות אוטונומית
prerequisites:
  - "קרא תחילה: ~/.openclaw/workspace/MASTER-INSIGHTS.md"
  - "בדוק אם יש תובנות שלמדנו שאפשר להשתמש בהם בפעולה שאני הולך לעשות"
version: "2.0.0"
author: Ben
---
"""

import json
import os
import subprocess
import sqlite3
import threading
import hashlib
from datetime import datetime, timedelta
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configuration
OUTPUT_DIR = "spz-feeds"
STATE_DB = "spz_state.db"

AGENTS = {
    "reddit": {
        "script": "spz-reddit-agent.py",
        "output": "reddit_feed.json",
        "weight": 1.0
    },
    "rss": {
        "script": "spz-rss-agent.py",
        "output": "rss_feed.json",
        "weight": 1.2
    },
    "twitter": {
        "script": "spz-twitter-agent.py",
        "output": "twitter_feed.json",
        "weight": 0.9
    }
}

BREAKING_KEYWORDS = ["breaking", "urgent", "update", "now", "just", "live"]

class EnhancedOrchestrator:
    def __init__(self):
        self.all_posts = []
        self.setup_database()
        self.load_seen_posts()
    
    def setup_database(self):
        """Initialize SQLite database for state persistence"""
        conn = sqlite3.connect(STATE_DB)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS seen_posts (
                url TEXT PRIMARY KEY,
                title_hash TEXT,
                title TEXT,
                source_agent TEXT,
                first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                count INTEGER DEFAULT 1
            )
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_title_hash ON seen_posts(title_hash)
        ''')
        
        conn.commit()
        conn.close()
        print("[DB] SQLite state database ready")
    
    def load_seen_posts(self):
        """Load previously seen URLs and hashes from database - only last 4 hours to allow fresh content"""
        self.seen_urls = set()
        self.seen_hashes = set()
        
        if not os.path.exists(STATE_DB):
            return
        
        conn = sqlite3.connect(STATE_DB)
        cursor = conn.cursor()
        
        # Load URLs from last 4 hours only (was 48 hours - too aggressive!)
        four_hours_ago = datetime.now() - timedelta(hours=4)
        cursor.execute(
            "SELECT url, title_hash FROM seen_posts WHERE first_seen > ?",
            (four_hours_ago,)
        )
        
        for row in cursor.fetchall():
            self.seen_urls.add(row[0])
            self.seen_hashes.add(row[1])
        
        conn.close()
        print(f"[DB] Loaded {len(self.seen_urls)} URLs from last 4 hours")
    
    def save_post_to_db(self, post):
        """Save post to database"""
        conn = sqlite3.connect(STATE_DB)
        cursor = conn.cursor()
        
        url = post.get('url', '')
        title = post.get('title', '')
        title_hash = hashlib.md5(title.lower().strip().encode()).hexdigest()
        source = post.get('source_agent', 'unknown')
        
        try:
            cursor.execute('''
                INSERT INTO seen_posts (url, title_hash, title, source_agent)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(url) DO UPDATE SET
                    count = count + 1,
                    first_seen = first_seen
            ''', (url, title_hash, title, source))
            conn.commit()
        except Exception as e:
            print(f"[WARNING] Failed to save post to DB: {e}")
        finally:
            conn.close()
    
    def run_agent(self, agent_name, config):
        """Run agent with retry logic"""
        max_retries = 3
        for attempt in range(max_retries):
            result = self._run_agent_once(agent_name, config)
            if result is not None:
                return result
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff
                print(f"[RETRY] Waiting {wait_time}s before retry {attempt + 2}/{max_retries}")
                import time
                time.sleep(wait_time)
        
        return None
    
    def _run_agent_once(self, agent_name, config):
        """Single attempt to run agent"""
        print(f"\n[ORCHESTRATOR] Starting {agent_name} agent...")
        
        try:
            script_path = config["script"]
            if not os.path.exists(script_path):
                print(f"[WARNING] {script_path} not found, creating placeholder")
                # Create placeholder
                with open(script_path, 'w') as f:
                    f.write(f'# Placeholder for {agent_name} agent\n')
                return None
            
            # Remove old output file to force fresh fetch
            output_path = os.path.join(OUTPUT_DIR, config["output"])
            if os.path.exists(output_path):
                os.remove(output_path)
                print(f"[INFO] Removed old output: {output_path}")
            
            # Use python3 from PATH (Linuxbrew version with user packages)
            python_cmd = "python3"
            
            result = subprocess.run(
                [python_cmd, script_path],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode != 0:
                print(f"[ERROR] {agent_name} failed: {result.stderr[:500]}")
                return None
            
            print(f"[OK] {agent_name} completed successfully")
            
            output_path = os.path.join(OUTPUT_DIR, config["output"])
            if os.path.exists(output_path):
                with open(output_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                print(f"[WARNING] {agent_name} output not found")
                return None
                
        except subprocess.TimeoutExpired:
            print(f"[ERROR] {agent_name} timed out after 5 minutes")
            return None
        except Exception as e:
            print(f"[ERROR] {agent_name} error: {e}")
            return None
    
    def run_all_agents_parallel(self):
        """Run all agents in parallel using threads"""
        print("="*60)
        print("SPZ ORCHESTRATOR v2.0 - Parallel Execution")
        print("="*60)
        
        results = {}
        completed = 0
        failed = 0
        
        with ThreadPoolExecutor(max_workers=3) as executor:
            # Submit all agents
            futures = {
                executor.submit(self.run_agent, name, config): name
                for name, config in AGENTS.items()
            }
            
            # Collect results as they complete
            for future in as_completed(futures):
                agent_name = futures[future]
                try:
                    result = future.result()
                    if result:
                        results[agent_name] = result
                        completed += 1
                    else:
                        failed += 1
                except Exception as e:
                    print(f"[ERROR] {agent_name} generated exception: {e}")
                    failed += 1
        
        print(f"\n[SUMMARY] Completed: {completed}/{len(AGENTS)}")
        if failed > 0:
            print(f"[SUMMARY] Failed: {failed}")
        
        return results
    
    def calculate_fuzzy_similarity(self, title1, title2):
        """Calculate Jaccard similarity between two titles"""
        set1 = set(title1.lower().split())
        set2 = set(title2.lower().split())
        
        intersection = len(set1 & set2)
        union = len(set1 | set2)
        
        return intersection / union if union > 0 else 0.0
    
    def deduplicate_with_fuzzy(self, posts, similarity_threshold=0.85):
        """Remove duplicates using exact URL + fuzzy title matching"""
        unique_posts = []
        title_list = []  # Keep track for fuzzy matching
        
        for post in posts:
            url = post.get("url", "")
            title = post.get("title", "").lower().strip()
            title_hash = hashlib.md5(title.encode()).hexdigest()
            
            # Check exact URL match (only skip if URL was seen in THIS run)
            if url in self.seen_urls:
                continue
            
            # Fuzzy matching with existing unique posts (same run only, not DB)
            is_duplicate = False
            for existing_title in title_list:
                similarity = self.calculate_fuzzy_similarity(title, existing_title)
                if similarity >= similarity_threshold:
                    is_duplicate = True
                    break
            
            if is_duplicate:
                continue
            
            self.seen_urls.add(url)
            self.seen_hashes.add(title_hash)
            title_list.append(title)
            unique_posts.append(post)
        
        return unique_posts
    
    def calculate_recency_score(self, post):
        """Calculate recency score (0-100)"""
        try:
            post_time_str = post.get("created_date", "")
            if not post_time_str:
                return 50
            
            post_time = datetime.fromisoformat(post_time_str.replace('Z', '+00:00'))
            age_hours = (datetime.now(timezone.utc) - post_time).total_seconds() / 3600
            
            if age_hours < 1:
                return 100
            elif age_hours < 6:
                return 80
            elif age_hours < 24:
                return 60
            elif age_hours < 48:
                return 40
            else:
                return max(0, 40 - (age_hours - 48) * 0.5)
        except:
            return 50
    
    def calculate_final_score(self, post, agent_weight=1.0):
        """Calculate final score combining importance and recency"""
        base_importance = post.get("importance", 50)
        recency_score = self.calculate_recency_score(post)
        
        # Proportional breaking boost
        title = post.get("title", "").lower()
        keywords_found = sum(1 for kw in BREAKING_KEYWORDS if kw in title)
        breaking_boost = min(25, keywords_found * 8)
        
        final_score = (
            (base_importance * 0.5) +
            (recency_score * 0.4) +
            breaking_boost
        ) * agent_weight
        
        return min(100, final_score)
    
    def aggregate_results(self, agent_results):
        """Combine all agent results, deduplicate, and score"""
        print("\n[ORCHESTRATOR] Aggregating results...")
        
        all_posts = []
        
        # Collect posts from all agents
        for agent_name, result in agent_results.items():
            agent_weight = AGENTS[agent_name]["weight"]
            posts = result.get("posts", [])
            
            print(f"[INFO] {agent_name}: {len(posts)} posts")
            
            for post in posts:
                post["source_agent"] = agent_name
                post["original_importance"] = post.get("importance", 50)
                post["final_score"] = self.calculate_final_score(post, agent_weight)
                # Preserve imageUrl if it exists
                if "imageUrl" not in post and "image" in post:
                    post["imageUrl"] = post["image"]
                all_posts.append(post)
        
        print(f"[INFO] Total posts before dedup: {len(all_posts)}")
        
        # Deduplicate
        unique_posts = self.deduplicate_with_fuzzy(all_posts)
        print(f"[INFO] Posts after dedup: {len(unique_posts)}")
        
        # Sort by final score
        unique_posts.sort(key=lambda x: x["final_score"], reverse=True)
        
        # Save to database
        for post in unique_posts:
            self.save_post_to_db(post)
        
        self.all_posts = unique_posts
        return unique_posts
    
    def generate_summary(self):
        """Generate feed summary statistics"""
        stats = {
            "total_posts": len(self.all_posts),
            "by_source": defaultdict(int),
            "by_score": defaultdict(int),
            "by_timeframe": {
                "last_hour": 0,
                "last_6h": 0,
                "last_24h": 0,
                "older": 0
            }
        }
        
        now = datetime.now(timezone.utc)
        
        for post in self.all_posts:
            # By source
            stats["by_source"][post.get("source_agent", "unknown")] += 1
            
            # By score
            score = post.get("final_score", 0)
            if score >= 80:
                stats["by_score"]["high"] += 1
            elif score >= 60:
                stats["by_score"]["medium"] += 1
            elif score >= 40:
                stats["by_score"]["low"] += 1
            else:
                stats["by_score"]["archive"] += 1
            
            # By timeframe
            try:
                post_time = datetime.fromisoformat(
                    post.get("created_date", "").replace('Z', '+00:00')
                )
                age_hours = (now - post_time).total_seconds() / 3600
                
                if age_hours < 1:
                    stats["by_timeframe"]["last_hour"] += 1
                elif age_hours < 6:
                    stats["by_timeframe"]["last_6h"] += 1
                elif age_hours < 24:
                    stats["by_timeframe"]["last_24h"] += 1
                else:
                    stats["by_timeframe"]["older"] += 1
            except:
                stats["by_timeframe"]["older"] += 1
        
        return stats
    
    def export_master_feed(self, filename="spz_master_feed.json"):
        """Export unified master feed"""
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        output_path = os.path.join(OUTPUT_DIR, filename)
        
        data = {
            "metadata": {
                "version": "2.0",
                "generated_at": datetime.now().isoformat(),
                "sources": list(AGENTS.keys()),
                "stats": self.generate_summary()
            },
            "posts": self.all_posts
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        return output_path
    
    def run(self):
        """Main execution flow"""
        print("\n" + "="*60)
        print("SPZ News Aggregator System")
        print("="*60)
        
        # Step 1: Run all agents in parallel
        agent_results = self.run_all_agents_parallel()
        
        if not agent_results:
            print("[ERROR] No agents completed successfully")
            return None
        
        # Step 2: Aggregate and deduplicate
        unique_posts = self.aggregate_results(agent_results)
        
        # Step 3: Export master feed
        output_path = self.export_master_feed()
        
        # Summary
        print("\n" + "="*60)
        print("[DONE] SPZ Orchestrator v2.0 completed")
        print(f"[DONE] Total unique posts: {len(unique_posts)}")
        print(f"[DONE] Output: {output_path}")
        print("="*60)
        
        return unique_posts

if __name__ == "__main__":
    from datetime import timezone
    orchestrator = EnhancedOrchestrator()
    orchestrator.run()
