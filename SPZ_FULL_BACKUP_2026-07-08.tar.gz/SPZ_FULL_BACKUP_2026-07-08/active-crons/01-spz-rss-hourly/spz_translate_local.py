#!/usr/bin/env python3
"""
SPZ Local Translator - מתרגם כתבות RSS לעברית
שיטה: מילון מילים לוקאלי + זיהוי מילים נפוצות
ללא תלות חיצונית - עובד offline
"""

import json
import re
import html
import os
import time

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
FEED_FILES = ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]
TRANSLATION_LOG = os.path.join(FEEDS_DIR, "translation_log_local.json")

# Local dictionary - common news terms
TRANSLATIONS = {
    # Countries
    "israel": "ישראל", "israeli": "ישראלי",
    "iran": "איראן", "iranian": "איראני",
    "gaza": "עזה", "palestine": "פלסטין", "palestinian": "פלסטיני",
    "jerusalem": "ירושלים", "tehran": "טהרן", "tel aviv": "תל אביב",
    "america": "אמריקה", "american": "אמריקאי",
    "pakistan": "פקיסטן",
    
    # Military
    "war": "מלחמה", "attack": "התקפה", "attacks": "התקפות",
    "missile": "טיל", "missiles": "טילים",
    "rocket": "רקטה", "rockets": "רקטות",
    "strike": "תקיפה", "strikes": "תקיפות",
    "bombing": "הפצצה", "idf": "צה\"ל", "iaf": "חיל האוויר",
    "military": "צבאי", "army": "צבא",
    "interception": "יירוט", "interceptions": "יירוטים",
    "airstrike": "תקיפה אווירית", "airstrikes": "תקיפות אוויריות",
    
    # Groups
    "hamas": "חמאס", "hezbollah": "חיזבאללה",
    
    # Actions
    "launches": "משגר", "launch": "שיגור",
    "hit": "פגיעה", "hits": "פוגע",
    "capture": "תיעוד", "captured": "תועד",
    
    # News terms
    "breaking news": "חדשות דחופות", "news": "חדשות",
    "alert": "התרעה", "watch": "צפו", "moment": "רגע",
    "footage": "תיעוד", "live": "שידור חי",
    
    # Places
    "high-rise": "גורד שחקים", "building": "בניין",
    "hospital": "בית חולים", "school": "בית ספר",
    "mosque": "מסגד", "church": "כנסייה",
    
    # People/Actions
    "killed": "נהרג", "dead": "הרוג",
    "injured": "פצוע", "wounded": "פצוע",
    "destroyed": "הושמד", "damage": "נזק",
    
    # Common
    "today": "היום", "yesterday": "אתמול",
    "report": "דיווח", "reports": "דיווחים",
    "source": "מקור", "official": "רשמי",
    "government": "ממשלה", "minister": "שר",
    "president": "נשיא", "prime minister": "ראש ממשלה",
    
    # Regions
    "middle east": "המזרח התיכון",
    "west bank": "הגדה המערבית",
    "gaza strip": "רצועת עזה",
    "lebanon": "לבנון", "syria": "סוריה",
    "jordan": "ירדן", "egypt": "מצרים",
    "iraq": "עיראק", "turkey": "טורקיה",
    "yemen": "תימן", "saudi arabia": "ערב הסעודית",
    
    # Misc
    "video": "סרטון", "photo": "תמונה",
    "update": "עדכון", "developing": "מתפתח",
    "confirmed": "מאושר", "unconfirmed": "לא מאושר",
    "casualties": "נפגעים", "civilian": "אזרחי",
}

def translate_text_local(text):
    """מתרגם טקסט באמצעות מילון מקומי"""
    if not text:
        return ""
    
    # Clean HTML
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    text = text.strip()
    
    if not text:
        return ""
    
    # Already Hebrew?
    if any('\u0590' <= c <= '\u05FF' for c in text):
        return text
    
    result = text
    translated_words = []
    
    # Sort by length (longest first) to handle phrases
    for eng, heb in sorted(TRANSLATIONS.items(), key=lambda x: -len(x[0])):
        if eng in result.lower():
            # Case-insensitive replace
            pattern = re.compile(re.escape(eng), re.IGNORECASE)
            result = pattern.sub(heb, result)
            translated_words.append(eng)
    
    # If nothing translated, return original with marker
    if not translated_words:
        return text + " [EN]"
    
    # Add translation note
    result = result + "\n[תרגום חלקי: " + ", ".join(translated_words[:5]) + "]"
    
    return result

def load_log():
    if os.path.exists(TRANSLATION_LOG):
        try:
            with open(TRANSLATION_LOG, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_log(log):
    with open(TRANSLATION_LOG, 'w', encoding='utf-8') as f:
        json.dump(log, f, ensure_ascii=False, indent=2)

def process_feed(feed_file, log):
    filepath = os.path.join(FEEDS_DIR, feed_file)
    if not os.path.exists(filepath):
        return 0, 0
    
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    if 'posts' not in data:
        return 0, 0
    
    posts = data['posts']
    translated = 0
    skipped = 0
    
    print(f"Processing {len(posts)} posts from {feed_file}...")
    
    for i, post in enumerate(posts):
        post_id = post.get('url', '') or str(i)
        
        if post_id in log:
            skipped += 1
            continue
        
        title = post.get('title', '')
        desc = post.get('description', '')
        
        # Translate
        title_he = translate_text_local(title)
        desc_he = translate_text_local(desc)
        
        post['title_hebrew'] = title_he
        post['description_hebrew'] = desc_he
        
        log[post_id] = {
            'title_hebrew': title_he,
            'description_hebrew': desc_he,
            'time': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        translated += 1
        
        if i < 3:  # Show first 3
            print(f"  [{i+1}] {title[:60]}")
            print(f"       → {title_he[:60]}")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print(f"Done: {translated} translated, {skipped} skipped")
    return translated, skipped

def main():
    print("=" * 60)
    print("SPZ LOCAL Translator - Offline Dictionary Mode")
    print(f"Dictionary size: {len(TRANSLATIONS)} terms")
    print("=" * 60)
    
    log = load_log()
    print(f"Cache: {len(log)} items\n")
    
    total_t = 0
    total_s = 0
    
    for feed in FEED_FILES:
        print(f"\nProcessing: {feed}")
        t, s = process_feed(feed, log)
        total_t += t
        total_s += s
    
    save_log(log)
    
    print(f"\nTotal: {total_t} translated, {total_s} skipped")
    print("=" * 60)

if __name__ == "__main__":
    main()
