#!/bin/bash
# SPZ Hourly Pipeline - RSS + Reddit + Translation + GitHub Sync
# v3.0 - מתקן בעיית תרגום
set -euo pipefail

WORKSPACE="/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly"
LOG_FILE="$WORKSPACE/logs/spz_cron.log"
MAIN_FEEDS="/home/yosia/.openclaw/workspace/spz-feeds"

# Config
MAX_TRANSLATIONS_PER_RUN=30

echo "========================================" >> "$LOG_FILE"
echo "SPZ Hourly Run v3.0 - $(date)" >> "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"

if [ -f "$WORKSPACE/.env" ]; then
    source "$WORKSPACE/.env"
fi

cd "$WORKSPACE"

# Step 0: העתקת translation_log מהספרייה הראשית ל-workspace
if [ -f "$MAIN_FEEDS/translation_log.json" ]; then
    cp "$MAIN_FEEDS/translation_log.json" "$WORKSPACE/spz-feeds/translation_log.json"
    echo "[$(date)] Copied translation cache from main directory" >> "$LOG_FILE"
fi

# Step 1: איסוף (כותב ל- spz-feeds/ בתוך ספריית ה-cron)
echo "[$(date)] Step 1: Collecting articles..." >> "$LOG_FILE"
python3 "$WORKSPACE/spz_orchestrator.py" >> "$LOG_FILE" 2>&1
if [ $? -ne 0 ]; then
    echo "[$(date)] ❌ Collection failed" >> "$LOG_FILE"
    exit 1
fi
echo "[$(date)] ✅ Collection done" >> "$LOG_FILE"

# Step 1.5: העתקת הקבצים המאוגדים לספרייה הראשית (כולל master)
echo "[$(date)] Step 1.5: Copying feeds to main directory..." >> "$LOG_FILE"
cp "$WORKSPACE/spz-feeds/rss_feed.json" "$MAIN_FEEDS/rss_feed.json"
cp "$WORKSPACE/spz-feeds/reddit_feed.json" "$MAIN_FEEDS/reddit_feed.json" 2>/dev/null
cp "$WORKSPACE/spz-feeds/spz_master_feed.json" "$MAIN_FEEDS/spz_master_feed.json"
echo "[$(date)] ✅ Feeds copied to main directory" >> "$LOG_FILE"

# Step 2: תרגום חכם (עובד על הספרייה הראשית)
echo "[$(date)] Step 2: Translating new articles to Hebrew..." >> "$LOG_FILE"
cd "$MAIN_FEEDS"
python3 "$WORKSPACE/spz_translate.py" >> "$LOG_FILE" 2>&1
if [ $? -ne 0 ]; then
    echo "[$(date)] ⚠️ Translation had warnings" >> "$LOG_FILE"
fi
echo "[$(date)] ✅ Translation done" >> "$LOG_FILE"

# Step 2.5: העתקת הקבצים המתורגמים חזרה ל-workspace
cp "$MAIN_FEEDS/rss_feed.json" "$WORKSPACE/spz-feeds/rss_feed.json"
cp "$MAIN_FEEDS/reddit_feed.json" "$WORKSPACE/spz-feeds/reddit_feed.json" 2>/dev/null
cp "$MAIN_FEEDS/spz_master_feed.json" "$WORKSPACE/spz-feeds/spz_master_feed.json"
echo "[$(date)] ✅ Translated feeds copied back" >> "$LOG_FILE"

# Step 3: סינכרון לגיטהאב
echo "[$(date)] Step 3: Syncing to GitHub..." >> "$LOG_FILE"
cd "$WORKSPACE"
python3 "$WORKSPACE/spz_github_sync.py" >> "$LOG_FILE" 2>&1
echo "[$(date)] ✅ GitHub sync done" >> "$LOG_FILE"

echo "[$(date)] All complete!" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
