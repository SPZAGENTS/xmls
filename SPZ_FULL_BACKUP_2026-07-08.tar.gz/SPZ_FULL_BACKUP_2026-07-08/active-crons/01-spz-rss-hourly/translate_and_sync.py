#!/usr/bin/env python3
"""
Translation script for SPZ feeds.
Translates all untranslated articles to Hebrew using deep_translator.
Logs all actions to translation.log
"""

import json
import os
import sys
from datetime import datetime
from deep_translator import GoogleTranslator

# Paths
FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = os.path.join(FEEDS_DIR, "translation.log")
FEEDS = {
    "rss": os.path.join(FEEDS_DIR, "rss_feed.json"),
    "reddit": os.path.join(FEEDS_DIR, "reddit_feed.json"),
    "twitter": os.path.join(FEEDS_DIR, "twitter_feed.json"),
}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log(f"ERROR loading {path}: {e}")
        return None

def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        log(f"ERROR saving {path}: {e}")
        return False

def clean_text(text):
    """Strip HTML tags and normalize whitespace."""
    if not text:
        return ""
    import re
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'&#[0-9]+;', '', text)
    text = re.sub(r'&\w+;', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def translate_text(text, translator, max_len=4000):
    """Translate text, truncating if too long."""
    if not text or not text.strip():
        return ""
    text = text[:max_len]
    try:
        return translator.translate(text)
    except Exception as e:
        return f"[TRANSLATION_ERROR: {e}]"

def process_feed(name, path, translator):
    data = load_json(path)
    if data is None:
        log(f"SKIPPED {name}: could not load")
        return 0, 0

    posts = []
    if isinstance(data, list):
        posts = data
    elif isinstance(data, dict):
        if "posts" in data:
            posts = data["posts"]
        else:
            posts = [data]
    else:
        log(f"SKIPPED {name}: unrecognized structure")
        return 0, 0

    translated_count = 0
    skipped_count = 0

    for idx, post in enumerate(posts):
        if not isinstance(post, dict):
            continue

        # Check if already translated
        if post.get("title_hebrew") and post.get("description_hebrew"):
            skipped_count += 1
            continue

        title = clean_text(post.get("title", ""))
        desc = clean_text(post.get("description", ""))

        log(f"TRANSLATING {name}[{idx}] | title_len={len(title)} desc_len={len(desc)}")

        title_he = translate_text(title, translator)
        desc_he = translate_text(desc, translator)

        post["title_hebrew"] = title_he
        post["description_hebrew"] = desc_he
        translated_count += 1

        log(f"  -> title_he={title_he[:80]}...")

    # Save back
    if translated_count > 0:
        if isinstance(data, list):
            save_json(path, posts)
        elif isinstance(data, dict):
            if "posts" in data:
                data["posts"] = posts
            save_json(path, data)

    log(f"DONE {name}: translated={translated_count}, already_translated={skipped_count}, total={len(posts)}")
    return translated_count, skipped_count

def main():
    # Initialize log
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n{'='*60}\n")
        f.write(f"TRANSLATION RUN STARTED: {datetime.now().isoformat()}\n")
        f.write(f"{'='*60}\n")

    translator = GoogleTranslator(source='auto', target='iw')

    total_translated = 0
    total_skipped = 0

    for name, path in FEEDS.items():
        if not os.path.exists(path):
            log(f"MISSING {name}: {path}")
            continue
        t, s = process_feed(name, path, translator)
        total_translated += t
        total_skipped += s

    log(f"FINAL: total_translated={total_translated}, total_skipped={total_skipped}")

    # Run GitHub sync
    sync_script = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"
    if os.path.exists(sync_script):
        log("RUNNING GitHub sync script...")
        import subprocess
        result = subprocess.run(
            [sys.executable, sync_script],
            capture_output=True, text=True, cwd=os.path.dirname(sync_script)
        )
        log(f"SYNC stdout: {result.stdout[:500]}")
        if result.stderr:
            log(f"SYNC stderr: {result.stderr[:500]}")
        log(f"SYNC returncode: {result.returncode}")
    else:
        log(f"MISSING sync script: {sync_script}")

    log("RUN COMPLETE")
    return 0

if __name__ == "__main__":
    sys.exit(main())
