#!/usr/bin/env python3
"""
SPZ Translate & Sync - Local Ollama version
Translates untranslated articles to Hebrew using local llama3.1, then runs GitHub sync.
"""

import json
import os
import sys
import time
import re
import html
from datetime import datetime
import subprocess
import urllib.request
import urllib.error

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
LOG_FILE = "/home/yosia/.openclaw/workspace/spz-feeds/translation.log"
SYNC_SCRIPT = "/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly/spz_github_sync.py"
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.1:8b"

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    text = text.replace('\n', ' ').strip()
    text = re.sub(r'\s+', ' ', text)
    return text[:600]

def translate_single(title, description):
    """Translate one article using local Ollama."""
    title_clean = clean_text(title)
    desc_clean = clean_text(description)

    prompt = f"""Translate this English news to Hebrew. Return exactly two lines:
HEBREW_TITLE: <Hebrew title>
HEBREW_DESC: <Hebrew description>

English Title: {title_clean}
English Description: {desc_clean}"""

    payload = json.dumps({
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.2, "num_predict": 400}
    }).encode('utf-8')

    req = urllib.request.Request(OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"}, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode())
        content = data.get('response', '').strip()

        ht = hd = ""
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("HEBREW_TITLE:"):
                ht = line[len("HEBREW_TITLE:"):].strip()
                # Remove quotes if present
                if ht.startswith('"') and ht.endswith('"'):
                    ht = ht[1:-1]
                if ht.startswith("'") and ht.endswith("'"):
                    ht = ht[1:-1]
            elif line.startswith("HEBREW_DESC:"):
                hd = line[len("HEBREW_DESC:"):].strip()
                if hd.startswith('"') and hd.endswith('"'):
                    hd = hd[1:-1]
                if hd.startswith("'") and hd.endswith("'"):
                    hd = hd[1:-1]

        if ht and any('\u0590' <= c <= '\u05FF' for c in ht):
            return ht, hd
        return None, None
    except Exception as e:
        log(f"    Ollama error: {str(e)[:120]}")
        return None, None

def process_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    posts = data.get("posts", [])
    # Find posts that need translation
    untranslated = []
    for post in posts:
        th = post.get("title_hebrew", "")
        if not th or not any('\u0590' <= c <= '\u05FF' for c in str(th)):
            untranslated.append(post)

    if not untranslated:
        log(f"{os.path.basename(filepath)}: all {len(posts)} already translated")
        return 0, 0

    log(f"{os.path.basename(filepath)}: {len(posts)} total, {len(untranslated)} to translate")
    ok = fail = 0

    for i, post in enumerate(untranslated, 1):
        title = post.get("title", "")
        desc = post.get("description", "")

        ht, hd = translate_single(title, desc)

        if ht:
            post["title_hebrew"] = ht
            post["description_hebrew"] = hd or ""
            ok += 1
            log(f"  [{i}/{len(untranslated)}] OK {ht[:70]}")
        else:
            fail += 1
            log(f"  [{i}/{len(untranslated)}] FAIL {str(title)[:60]}...")

        # Save progress every 5 articles
        if i % 5 == 0:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"  Progress saved: {ok}/{len(untranslated)} done")

        time.sleep(0.5)

    # Final save
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    log(f"{os.path.basename(filepath)}: DONE. Translated {ok}, failed {fail}")
    return ok, len(untranslated)

def run_github_sync():
    if not os.path.exists(SYNC_SCRIPT):
        log(f"Sync script not found: {SYNC_SCRIPT}")
        return False
    log("Running GitHub sync...")
    result = subprocess.run(
        [sys.executable, SYNC_SCRIPT],
        capture_output=True, text=True, timeout=300,
        cwd="/home/yosia/.openclaw/workspace/active-crons/01-spz-rss-hourly"
    )
    log(f"  Sync stdout: {result.stdout[:500]}")
    if result.stderr:
        log(f"  Sync stderr: {result.stderr[:500]}")
    log(f"  Sync return code: {result.returncode}")
    return result.returncode == 0

def main():
    log("=" * 60)
    log("SPZ Translate & Sync (Local Ollama) started")
    log("=" * 60)
    log(f"FEEDS_DIR: {FEEDS_DIR}, MODEL: {MODEL}")

    total_ok = total_fail = 0
    for fname in ["rss_feed.json", "reddit_feed.json", "twitter_feed.json"]:
        fp = os.path.join(FEEDS_DIR, fname)
        if os.path.exists(fp):
            ok, total = process_file(fp)
            total_ok += ok
            total_fail += (total - ok)
            time.sleep(1)
        else:
            log(f"{fname}: file not found")

    log(f"\nSummary: {total_ok} translated, {total_fail} failed")

    if total_ok > 0:
        success = run_github_sync()
        if success:
            log("GitHub sync completed successfully")
        else:
            log("GitHub sync failed")
    else:
        log("No translations made, skipping sync")

    log("=" * 60)
    log("SPZ Translate & Sync (Local Ollama) finished")
    log("=" * 60)

if __name__ == "__main__":
    main()
