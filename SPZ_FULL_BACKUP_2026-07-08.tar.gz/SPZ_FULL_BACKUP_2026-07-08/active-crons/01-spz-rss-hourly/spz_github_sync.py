#!/usr/bin/env python3
"""
SPZ GitHub Sync v2.1
Reads master feed and pushes updates to GitHub with fixed file names
Max 10 articles per XML file
"""

import subprocess
import json
import os
import re
from datetime import datetime

REPO_DIR = "/home/yosia/.openclaw/workspace/spz-repo"
GITHUB_REPO = "https://github.com/SPZAGENTS/xmls.git"
FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"

# Target files to update (exactly as specified)
TARGET_FILES = {
    'abc_news_international.xml',
    'arutz-sheva-all.xml',
    'bbc_world.xml',
    'cbc_world.xml',
    'fox_news_world.xml',
    'france24.xml',
    'geektime-all.xml',
    'guardian_world.xml',
    'ICE-all.xml',
    'international-master.xml',
    'international-war.xml',
    'israel-hayom-all.xml',
    'npr_world.xml',
    'nyt_world.xml',
    'politico.xml',
    'reddit-aggregate.xml',
    'reddit-conflict-war.xml',
    'reddit-global-news.xml',
    'reddit-israel-jewish.xml',
    'reddit-middle-east.xml',
    'reddit-military-analysis.xml',
    'reddit-war.xml',
    'times-of-israel-all.xml',
    'walla-all.xml',
    'washington_post.xml',
    'ynet-all.xml',
    'zman-israel-all.xml',
}

# Mapping of source names to XML file names
SOURCE_TO_FILE = {
    # Israeli sources
    'Jerusalem Post': 'times-of-israel-all.xml',
    'Times of Israel': 'times-of-israel-all.xml',
    'Ynet': 'ynet-all.xml',
    'ynet-breaking-news': 'ynet-all.xml',
    'ynet-main-news': 'ynet-all.xml',
    'ynet-culture': 'ynet-all.xml',
    'ynet-economy': 'ynet-all.xml',
    'ynet-health': 'ynet-all.xml',
    'ynet-opinions': 'ynet-all.xml',
    'ynet-sports': 'ynet-all.xml',
    'ynet-technology': 'ynet-all.xml',
    'ynet-news-english': 'ynet-all.xml',
    'Walla': 'walla-all.xml',
    'Israel Hayom': 'israel-hayom-all.xml',
    'Maariv': 'arutz-sheva-all.xml',
    'Arutz Sheva': 'arutz-sheva-all.xml',
    'Srugim': 'arutz-sheva-all.xml',
    'Zman Israel': 'zman-israel-all.xml',
    'Haaretz': 'times-of-israel-all.xml',
    'Geektime': 'geektime-all.xml',
    'גיקטיים': 'geektime-all.xml',
    'היום': 'israel-hayom-all.xml',
    'וואלה': 'walla-all.xml',
    'זמן-ישראל': 'zman-israel-all.xml',
    'סרוגים': 'arutz-sheva-all.xml',
    
    # International sources
    'BBC World': 'bbc_world.xml',
    'BBC News': 'bbc_world.xml',
    'BBC UK': 'bbc_world.xml',
    'BBC Middle East': 'bbc_world.xml',
    'France24': 'france24.xml',
    'France24 Middle East': 'france24.xml',
    'The Guardian': 'guardian_world.xml',
    'Guardian World': 'guardian_world.xml',
    'NYT World': 'nyt_world.xml',
    'NYT Middle East': 'nyt_world.xml',
    'NYT Homepage': 'nyt_world.xml',
    'Washington Post': 'washington_post.xml',
    'Washington Post Politics': 'washington_post.xml',
    'NPR World': 'npr_world.xml',
    'ABC News': 'abc_news_international.xml',
    'ABC News International': 'abc_news_international.xml',
    'Fox News': 'fox_news_world.xml',
    'Fox News World': 'fox_news_world.xml',
    'NBC News': 'npr_world.xml',
    'Politico': 'politico.xml',
    'CBC World': 'cbc_world.xml',
    'Reuters': 'guardian_world.xml',
    
    # Reddit sources
    'reddit-israel': 'reddit-israel-jewish.xml',
    'reddit-judaism': 'reddit-israel-jewish.xml',
    'reddit-jewish': 'reddit-israel-jewish.xml',
    'reddit-zionism': 'reddit-israel-jewish.xml',
    'reddit-worldnews': 'reddit-global-news.xml',
    'reddit-middleeast': 'reddit-middle-east.xml',
    'reddit-geopolitics': 'reddit-conflict-war.xml',
    'reddit-news': 'reddit-global-news.xml',
    'reddit-israel-palestine': 'reddit-war.xml',
    'reddit-military': 'reddit-military-analysis.xml',
    'reddit-aggregate': 'reddit-aggregate.xml',
    'reddit-conflict-war': 'reddit-conflict-war.xml',
    'reddit-global-news': 'reddit-global-news.xml',
    'reddit-israel-jewish': 'reddit-israel-jewish.xml',
    'reddit-middle-east': 'reddit-middle-east.xml',
    'reddit-military-analysis': 'reddit-military-analysis.xml',
    'reddit-war': 'reddit-war.xml',
    
    # Twitter sources
    'twitter-articles-scored': 'twitter-articles-scored.xml',
    'twitter-grok-feed': 'twitter-grok-feed.xml',
}

# Sources that should be grouped into special files
REDDIT_WAR_SOURCES = [
    'reddit-geopolitics', 'reddit-military', 'reddit-worldnews'
]

REDDIT_NEWS_SOURCES = [
    'reddit-worldnews', 'reddit-news', 'reddit-global-news'
]

MAX_ARTICLES = 10

def clone_or_pull_repo():
    """Clone or pull the repo"""
    try:
        if os.path.exists(REPO_DIR):
            subprocess.run(
                ['git', '-C', REPO_DIR, 'pull', 'origin', 'main'],
                capture_output=True, timeout=60
            )
        else:
            os.makedirs(os.path.dirname(REPO_DIR), exist_ok=True)
            subprocess.run(
                ['git', 'clone', GITHUB_REPO, REPO_DIR],
                capture_output=True, timeout=120
            )
        return True
    except Exception as e:
        print(f"Git error: {e}")
        return False

def read_master_feed():
    """Read all feeds and merge, preferring posts with images"""
    master_file = os.path.join(FEEDS_DIR, "spz_master_feed.json")
    rss_file = os.path.join(FEEDS_DIR, "rss_feed.json")
    reddit_file = os.path.join(FEEDS_DIR, "reddit_feed.json")
    twitter_file = os.path.join(FEEDS_DIR, "twitter-grok-feed.json")
    
    post_by_url = {}
    
    # Read feeds - RSS first so translated posts win!
    # Order matters: rss (has Hebrew translation) first, then others
    feed_files = [rss_file, master_file, reddit_file, twitter_file]
    
    for feed_file in feed_files:
        if not os.path.exists(feed_file):
            continue
        
        try:
            with open(feed_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, dict):
                posts = data.get('posts', data.get('entries', []))
            elif isinstance(data, list):
                posts = data
            else:
                posts = []
            
            # Determine source from filename for feeds without source field
            file_source = None
            if 'twitter' in feed_file:
                file_source = 'twitter-grok-feed'
            elif 'reddit' in feed_file:
                file_source = 'reddit-aggregate'
            elif 'rss' in feed_file:
                file_source = None  # RSS has its own source field
            elif 'master' in feed_file:
                file_source = None
            
            for p in posts:
                # Add source if missing
                if not p.get('source') and file_source:
                    p['source'] = file_source
                
                # Twitter posts use 'username' instead of 'source'
                if 'twitter' in feed_file and not p.get('source'):
                    p['source'] = 'twitter-grok-feed'
                
                url = p.get('url', '')
                if not url:
                    url = p.get('link', '')
                if not url:
                    continue
                
                # When updating existing post, preserve Hebrew translation fields
                if url not in post_by_url:
                    post_by_url[url] = p
                else:
                    existing = post_by_url[url]
                    # Preserve Hebrew translation fields from RSS/Reddit
                    if p.get('title_hebrew'):
                        existing['title_hebrew'] = p['title_hebrew']
                    if p.get('description_hebrew'):
                        existing['description_hebrew'] = p['description_hebrew']
                    if p.get('hebrew_translation'):
                        existing['hebrew_translation'] = p['hebrew_translation']
                    
                    # Update imageUrl only if new post has one and existing doesn't
                    if p.get('imageUrl') and not existing.get('imageUrl'):
                        existing['imageUrl'] = p['imageUrl']
            
            print(f"[INFO] Loaded {len(posts)} posts from {os.path.basename(feed_file)}")
        except Exception as e:
            print(f"[WARNING] Error reading {feed_file}: {e}")
    
    all_posts = list(post_by_url.values())
    print(f"[INFO] Total unique posts: {len(all_posts)}")
    return all_posts

def get_target_file(source):
    """Map source name to target XML file"""
    # Direct mapping
    if source in SOURCE_TO_FILE:
        return SOURCE_TO_FILE[source]
    
    # Try with spaces replaced
    source_normalized = source.lower().replace(' ', '-').replace('_', '-')
    for key, value in SOURCE_TO_FILE.items():
        key_normalized = key.lower().replace(' ', '-').replace('_', '-')
        if source_normalized == key_normalized:
            return value
    
    return None

def update_xml_files(articles):
    """Update XML files in repo with new articles"""
    # Group articles by target XML file
    by_file = {}
    skipped = 0
    
    for article in articles:
        source = article.get('source', 'unknown')
        target_file = get_target_file(source)
        
        if not target_file or target_file not in TARGET_FILES:
            skipped += 1
            continue
        
        if target_file not in by_file:
            by_file[target_file] = []
        
        by_file[target_file].append(article)
    
    print(f"[INFO] Skipped {skipped} articles (no matching target file)")
    
    # Build special aggregate files
    build_reddit_aggregate(by_file, articles)
    build_reddit_war(by_file, articles)
    build_international_master(by_file, articles)
    build_international_war(by_file, articles)
    build_twitter_aggregate(by_file, articles)
    
    updated = []
    for target_file, file_articles in by_file.items():
        if target_file not in TARGET_FILES:
            continue
        
        # Sort by importance/score and take top 10
        file_articles.sort(key=lambda x: x.get('final_score', x.get('importance', 50)), reverse=True)
        top_articles = file_articles[:MAX_ARTICLES]
        
        # Build XML content
        xml_content = build_xml(target_file.replace('.xml', ''), top_articles)
        
        xml_file = os.path.join(REPO_DIR, target_file)
        with open(xml_file, 'w', encoding='utf-8') as f:
            f.write(xml_content)
        
        updated.append(target_file)
        print(f"  Updated: {target_file} ({len(top_articles)} articles)")
    
    return updated

def build_reddit_aggregate(by_file, all_articles):
    """Build reddit-aggregate.xml from all reddit sources"""
    reddit_articles = [a for a in all_articles if a.get('source', '').startswith('reddit')]
    reddit_articles.sort(key=lambda x: x.get('final_score', x.get('importance', 50)), reverse=True)
    
    by_file['reddit-aggregate.xml'] = reddit_articles[:MAX_ARTICLES]

def build_international_master(by_file, all_articles):
    """Build international-master.xml from all international sources"""
    intl_sources = {
        'BBC World', 'BBC News', 'BBC UK', 'BBC Middle East',
        'France24', 'France24 Middle East',
        'The Guardian', 'Guardian World',
        'NYT World', 'NYT Middle East', 'NYT Homepage',
        'Washington Post', 'Washington Post Politics',
        'NPR World', 'ABC News', 'ABC News International',
        'Fox News', 'Fox News World', 'NBC News',
        'Politico', 'CBC World', 'Reuters'
    }
    
    intl_articles = [a for a in all_articles if a.get('source') in intl_sources]
    intl_articles.sort(key=lambda x: x.get('final_score', x.get('importance', 50)), reverse=True)
    
    by_file['international-master.xml'] = intl_articles[:MAX_ARTICLES]

def build_international_war(by_file, all_articles):
    """Build international-war.xml from conflict-related sources"""
    war_keywords = ['war', 'conflict', 'military', 'attack', 'strike', 'bomb', 'missile',
                    'hamas', 'hezbollah', 'gaza', 'lebanon', 'iran', 'idf', 'defense']
    
    intl_sources = {
        'BBC World', 'BBC News', 'BBC UK', 'BBC Middle East',
        'France24', 'France24 Middle East',
        'The Guardian', 'Guardian World',
        'NYT World', 'NYT Middle East', 'NYT Homepage',
        'Washington Post', 'Washington Post Politics',
        'NPR World', 'ABC News', 'ABC News International',
        'Fox News', 'Fox News World', 'NBC News',
        'Politico', 'CBC World', 'Reuters'
    }
    
    war_articles = []
    for a in all_articles:
        if a.get('source') not in intl_sources:
            continue
        title = a.get('title', '').lower()
        if any(kw in title for kw in war_keywords):
            war_articles.append(a)
    
    war_articles.sort(key=lambda x: x.get('final_score', x.get('importance', 50)), reverse=True)
    by_file['international-war.xml'] = war_articles[:MAX_ARTICLES]

def build_reddit_war(by_file, all_articles):
    """Build reddit-war.xml from Reddit sources with images"""
    reddit_war_sources = {
        'reddit-geopolitics', 'reddit-military', 'reddit-worldnews',
        'reddit-conflict-war', 'reddit-israel-palestine'
    }
    
    war_keywords = ['war', 'conflict', 'military', 'attack', 'strike', 'bomb', 'missile',
                    'hamas', 'hezbollah', 'gaza', 'lebanon', 'iran', 'idf', 'defense']
    
    war_articles = []
    for a in all_articles:
        if a.get('source') not in reddit_war_sources:
            continue
        title = a.get('title', '').lower()
        if any(kw in title for kw in war_keywords):
            war_articles.append(a)
    
    # Sort by: has image first, then date, then score
    def sort_key(x):
        has_img = 1 if x.get('imageUrl') else 0
        return (has_img, x.get('final_score', x.get('importance', 50)))
    
    war_articles.sort(key=sort_key, reverse=True)
    by_file['reddit-war.xml'] = war_articles[:MAX_ARTICLES]

def build_twitter_aggregate(by_file, all_articles):
    """Build twitter-articles-scored.xml and twitter-grok-feed.xml"""
    twitter_articles = [a for a in all_articles if a.get('source', '').startswith('twitter')]
    twitter_articles.sort(key=lambda x: x.get('final_score', x.get('importance', 50)), reverse=True)
    
    by_file['twitter-articles-scored.xml'] = twitter_articles[:MAX_ARTICLES]
    by_file['twitter-grok-feed.xml'] = twitter_articles[:MAX_ARTICLES]

def build_xml(source, articles):
    """Build RSS XML from articles"""
    now = datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')
    
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    xml += '<rss version="2.0">\n'
    xml += '  <channel>\n'
    xml += f'    <title>{escape_xml(source.title().replace("-", " "))} - Top Stories</title>\n'
    xml += f'    <lastBuildDate>{now}</lastBuildDate>\n'
    xml += '    <description>SPZ News Aggregator</description>\n'
    
    for article in articles:
        # Use Hebrew translation if available, otherwise fallback to English
        # Support both title_hebrew (RSS/Reddit) and hebrew_translation (Twitter)
        title = escape_xml(article.get('title_hebrew', article.get('hebrew_translation', article.get('title', article.get('text', 'No Title')))))
        link = article.get('url', article.get('link', ''))
        # Use Hebrew translation if available, with language validation
        # For Twitter/Grok, hebrew_translation is reliable; description_hebrew may be English
        desc_text = article.get('hebrew_translation', '')
        if not desc_text or not any('\u0590' <= c <= '\u05FF' for c in str(desc_text)):
            desc_text = article.get('description_hebrew', '')
        if not desc_text or not any('\u0590' <= c <= '\u05FF' for c in str(desc_text)):
            desc_text = article.get('description', article.get('summary', article.get('text', '')))
        desc = escape_xml(desc_text)
        pub_date = article.get('created_date', article.get('date', now))
        importance = article.get('importance', article.get('relevance_score', 50))
        
        # Try to get imageUrl from article
        image_url = article.get('imageUrl', '')
        if not image_url:
            # Try media_urls (Twitter format)
            media_urls = article.get('media_urls', [])
            if isinstance(media_urls, list) and media_urls:
                image_url = media_urls[0]
            if not image_url:
                # Try to extract from description
                raw_desc = article.get('description', '') or ''
                match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', raw_desc)
                if match:
                    image_url = match.group(1)
        
        xml += '    <item>\n'
        xml += f'      <title>{title}</title>\n'
        xml += f'      <link>{escape_xml(link)}</link>\n'
        xml += f'      <description>{desc}</description>\n'
        # Always add imageUrl tag, even if empty (for consistent XML structure)
        if image_url:
            xml += f'      <imageUrl>{escape_xml(image_url)}</imageUrl>\n'
        else:
            xml += '      <imageUrl></imageUrl>\n'
        xml += f'      <pubDate>{pub_date}</pubDate>\n'
        xml += f'      <importance>{importance}</importance>\n'
        xml += '    </item>\n'
    
    xml += '  </channel>\n'
    xml += '</rss>\n'
    
    return xml

def escape_xml(text):
    """Escape XML special chars"""
    if not text:
        return ""
    text = str(text)
    text = text.replace('&', '&amp;')
    text = text.replace('<', '&lt;')
    text = text.replace('>', '&gt;')
    text = text.replace('"', '&quot;')
    return text

def commit_and_push():
    """Commit and push changes"""
    try:
        subprocess.run(['git', '-C', REPO_DIR, 'add', '.'],
                      capture_output=True, timeout=30)
        
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
        subprocess.run(
            ['git', '-C', REPO_DIR, 'commit', '-m', f'SPZ Update {timestamp}'],
            capture_output=True, timeout=30
        )
        
        subprocess.run(
            ['git', '-C', REPO_DIR, 'push', 'origin', 'main'],
            capture_output=True, timeout=60
        )
        
        return True
    except Exception as e:
        print(f"Push error: {e}")
        return False

def main():
    print("SPZ GitHub Sync v2.1")
    print("=" * 30)
    
    # Get repo
    if not clone_or_pull_repo():
        print("Failed to access repo")
        return
    print("✓ Repo ready")
    
    # Read articles
    articles = read_master_feed()
    print(f"✓ Found {len(articles)} articles")
    
    if not articles:
        print("Nothing to sync")
        return
    
    # Update XML files
    updated = update_xml_files(articles)
    print(f"✓ Updated {len(updated)} source files")
    
    # Push
    print("\nPushing to GitHub...")
    if commit_and_push():
        print("✓ Sync complete!")
    else:
        print("✗ Sync failed")

if __name__ == "__main__":
    main()
