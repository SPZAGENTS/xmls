#!/usr/bin/env python3
"""
SPZ Translator v3.0 - תרגום מהיר עם Google Translate (חינם!)
משתמש ב-API של Google Translate דרך requests פשוט
"""

import json
import os
import re
import html
import time
import urllib.request
import urllib.parse

FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
FEED_FILES = ["rss_feed.json", "reddit_feed.json", "twitter-grok-feed.json"]
TRANSLATION_LOG = os.path.join(FEEDS_DIR, "translation_log.json")
MAX_TRANSLATIONS_PER_RUN = 500

def load_translation_log():
    if os.path.exists(TRANSLATION_LOG):
        try:
            with open(TRANSLATION_LOG, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_translation_log(log):
    with open(TRANSLATION_LOG, 'w', encoding='utf-8') as f:
        json.dump(log, f, ensure_ascii=False, indent=2)

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    text = ' '.join(text.split())
    return text.strip()

def is_hebrew(text):
    if not text:
        return False
    return any('\u0590' <= c <= '\u05FF' for c in text)

def translate_with_google(text, is_title=True):
    """מתרגם דרך Google Translate API (חינם, ללא מפתח!)"""
    if not text or len(text.strip()) == 0:
        return None
    
    try:
        # Google Translate API - חינמי וללא מפתח
        encoded_text = urllib.parse.quote(text)
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=he&dt=t&q={encoded_text}"
        
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        )
        
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            if data and len(data) > 0 and data[0]:
                translated = ''.join([item[0] for item in data[0] if item[0]])
                return translated
            return None
            
    except Exception as e:
        print(f"❌ Google Translate error: {e}")
        return None

def translate_with_openai(text, is_title=True):
    """מתרגם דרך OpenAI API (fallback)"""
    if not text or len(text.strip()) == 0:
        return None
    
    api_key = os.environ.get('OPENAI_API_KEY')
    if not api_key:
        return None
    
    import subprocess
    
    content_type = "title" if is_title else "summary"
    
    payload = json.dumps({
        "model": "gpt-3.5-turbo",
        "messages": [
            {"role": "system", "content": "You are a professional translator. Translate from English to Hebrew. Keep it natural and accurate. Return ONLY the translation, no explanations."},
            {"role": "user", "content": f"Translate this news {content_type} to Hebrew:\n\n{text}"}
        ],
        "temperature": 0.3,
        "max_tokens": 200 if is_title else 500
    })
    
    try:
        result = subprocess.run(
            ['curl', '-s', 'https://api.openai.com/v1/chat/completions',
             '-H', 'Content-Type: application/json',
             '-H', f'Authorization: Bearer {api_key}',
             '-d', payload],
            capture_output=True, text=True, timeout=30
        )
        
        if result.returncode != 0:
            return None
        
        data = json.loads(result.stdout)
        
        if 'choices' in data and len(data['choices']) > 0:
            return data['choices'][0]['message']['content'].strip()
        return None
            
    except:
        return None

def translate_text(text, is_title=True):
    """מתרגם תחילה עם Google, אם נכשל - OpenAI"""
    if not text or len(text.strip()) == 0:
        return ""
    
    if is_hebrew(text):
        return text
    
    # נסה Google Translate ראשון (מהיר!)
    result = translate_with_google(text, is_title)
    if result and is_hebrew(result):
        return result
    
    # Fallback ל-OpenAI
    result = translate_with_openai(text, is_title)
    if result:
        return result
    
    return clean_text(text)

def process_feed(feed_file, translation_log, remaining_slots):
    """מעבד קובץ פיד ומתרגם רק כתבות חדשות"""
    filepath = os.path.join(FEEDS_DIR, feed_file)
    if not os.path.exists(filepath):
        return 0, 0, remaining_slots
    
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    if 'posts' not in data:
        return 0, 0, remaining_slots
    
    posts = data['posts']
    translated_count = 0
    cached_count = 0
    
    print(f"📄 {feed_file}: {len(posts)} posts total")
    
    # ראשית: מילוי כתבות שכבר בקאש
    for post in posts:
        post_id = post.get('url', '') or post.get('permalink', '') or post.get('link', '')
        
        if post_id in translation_log:
            cached = translation_log[post_id]
            post['title_hebrew'] = cached.get('title_hebrew', '')
            post['description_hebrew'] = cached.get('description_hebrew', '')
            cached_count += 1
    
    print(f"   ✓ {cached_count} from cache")
    
    # שנית: תרגום כתבות חדשות
    for post in posts:
        if remaining_slots <= 0:
            print(f"   ⏹️ Reached limit of {MAX_TRANSLATIONS_PER_RUN} translations")
            break
        
        post_id = post.get('url', '') or post.get('permalink', '') or post.get('link', '')
        
        if post_id in translation_log:
            continue
        
        # תרגום כותרת
        title = post.get('title', '')
        clean_title = clean_text(title)
        
        if clean_title and not is_hebrew(clean_title):
            title_hebrew = translate_text(clean_title, is_title=True)
            if title_hebrew and is_hebrew(title_hebrew):
                post['title_hebrew'] = title_hebrew
                print(f"   ✓ [{remaining_slots}] {title_hebrew[:60]}...")
                translated_count += 1
                remaining_slots -= 1
            else:
                post['title_hebrew'] = clean_title
        else:
            post['title_hebrew'] = clean_title
        
        # תרגום תיאור
        if remaining_slots > 0:
            description = post.get('description', '')
            clean_desc = clean_text(description)
            
            if clean_desc and not is_hebrew(clean_desc):
                desc_hebrew = translate_text(clean_desc, is_title=False)
                if desc_hebrew and is_hebrew(desc_hebrew):
                    post['description_hebrew'] = desc_hebrew
                    remaining_slots -= 1
                else:
                    post['description_hebrew'] = clean_desc
            else:
                post['description_hebrew'] = clean_desc
        
        # שמירה בקאש
        translation_log[post_id] = {
            'title_hebrew': post.get('title_hebrew', ''),
            'description_hebrew': post.get('description_hebrew', ''),
            'translated_at': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # המתנה קצרה
        time.sleep(0.1)
    
    # שמירת הקובץ המעודכן
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    not_translated = len(posts) - cached_count - translated_count
    print(f"   📊 {cached_count} cached, {translated_count} translated, {not_translated} pending")
    
    return translated_count, cached_count, remaining_slots

def main():
    print("=" * 60)
    print("🦔 SPZ Translator v3.0 - Google Translate + OpenAI")
    print(f"   Max {MAX_TRANSLATIONS_PER_RUN} translations per run")
    print("=" * 60)
    
    translation_log = load_translation_log()
    print(f"📚 Loaded {len(translation_log)} cached translations\n")
    
    total_translated = 0
    total_cached = 0
    remaining_slots = MAX_TRANSLATIONS_PER_RUN
    
    for feed_file in FEED_FILES:
        print(f"\n📄 Processing {feed_file}...")
        t, c, remaining_slots = process_feed(feed_file, translation_log, remaining_slots)
        total_translated += t
        total_cached += c
        
        if remaining_slots <= 0:
            print("\n⏹️ Translation limit reached, stopping.")
            break
    
    save_translation_log(translation_log)
    
    print("\n" + "=" * 60)
    print(f"✅ Complete! Translated: {total_translated}, Cached: {total_cached}")
    print(f"📚 Total in cache: {len(translation_log)}")
    print("=" * 60)

if __name__ == "__main__":
    main()
