#!/usr/bin/env node
/**
 * Log Change - חובה לקרוא לפני כל שינוי ב-active-crons/
 * 
 * שימוש:
 *   const logChange = require('./scripts/log-change');
 *   logChange('ADDED', '08-new-process/run.sh', 'Ben requested new process', 'Ben');
 */

const fs = require('fs');
const path = require('path');

const LOG_FILE = path.join(__dirname, '..', 'logs', 'changes.log');
const LOG_DIR = path.dirname(LOG_FILE);

// Ensure log directory exists
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

/**
 * Log a change to the active-crons/ directory
 * @param {string} action - ADDED, MODIFIED, REMOVED, DISABLED, ENABLED
 * @param {string} target - What changed (file path or cron name)
 * @param {string} reason - Why it changed
 * @param {string} requestedBy - Who requested (Ben, Yossi, System, Self)
 */
function logChange(action, target, reason, requestedBy = 'System') {
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const entry = `[${timestamp}] ${action}: ${target} | REASON: ${reason} | BY: ${requestedBy}\n`;
  
  fs.appendFileSync(LOG_FILE, entry);
  
  // Also log to console for immediate visibility
  console.log(`📋 ${action}: ${target}`);
  
  return entry.trim();
}

// If called directly from CLI
if (require.main === module) {
  const [,, action, target, reason, requestedBy] = process.argv;
  
  if (!action || !target) {
    console.error('Usage: node log-change.js <ACTION> <TARGET> <REASON> [REQUESTED_BY]');
    console.error('Example: node log-change.js ADDED "08-new-cron/run.sh" "New daily report" Ben');
    process.exit(1);
  }
  
  logChange(action, target, reason || 'No reason given', requestedBy || 'CLI');
  console.log('✅ Logged to', LOG_FILE);
}

module.exports = logChange;
