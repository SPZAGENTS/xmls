# ⚠️ RULE: Active Crons Change Logging (חוק מספר 8)

## נוסח החוק

**"בכל פעם שמשהו משתנה בתהליכים שלנו (active-crons/), אני מתעד את השינוי בקובץ לוג לפני שאני ממשיך הלאה."**

---

## מתי מופעל

### חובה לתעד לפני שממשיכים:

1. **הוספת קרון חדש**
   - לפני `cron add` → כתוב ללוג
   - אחרי `cron add` → ודא שנרשם

2. **עדכון קרון קיים**
   - לפני `cron update` → תעד מה היה לפני
   - אחרי `cron update` → תעד מה השתנה

3. **מחיקת קרון**
   - לפני `cron remove` → תעד מה מוחקים ולמה
   - אחרי `cron remove` → אשר שהוסר

4. **שינוי קבצים ב-active-crons/**
   - כל שינוי בקובץ `.sh`, `.py`, `.js`
   - הוספה/מחיקה של קבצים
   - שינוי הגדרות

5. **שינוי system crontab (אם בכלל)**
   - אסור לגעת ב-system crontab
   - אם בכל זאת → תעד למה היה צריך

---

## איך מתעדים

### קובץ הלוג:
```
~/.openclaw/workspace/active-crons/logs/changes.log
```

### פורמט:
```
[YYYY-MM-DD HH:MM:SS] ACTION: <מה נעשה> | REASON: <למה> | BY: <מי ביקש>
```

### דוגמאות:
```
[2026-05-10 11:50:00] ADDED: cron 'new-cron-name' (every 4h) | REASON: Ben requested new Twitter monitoring process | BY: Ben
[2026-05-10 11:55:00] MODIFIED: 01-spz-rss-hourly/run.sh | REASON: Updated path to new directory structure | BY: System migration
[2026-05-10 12:00:00] REMOVED: cron 'audit-logger' | REASON: Ben wants rule-based logging instead of cron-based | BY: Ben
[2026-05-10 12:05:00] ADDED: 08-new-process/run.sh | REASON: Daily email check for urgent messages | BY: Ben
```

---

## איך הלוג נכתב

### דרך 1: ידני (כשאני עושה שינוי)
```javascript
// בכל סקריפט שאני כותב
const fs = require('fs');
const logFile = '/home/yosia/.openclaw/workspace/active-crons/logs/changes.log';
const entry = `[${new Date().toISOString()}] ADDED: cron 'name' | REASON: ... | BY: Ben\n`;
fs.appendFileSync(logFile, entry);
```

### דרך 2: אוטומטי (בכל פעם שאני קורא ל-cron tool)
לפני כל קריאה ל-`cron add/update/remove` → כתוב ללוג
אחרי כל קריאה → אשר בלוג שהושלם

### דרך 3: wrapping function
כל פעולה על active-crons/ עוברת דרך wrapper ש:
1. כותב ללוג מה מתכוונים לעשות
2. מבצע את הפעולה
3. כותב ללוג שהושלם (או נכשל)

---

## שאלות שאני שואל את עצמי לפני שינוי

### Pre-flight checklist:
- [ ] האם השינוי הזה צריך להיות מוגדר ב-OpenClaw cron (ולא system crontab)?
- [ ] האם תיעדתי מה עושים ולמה?
- [ ] האם השינוי בר- reversal אם צריך?
- [ ] האם יש גיבוי (SPZ_BACKUP_ROUTINE) אם משהו משתבש?

---

## מה קורה אם אני לא מתעד?

**זו טעות.** אני לא אמור לעשות שינוי בלי תיעוד.

אם בכל זאת עשיתי בלי לתעד:
1. תעד מיד אחרי
2. רשום שזה post-hoc
3. למד מזה לפעם הבאה

---

## היסטוריה

- **2026-05-10 11:50** - נוצר כקרון `audit-logger` (רץ כל שעה)
- **2026-05-10 11:53** - הוסב לחוק תפעולי (rule-based) לפי בקשת Ben

---

**חוק זה חל עליי (שפיצי) בכל פעולה שמשנה את active-crons/**
