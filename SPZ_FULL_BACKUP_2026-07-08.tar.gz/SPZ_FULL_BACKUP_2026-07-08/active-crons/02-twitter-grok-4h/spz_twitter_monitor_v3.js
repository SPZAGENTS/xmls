#!/usr/bin/env node
/**
 * SPZ Twitter Monitor v3 - Instagram-Aligned
 * מוניטור מחודש לפי תובנות מהאינסטגרם של SPZ
 * 
 * מה חדש:
 * - מילות חיפוש בעברית ואנגלית
 * - פוקוס על תוכן מהשטח (לא מדיות גדולות)
 * - כל סוגי המדיה: וידאו, תמונה, טקסט
 * - נושאים: אנטישמיות, נאמנות כפולה, איום איסלאמי, חשיפת תומכי טרור, פרו-ישראל
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const API_KEY = process.env.XAI_API_KEY;
if (!API_KEY) {
    console.error('❌ XAI_API_KEY not set');
    process.exit(1);
}

const CONFIG = {
    model: 'grok-4-fast-reasoning',
    output_dir: '/home/yosia/.openclaw/workspace/spz-feeds',
    xml_filename: 'twitter-grok-feed.xml',
    json_filename: 'twitter-grok-feed.json',
    repo_dir: '/home/yosia/.openclaw/workspace/spz-repo',
    max_results: 50,
    time_window_hours: 4,
    timeout_ms: 180000
};

// ===== מקורות לפי קטגוריות (מעודכן לפי אינסטגרם) =====
const SOURCES = {
    antisemitism_field: {
        name: "אנטישמיות מהשטח",
        handles: [
            '@campusjewhate', '@StopAntisemites', '@CanaryMission',
            '@EndJewHatred', '@JewishLDN', '@ParisJewry', '@NYJewish'
        ],
        keywords_he: ['אנטישמיות', 'תקיפת יהודים', 'הצתת בית כנסת', 'קמפוס יהודי'],
        keywords_en: ['antisemitism', 'attack on jews', 'synagogue arson', 'jewish campus'],
        weight: 3.0
    },
    islamic_threat_europe: {
        name: "איום איסלאמי באירופה",
        handles: [
            '@Visegrad24', '@RadioGenoa', '@EMichaelJones1',
            '@EuropeNews911', '@VoiceOfEuropeNews'
        ],
        keywords_he: ['שריעה', 'פטרול מוסלמי', 'אגרסיביות מוסלמית', 'ברלין לונדון פריז'],
        keywords_en: ['sharia patrol', 'muslim aggression', 'islamic threat europe', 'no go zone'],
        weight: 2.8
    },
    double_loyalty: {
        name: "נאמנות כפולה",
        handles: [
            '@NickShirleyNews', '@LibsOfTikTok', '@CollinRugg'
        ],
        keywords_he: ['נאמנות כפולה', 'אחים מוסלמים', 'תמיכה בטרור'],
        keywords_en: ['dual loyalty', 'muslim brotherhood', 'support terror', 'america vs islam'],
        weight: 2.5
    },
    expose_terror_supporters: {
        name: "חשיפת תומכי טרור",
        handles: [
            '@CanaryMission', '@StopAntisemites', '@HamasAtrocities'
        ],
        keywords_he: ['תומכי חמאס', 'פעילי שלום', 'הצגה', 'וועידה עממית'],
        keywords_en: ['hamas supporter', 'peace activist fake', 'terror supporter exposed', 'free gaza sham'],
        weight: 2.5
    },
    pro_israel_local: {
        name: "פרו-ישראל מקומי",
        handles: [
            '@TheJewishVoice', '@JewsAreNews', '@JewishRising',
            '@Eretz_Neo', '@StandWithUs'
        ],
        keywords_he: ['עלייה לישראל', 'עולה חדש', 'יהדות', 'תקווה'],
        keywords_en: ['making aliyah', 'new immigrant israel', 'jewish identity', 'hatikvah'],
        weight: 2.0
    },
    politicians_anti_antisemitism: {
        name: "פוליטיקאים נגד אנטישמיות",
        handles: [
            '@KemiBadenoch', '@PierrePoilievre', '@RobertFico',
            '@GiorgiaMeloni', '@vonderleyen'
        ],
        keywords_he: ['נגד אנטישמיות', 'בית ספר יהודי', 'מאבטחים'],
        keywords_en: ['fight antisemitism', 'jewish school security', 'never again', 'antisemitism must stop'],
        weight: 2.0
    }
};

function callGrokAPI(payload) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify(payload);
        const options = {
            hostname: 'api.x.ai',
            path: '/v1/responses',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Length': Buffer.byteLength(data)
            }
        };

        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk) => responseData += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(responseData);
                    if (res.statusCode !== 200) {
                        reject(new Error(`API Error ${res.statusCode}: ${JSON.stringify(parsed)}`));
                        return;
                    }
                    resolve(parsed);
                } catch (e) {
                    reject(e);
                }
            });
        });

        req.on('error', reject);
        req.setTimeout(CONFIG.timeout_ms, () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        req.write(data);
        req.end();
    });
}

// ===== חיפוש לפי מקור + נושא =====
async function searchByCategory(category, config) {
    const handlesQuery = config.handles.join(' OR ');
    const keywordsHe = config.keywords_he.slice(0, 2).join(' OR ');
    const keywordsEn = config.keywords_en.slice(0, 2).join(' OR ');
    
    const payload = {
        model: CONFIG.model,
        input: `Search X/Twitter for posts from the last ${CONFIG.time_window_hours} hours.

Focus: ${config.name}
Accounts to check: ${handlesQuery}

Search for posts about (Hebrew): ${keywordsHe}
Search for posts about (English): ${keywordsEn}

Requirements:
- REAL posts from the field (not news articles, not official statements)
- Any media type: video, image, text - all are welcome
- Prefer content that exposes, documents, or shows events as they happen
- Include Hebrew translation of the text
- Note: is it a video? image? or text-only?

Return JSON:
{
    "posts": [
        {
            "username": "@handle",
            "display_name": "Name",
            "text": "original text",
            "hebrew_translation": "תרגום לעברית",
            "date": "2026-05-05T12:00:00Z",
            "likes": 10,
            "retweets": 5,
            "replies": 2,
            "has_media": true,
            "media_type": "video|image|text",
            "media_urls": ["https://..."],
            "url": "https://x.com/...",
            "relevance_score": 85,
            "category": "${category}"
        }
    ]
}`,
        tools: [{ type: 'x_search' }]
    };

    try {
        console.log(`🔍 ${config.name} (${config.handles.length} handles)...`);
        const start = Date.now();
        const response = await callGrokAPI(payload);
        const duration = Date.now() - start;
        const posts = parsePosts(response);
        console.log(`   ✅ ${posts.length} posts in ${duration}ms`);
        return posts.map(p => ({
            ...p,
            category: category,
            category_name: config.name,
            weight: config.weight,
            search_method: 'category'
        }));
    } catch (error) {
        console.error(`   ❌ ${config.name} failed:`, error.message);
        return [];
    }
}

// ===== חיפוש חופשי לפי נושא =====
async function searchByTopic(topicQuery, topicName, weight) {
    const payload = {
        model: CONFIG.model,
        input: `Search X/Twitter for posts about "${topicQuery}" from the last ${CONFIG.time_window_hours} hours.

Find REAL field content - not news articles, not official statements.
Any media type: video, image, text.
Include Hebrew translation.

Return JSON:
{
    "posts": [
        {
            "username": "@handle",
            "display_name": "Name",
            "text": "content",
            "hebrew_translation": "תרגום",
            "date": "2026-05-05T12:00:00Z",
            "likes": 10,
            "retweets": 5,
            "has_media": true,
            "media_type": "video|image|text",
            "media_urls": ["https://..."],
            "url": "https://x.com/...",
            "relevance_score": 80
        }
    ]
}`,
        tools: [{ type: 'x_search' }]
    };

    try {
        console.log(`🔍 Topic: ${topicName}...`);
        const response = await callGrokAPI(payload);
        const posts = parsePosts(response);
        console.log(`   ✅ ${posts.length} posts`);
        return posts.map(p => ({
            ...p,
            category: 'topic',
            category_name: topicName,
            weight: weight,
            search_method: 'topic',
            search_topic: topicName
        }));
    } catch (error) {
        console.error(`   ❌ ${topicName} failed:`, error.message);
        return [];
    }
}

// ===== פרסור =====
function parsePosts(response) {
    if (!response.output) return [];
    
    for (const item of response.output) {
        let text = null;
        
        if (Array.isArray(item)) {
            for (const msg of item) {
                if (msg.content) {
                    for (const content of msg.content) {
                        if (content.text) { text = content.text; break; }
                    }
                }
            }
        } else if (item.content) {
            for (const content of item.content) {
                if (content.text) { text = content.text; break; }
            }
        }
        
        if (text) {
            let jsonStr = text;
            const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
            if (codeBlockMatch) jsonStr = codeBlockMatch[1].trim();
            
            const postsMatch = jsonStr.match(/"posts"\s*:\s*(\[[\s\S]*\])/);
            if (postsMatch) {
                try {
                    const posts = JSON.parse(postsMatch[1]);
                    return posts.map(normalizePost);
                } catch (e) {
                    const arrayMatch = jsonStr.match(/(\[[\s\S]*\])/);
                    if (arrayMatch) {
                        try {
                            const arr = JSON.parse(arrayMatch[1]);
                            if (Array.isArray(arr)) return arr.map(normalizePost);
                        } catch (e2) {}
                    }
                }
            }
        }
    }
    return [];
}

function normalizePost(p) {
    const handleMatch = (p.author || p.username || '').match(/@(\w+)/);
    const username = handleMatch ? '@' + handleMatch[1] : (p.username || 'unknown');
    
    return {
        username: username,
        display_name: p.display_name || (p.author || '').split(' - ')[0] || username,
        text: p.text || p.content || '',
        hebrew_translation: p.hebrew_translation || p.hebrew || '',
        title_hebrew: p.title_hebrew || p.hebrew_translation || p.hebrew || p.text || '',
        description_hebrew: p.hebrew_translation || p.hebrew || p.text || '',  // FIX: was English, now Hebrew
        date: p.date || p.timestamp || new Date().toISOString(),
        likes: parseInt(p.likes || p.engagement?.likes || 0),
        retweets: parseInt(p.retweets || p.engagement?.reposts || 0),
        replies: parseInt(p.replies || p.engagement?.replies || 0),
        url: p.url || '',
        has_media: p.has_media || (p.media_urls && p.media_urls.length > 0) || false,
        media_type: p.media_type || 'text',
        media_urls: p.media_urls || [],
        relevance_score: parseInt(p.relevance_score || 50),
        category: p.category || 'general'
    };
}

// ===== ציון סופי =====
function calculateFinalScore(post) {
    let score = post.relevance_score || 50;
    score *= post.weight || 1;
    
    // Media bonus
    if (post.has_media) {
        if (post.media_type === 'video') score *= 1.3;
        else if (post.media_type === 'image') score *= 1.2;
        else score *= 1.1;
    }
    
    // Engagement bonus
    const engagement = post.likes + post.retweets * 2 + post.replies;
    if (engagement > 100) score *= 1.3;
    else if (engagement > 50) score *= 1.2;
    else if (engagement > 10) score *= 1.1;
    
    return Math.min(Math.round(score), 100);
}

// ===== XML =====
function generateXML(posts) {
    const now = new Date().toISOString();
    
    let xml = `<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
  <channel>
    <title>SPZ Twitter Feed - Field Content</title>
    <description>תוכן מהשטח - אנטישמיות, איום איסלאמי, חשיפת תומכי טרור, פרו-ישראל</description>
    <link>https://github.com/SPZAGENTS/xmls</link>
    <lastBuildDate>${now}</lastBuildDate>
    <language>he</language>
`;

    const sorted = posts.sort((a, b) => calculateFinalScore(b) - calculateFinalScore(a));
    
    for (const post of sorted.slice(0, 30)) {
        const score = calculateFinalScore(post);
        const title = (post.hebrew_translation || post.text || 'ללא כותרת')
            .substring(0, 80)
            .replace(/\n/g, ' ');
        const fullTitle = title.length > 80 ? title + '...' : title;
        
        let desc = '';
        if (post.media_urls && post.media_urls.length > 0) {
            desc += ` &lt;img align='right' src='${escapeXml(post.media_urls[0])}' alt='${post.media_type}'&gt; `;
        }
        desc += escapeXml(post.hebrew_translation || post.text || '');
        
        const mediaIcon = post.media_type === 'video' ? '🎬 ' : 
                         post.media_type === 'image' ? '📷 ' : '📝 ';
        
        xml += `    <item>
      <title>[${score}] ${mediaIcon}${escapeXml(fullTitle)}</title>
      <link>${escapeXml(post.url || '')}</link>
      <description>${desc}</description>
      <pubDate>${post.date}</pubDate>
      <source>twitter-${escapeXml(post.username || 'unknown')}</source>
      <category>${post.category_name || post.category}</category>
      ${post.has_media ? `<enclosure url="${escapeXml(post.url || '')}" type="${post.media_type === 'video' ? 'video/mp4' : post.media_type === 'image' ? 'image/jpeg' : 'text/html'}"/>` : ''}
    </item>
`;
    }
    
    xml += `  </channel>
</rss>`;
    return xml;
}

function escapeXml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

// ===== שמירה =====
function saveFiles(posts, xml) {
    const jsonPath = path.join(CONFIG.output_dir, CONFIG.json_filename);
    const jsonData = {
        metadata: {
            agent: 'twitter',
            version: '3.0',
            timestamp: new Date().toISOString(),
            total_posts: posts.length,
            categories: {}
        },
        posts: posts
    };
    
    // Count by category
    for (const post of posts) {
        const cat = post.category_name || post.category;
        jsonData.metadata.categories[cat] = (jsonData.metadata.categories[cat] || 0) + 1;
    }
    
    fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2), 'utf-8');
    console.log(`✅ JSON: ${jsonPath}`);
    
    const xmlPath = path.join(CONFIG.output_dir, CONFIG.xml_filename);
    fs.writeFileSync(xmlPath, xml, 'utf-8');
    console.log(`✅ XML: ${xmlPath}`);
    
    return { jsonPath, xmlPath };
}

// ===== Git =====
function pushToGit(files, postCount) {
    try {
        const repoJson = path.join(CONFIG.repo_dir, CONFIG.json_filename);
        const repoXml = path.join(CONFIG.repo_dir, CONFIG.xml_filename);
        
        fs.copyFileSync(files.jsonPath, repoJson);
        fs.copyFileSync(files.xmlPath, repoXml);
        
        execSync(`git -C ${CONFIG.repo_dir} pull origin main`, { captureOutput: true, timeout: 60000 });
        execSync(`git -C ${CONFIG.repo_dir} add .`, { captureOutput: true, timeout: 30000 });
        
        const ts = new Date().toISOString().substring(0, 16).replace('T', ' ');
        execSync(`git -C ${CONFIG.repo_dir} commit -m "Twitter v3 ${ts} (${postCount} posts)"`, { captureOutput: true, timeout: 30000 });
        execSync(`git -C ${CONFIG.repo_dir} push origin main`, { captureOutput: true, timeout: 60000 });
        
        console.log('✅ Pushed to GitHub');
        return true;
    } catch (e) {
        console.log('⚠️ Git issue:', e.message);
        return false;
    }
}

// ===== ראשי =====
async function main() {
    console.log('🚀 SPZ Twitter Monitor v3 - Instagram-Aligned');
    console.log('==============================================');
    console.log(`⏰ ${new Date().toISOString()}`);
    console.log(`🔍 Window: ${CONFIG.time_window_hours}h\n`);
    
    const allPosts = [];
    
    // חיפוש לפי קטגוריות
    for (const [catKey, catConfig] of Object.entries(SOURCES)) {
        const posts = await searchByCategory(catKey, catConfig);
        allPosts.push(...posts);
        
        // Rate limit protection
        if (catKey !== 'politicians_anti_antisemitism') {
            console.log('   ⏳ Waiting 3s...');
            await new Promise(r => setTimeout(r, 3000));
        }
    }
    
    // חיפוש נושאים חופשיים
    const topicPosts = await searchByTopic(
        'antisemitism OR "attack on jews" OR "synagogue" OR "jewish attacked" OR "campus antisemitism"',
        'אנטישמיות מהשטח',
        2.5
    );
    allPosts.push(...topicPosts);
    
    // עוד נושא
    await new Promise(r => setTimeout(r, 3000));
    const topicPosts2 = await searchByTopic(
        'sharia OR "muslim patrol" OR "islamic threat" OR "europe islam" OR "no go zone"',
        'איום איסלאמי באירופה',
        2.3
    );
    allPosts.push(...topicPosts2);
    
    console.log(`\n📊 Total posts: ${allPosts.length}`);
    
    if (allPosts.length === 0) {
        console.log('⚠️ No posts found');
        return;
    }
    
    // Generate
    console.log('\n📝 Generating XML...');
    const xml = generateXML(allPosts);
    
    // Save
    const files = saveFiles(allPosts, xml);
    
    // Push
    console.log('\n📤 Pushing to GitHub...');
    pushToGit(files, allPosts.length);
    
    // Summary
    console.log('\n✅ Done!');
    console.log(`📊 Posts: ${allPosts.length}`);
    for (const [cat, count] of Object.entries(files.jsonData?.metadata?.categories || {})) {
        console.log(`   ${cat}: ${count}`);
    }
    console.log(`   Videos: ${allPosts.filter(p => p.media_type === 'video').length}`);
    console.log(`   Images: ${allPosts.filter(p => p.media_type === 'image').length}`);
    console.log(`   Text: ${allPosts.filter(p => p.media_type === 'text').length}`);
    console.log(`   Top score: ${Math.max(...allPosts.map(calculateFinalScore))}`);
}

main().catch(console.error);