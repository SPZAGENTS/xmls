#!/bin/bash
# SPZ Twitter Monitor v2 - Cron Job
# רץ כל 4 שעות עם חיפוש ממוקד ושמירת JSON

export XAI_API_KEY="xai-zesycAgCOo8Rm4FjlhnsYZhBmxswrp83RgDK7qAsGRiVZO9HEI2BKnMyglrCHVzBexXtf68OK7hkNGKs"

# Git config
REPO_DIR="/home/yosia/.openclaw/workspace/spz-repo"
git -C "$REPO_DIR" config user.email "spz@agent.local" 
git -C "$REPO_DIR" config user.name "SPZ Agent"
git -C "$REPO_DIR" remote set-url origin "https://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@github.com/SPZAGENTS/xmls.git"

LOG_DIR="/home/yosia/.openclaw/workspace/logs"
mkdir -p "$LOG_DIR"

LOG_FILE="$LOG_DIR/twitter_cron_$(date +%Y%m%d).log"
ALERT_NUMBER="+972527222872"

echo "========================================" >> "$LOG_FILE"
echo "$(date '+%Y-%m-%d %H:%M:%S'): Starting Twitter Monitor v2 (4h interval)" >> "$LOG_FILE"

# Use new v2 monitor
node /home/yosia/.openclaw/workspace/active-crons/02-twitter-grok-4h/spz_twitter_monitor_v3.js >> "$LOG_FILE" 2>&1

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S'): ✅ Success" >> "$LOG_FILE"
    
    # Send summary if posts found
    POST_COUNT=$(jq -r '.metadata.total_posts' /home/yosia/.openclaw/workspace/spz-feeds/twitter-grok-feed.json 2>/dev/null || echo "0")
    if [ "$POST_COUNT" -gt 0 ] 2>/dev/null; then
        wacli send text --to "$ALERT_NUMBER" --message "🐦 SPZ Twitter: נמצאו $POST_COUNT פוסטים חדשים ($(date '+%H:%M'))" 2>/dev/null
    fi
else
    echo "$(date '+%Y-%m-%d %H:%M:%S'): ❌ Failed with code $EXIT_CODE" >> "$LOG_FILE"
    wacli send text --to "$ALERT_NUMBER" --message "❌ SPZ Twitter Monitor - נכשל (קוד: $EXIT_CODE)" 2>/dev/null
fi

echo "========================================" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

exit $EXIT_CODE