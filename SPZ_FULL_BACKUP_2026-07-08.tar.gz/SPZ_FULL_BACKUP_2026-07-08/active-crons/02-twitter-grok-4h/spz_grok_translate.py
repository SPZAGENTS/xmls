#!/usr/bin/env python3
"""
SPZ Grok Translator - תרגום ייעודי לפלט מ-Grok Cron
=====================================================
מטרה: לקחת את twitter-grok-feed.json, למלא שדות חסרים בעברית,
ולייצר twitter-grok-feed.xml בעברית מלאה.

מבנה הקלט (Grok JSON):
  - text: טקסט מקורי באנגלית
  - hebrew_translation: תרגום בעברית (כבר קיים!)
  - title_hebrew: ריק ← צריך למלא
  - description_hebrew: ריק ← צריך למלא
  - url, username, likes, retweets, date וכו'

מבנה הפלט:
  - twitter-grok-feed.xml בעברית מלאה
  - twitter-grok-feed.json מעודכן עם title_hebrew + description_hebrew

אינטגרציה:
  1. GROK Cron רץ → יוצר twitter-grok-feed.json
  2. סקריפט זה רץ → מתקן JSON + מייצר XML בעברית
  3. XML נדחף לגיטהאב
"""

import json
import os
import re
import html
from datetime import datetime

# נתיבים - משתמשים באותם נתיבים ש-Grok Cron משתמש
FEEDS_DIR = "/home/yosia/.openclaw/workspace/spz-feeds"
REPO_DIR = "/home/yosia/.openclaw/workspace/spz-repo"

GROK_JSON = os.path.join(FEEDS_DIR, "twitter-grok-feed.json")
GROK_XML_OUT = os.path.join(REPO_DIR, "twitter-grok-feed.xml")


def clean_text(text):
    """ניקוי טקסט בסיסי"""
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    text = ' '.join(text.split())
    return text.strip()


def has_hebrew(text):
    """בדוק אם הטקסט מכיל עברית"""
    if not text:
        return False
    return any('\u0590' <= c <= '\u05FF' for c in str(text))


def escape_xml(text):
    """בריחת תווים מיוחדים ב-XML"""
    if not text:
        return ""
    text = str(text)
    text = text.replace('&', '&amp;')
    text = text.replace('<', '&lt;')
    text = text.replace('>', '&gt;')
    text = text.replace('"', '&quot;')
    return text


def translate_grok_posts(posts):
    """
    מתרגם פוסטים מ-Grok.
    ל-Grok יש כבר hebrew_translation - פשוט מעתיק לשדות הנכונים.
    """
    translated = 0
    skipped = 0
    
    for post in posts:
        # אם כבר יש title_hebrew בעברית - דלג
        if post.get('title_hebrew') and has_hebrew(post['title_hebrew']):
            skipped += 1
            continue
        
        # קח את hebrew_translation או text
        hebrew_text = post.get('hebrew_translation', '')
        english_text = post.get('text', '')
        
        # בחר את המקור לשדות
        source_text = hebrew_text if hebrew_text else english_text
        clean = clean_text(source_text)
        
        if not clean:
            continue
        
        # מלא title_hebrew - חלק ראשון או כל הטקסט
        if len(clean) > 100:
            # קח משפט ראשון או 100 תווים ל-title
            first_sentence = clean.split('.')[0] if '.' in clean else clean[:100]
            post['title_hebrew'] = first_sentence.strip()
            post['description_hebrew'] = clean
        else:
            post['title_hebrew'] = clean
            post['description_hebrew'] = clean
        
        translated += 1
    
    return translated, skipped


def build_grok_xml(posts):
    """
    בונה XML RSS 2.0 מפוסטי Grok בעברית.
    פורמט תואם לשאר הפידים ב-repo.
    """
    now = datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')
    
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    xml += '<rss version="2.0">\n'
    xml += '  <channel>\n'
    xml += '    <title>Twitter Grok Feed - Top Stories</title>\n'
    xml += f'    <lastBuildDate>{now}</lastBuildDate>\n'
    xml += '    <description>SPZ News Aggregator</description>\n'
    
    # מיין לפי חשיבות (relevance_score או likes)
    sorted_posts = sorted(
        posts, 
        key=lambda p: p.get('relevance_score', 0) + p.get('likes', 0) * 0.1,
        reverse=True
    )
    
    for post in sorted_posts[:30]:  # מקסימום 30 פריטים
        title = escape_xml(post.get('title_hebrew', post.get('hebrew_translation', 'ללא כותרת')))
        link = escape_xml(post.get('url', ''))
        desc = escape_xml(post.get('description_hebrew', post.get('hebrew_translation', '')))
        date = escape_xml(post.get('date', now))
        author = escape_xml(post.get('username', 'Unknown'))
        
        xml += '    <item>\n'
        xml += f'      <title>{title}</title>\n'
        xml += f'      <link>{link}</link>\n'
        xml += f'      <description>{desc}</description>\n'
        xml += f'      <pubDate>{date}</pubDate>\n'
        xml += f'      <author>{author}</author>\n'
        
        # metadata נוסף כ-guide/source
        score = post.get('relevance_score', 0)
        category = post.get('category_name', 'General')
        xml += f'      <category>{escape_xml(category)}</category>\n'
        xml += f'      <source>Twitter / X</source>\n'
        
        xml += '    </item>\n'
    
    xml += '  </channel>\n'
    xml += '</rss>\n'
    
    return xml


def save_updated_json(data, filepath):
    """שמירת JSON מעודכן עם השדות החדשים"""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def save_xml(xml_content, filepath):
    """שמירת XML"""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(xml_content)


def main():
    """תהליך ראשי"""
    print("=" * 60)
    print("SPZ Grok Translator")
    print("=" * 60)
    
    # 1. קרא JSON
    if not os.path.exists(GROK_JSON):
        print(f"❌ {GROK_JSON} not found")
        return 1
    
    with open(GROK_JSON, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    posts = data.get('posts', [])
    print(f"📄 Loaded {len(posts)} posts from {GROK_JSON}")
    
    if not posts:
        print("⚠️ No posts to translate")
        return 0
    
    # 2. תרגם (בעצם רק מעתיק hebrew_translation לשדות הנכונים)
    translated, skipped = translate_grok_posts(posts)
    print(f"✅ Updated: {translated} posts, Skipped: {skipped} (already Hebrew)")
    
    # 3. שמור JSON מעודכן
    save_updated_json(data, GROK_JSON)
    print(f"💾 Updated JSON saved: {GROK_JSON}")
    
    # 4. בנה XML
    xml = build_grok_xml(posts)
    
    # 5. שמור XML
    save_xml(xml, GROK_XML_OUT)
    print(f"💾 Hebrew XML saved: {GROK_XML_OUT}")
    
    # 6. בדוק תוצאה
    with open(GROK_XML_OUT, 'r', encoding='utf-8') as f:
        content = f.read()
    
    has_hebrew_xml = has_hebrew(content)
    print(f"\n🔍 XML contains Hebrew: {has_hebrew_xml}")
    
    if has_hebrew_xml:
        print("✅ SUCCESS - XML is ready for GitHub push")
        return 0
    else:
        print("❌ WARNING - XML does not contain Hebrew text")
        return 1


if __name__ == "__main__":
    exit(main())
