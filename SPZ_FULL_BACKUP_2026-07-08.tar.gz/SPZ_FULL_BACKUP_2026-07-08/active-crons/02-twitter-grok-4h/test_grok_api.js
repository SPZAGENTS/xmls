// Quick diagnostic for SPZ Twitter Monitor
const https = require('https');

const API_KEY = process.env.XAI_API_KEY || 'xai-zesycAgCOo8Rm4FjlhnsYZhBmxswrp83RgDK7qAsGRiVZO9HEI2BKnMyglrCHVzBexXtf68OK7hkNGKs';

function callGrokAPI(payload) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify(payload);
        const options = {
            hostname: 'api.x.ai',
            path: '/v1/responses',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Length': Buffer.byteLength(data)
            }
        };

        console.log('Making API request...');
        const start = Date.now();
        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk) => responseData += chunk);
            res.on('end', () => {
                const duration = Date.now() - start;
                console.log(`Response received in ${duration}ms`);
                console.log(`Status: ${res.statusCode}`);
                if (res.statusCode !== 200) {
                    console.error('Error response:', responseData.substring(0, 500));
                    reject(new Error(`HTTP ${res.statusCode}`));
                    return;
                }
                try {
                    const parsed = JSON.parse(responseData);
                    resolve(parsed);
                } catch (e) {
                    console.error('Parse error:', responseData.substring(0, 500));
                    reject(e);
                }
            });
        });

        req.on('error', (err) => {
            console.error('Request error:', err.message);
            reject(err);
        });
        req.setTimeout(180000, () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        req.write(data);
        req.end();
    });
}

async function testOneCategory() {
    const payload = {
        model: 'grok-4-fast-reasoning',
        input: `Search X/Twitter for posts from the last 4 hours.

Focus: Antisemitism field reports
Accounts to check: @campusjewhate OR @StopAntisemites OR @CanaryMission

Search for posts about (Hebrew): אנטישמיות OR תקיפת יהודים
Search for posts about (English): antisemitism OR "attack on jews"

Requirements:
- REAL posts from the field
- Any media type
- Include Hebrew translation

Return JSON:
{
    "posts": [
        {
            "username": "@handle",
            "text": "original text",
            "hebrew_translation": "תרגום",
            "date": "2026-06-07T10:00:00Z",
            "likes": 10,
            "url": "https://x.com/..."
        }
    ]
}`,
        tools: [{ type: 'x_search' }]
    };

    console.log('🧪 Testing Grok API with x_search tool...');
    const start = Date.now();
    try {
        const response = await callGrokAPI(payload);
        console.log('✅ Got response');
        console.log(JSON.stringify(response, null, 2).substring(0, 800));
    } catch (e) {
        console.error('❌ Failed:', e.message);
    }
    console.log(`Total time: ${Date.now() - start}ms`);
}

testOneCategory().catch(console.error);
