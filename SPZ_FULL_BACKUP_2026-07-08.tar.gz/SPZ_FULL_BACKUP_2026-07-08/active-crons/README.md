# active-crons/ - מרכז הניהול של שפיצי

**נוצר:** 2026-05-10  
**מטרה:** מרכז ניהול אחיד לכל הקרונים הפעילים של SPZ  
**מיקום:** `~/.openclaw/workspace/active-crons/`

---

## 🎯 איך זה עובד

מעכשיו כל הקרונים רשומים **במערכת OpenClaw** ולא ב-system crontab.  
זה אומר שאני (שפיצי) יכול לראות אותם, לנהל אותם, ולדווח עליהם בכל רגע.

**לצפיה בכל הקרונים:**
```
cron list
```

**לבדיקת סטטוס:**
```
/status
```

**להפעלה ידנית:**
```
cron run <job-name>
```

---

## 📋 רשימת הקרונים (8 סה"כ)

### 1️⃣ SPZ RSS Hourly (`spz-rss-hourly`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל שעה בדיוק (00:00) |
| **מיקום** | `01-spz-rss-hourly/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | אוסף חדשות מ-28 מקורות RSS + Reddit → מסנן → מסנכרן ל-GitHub |
| **קבצים נוספים** | `spz_orchestrator.py`, `spz_rss_agent.py`, `spz_reddit_agent.py`, `spz_github_sync.py` |
| **סטטוס** | ✅ פעיל |

---

### 2️⃣ Twitter Grok Monitor (`twitter-grok-4h`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל 4 שעות (02:00, 06:00, 10:00, 14:00, 18:00, 22:00) |
| **מיקום** | `02-twitter-grok-4h/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | מנטר טוויטר דרך Grok API - מחפש: אנטישמיות, איום איסלאמי, נאמנות כפולה, תומכי טרור |
| **קבצים נוספים** | `spz_twitter_monitor_v3.js` |
| **סטטוס** | ✅ פעיל |

---

### 3️⃣ Moltbook Morning Post (`moltbook-morning`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל יום בשעה 09:00 |
| **מיקום** | `03-moltbook-morning/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | יוצר פוסט בוקר אוטומטי ב-Moltbook |
| **סטטוס** | ✅ פעיל |

---

### 4️⃣ Moltbook Afternoon Post (`moltbook-afternoon`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל יום בשעה 14:00 |
| **מיקום** | `04-moltbook-afternoon/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | יוצר פוסט צהריים אוטומטי ב-Moltbook |
| **סטטוס** | ✅ פעיל |

---

### 5️⃣ Moltbook Evening Post (`moltbook-evening`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל יום בשעה 20:00 |
| **מיקום** | `05-moltbook-evening/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | יוצר פוסט ערב אוטומטי ב-Moltbook |
| **סטטוס** | ✅ פעיל |

---

### 6️⃣ Moltbook Star Mode (`moltbook-star-2h`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל 2 שעות (00:00, 02:00, 04:00...) |
| **מיקום** | `06-moltbook-star-2h/` |
| **סקריפט** | `star-mode-v3.js` |
| **מה עושה** | אנגג'מנט אוטומטי ב-Moltbook - לייקים, תגובות, שיתופים |
| **סטטוס** | ✅ פעיל |

---

### 7️⃣ Heartbeat Monitor (`heartbeat-monitor`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | פעמיים ביום (10:00, 22:00) |
| **מיקום** | `07-heartbeat-monitor/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | בודק שכל הקרונים רצים ושולח התראות WhatsApp אם יש בעיה |
| **סטטוס** | ✅ פעיל |

---

## 📂 מבנה התיקייה

```
active-crons/
├── README.md                    # קובץ זה
├── 01-spz-rss-hourly/          # איסוף חדשות (כל שעה)
│   ├── run.sh                   # סקריפט ראשי
│   ├── spz_orchestrator.py     # מוח המערכת
│   ├── spz_rss_agent.py        # סוכן RSS
│   ├── spz_reddit_agent.py     # סוכן Reddit
│   └── spz_github_sync.py      # סנכרון GitHub
├── 02-twitter-grok-4h/         # ניטור טוויטר (כל 4 שעות)
│   ├── run.sh
│   └── spz_twitter_monitor_v3.js
├── 03-moltbook-morning/        # פוסט בוקר (09:00)
│   └── run.sh
├── 04-moltbook-afternoon/      # פוסט צהריים (14:00)
│   └── run.sh
├── 05-moltbook-evening/        # פוסט ערב (20:00)
│   └── run.sh
├── 06-moltbook-star-2h/        # אנגג'מנט (כל 2 שעות)
│   └── star-mode-v3.js
├── 07-heartbeat-monitor/       # ניטור סטטוס (10:00, 22:00)
│   └── run.sh
├── 08-daily-backup/            # גיבוי יומי בחצות (00:00)
│   └── run.sh
├── skills-moltbook@ -> ../skills/moltbook/    # קישור לסקיל
├── skills-grok-search@ -> ../skills/grok-search/
├── skills-cron@ -> ../skills/cron/
├── skills-spz-content@ -> ../skills/spz-content-system/
└── logs/                        # לוגים מאוחדים
```

---

### 8️⃣ Daily Backup (`daily-backup-midnight`)
| פרט | תיאור |
|-----|-------|
| **תדירות** | כל יום בחצות (00:00) |
| **מיקום** | `08-daily-backup/` |
| **סקריפט** | `run.sh` |
| **מה עושה** | יוצר גיבוי יומי (`SPZ_BACKUP_YYYY-MM-DD`), שומר 7 ימים אחרונים, מוחק ישן מיום 8 |
| **גיבויים** | `SPZ_BACKUP_2026-05-10`, `SPZ_BACKUP_2026-05-09` ... עד 7 ימים |
| **סטטוס** | ✅ פעיל |

---

### רשימת כל הקרונים
```bash
cron list
```

### הפעלה ידנית
```bash
cron run spz-rss-hourly
cron run twitter-grok-4h
cron run moltbook-morning
```

### בדיקת סטטוס קרון ספציפי
```bash
cron info spz-rss-hourly
```

### עצירה זמנית
```bash
cron disable moltbook-star-2h
```

### הפעלה מחדש
```bash
cron enable moltbook-star-2h
```

### מחיקה
```bash
cron remove <job-name>
```

---

## 📊 סטטוס אחרון

לבדיקת סטטוס בזמן אמת:
```
What is the status of my cron jobs?
```

או בקש ממני:
```
בדוק סטטוס הקרונים שלי
```

---

## 🔗 סקילים מקושרים

| קישור | תיאור |
|-------|-------|
| `skills-moltbook@` | סקיל Moltbook - פוסטים ואנגג'מנט |
| `skills-grok-search@` | סקיל חיפוש Grok/XAI |
| `skills-cron@` | סקיל ניהול קרונים |
| `skills-spz-content@` | סקיל מערכת תוכן SPZ |

---

## 📞 התראות

כל הקרונים שולחים התראות WhatsApp ל-`+972527222872` במקרה של:
- כישלון בריצה
- 0 פוסטים נמצאו (בטוויטר)
- קרון לא רץ יותר מ-4 שעות

---

## ⚡ מה השתנה?

**לפני:** קרונים רצו דרך `system crontab` (ניהול ידני)
**אחרי:** קרונים רשומים ב-OpenClaw (אני מנהל אותם)

**יתרונות:**
- ✅ אני רואה את כל הקרונים בכל רגע
- ✅ אני יכול להפעיל/לעצור/לערוך
- ✅ לוגים מרוכזים
- ✅ התראות אוטומטיות
- ✅ קל לשחזר אם משהו נשבר

---

## 📦 גיבוי

**גיבוי יומי (7 ימים מסתובבים):**
- `SPZ_BACKUP_YYYY-MM-DD` — גיבוי יומי (נשמרים 7 ימים אחרונים)
- `SPZ_BACKUP_ROUTINE` — גיבוי ראשוני (2026-05-10 11:40)

**קרון:** `daily-backup-midnight` רץ כל לילה ב-00:00
**מחיקה:** גיבויים מעבר ל-7 ימים נמחקים אוטומטית

---

*נוצר אוטומטית על ידי שפיצי (Pitzi) v2.0*
