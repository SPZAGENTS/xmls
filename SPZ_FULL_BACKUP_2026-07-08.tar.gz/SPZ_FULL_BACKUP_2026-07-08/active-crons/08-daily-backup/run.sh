#!/bin/bash
# Daily Backup - 7-Day Rotation
# יוצר גיבוי יומי עם שם ייחודי, שומר 7 ימים אחרונים

set -e

SOURCE_DIR="/home/yosia/.openclaw/workspace/active-crons"
BACKUP_BASE="/home/yosia/.openclaw/workspace"
LOG_FILE="/home/yosia/.openclaw/workspace/active-crons/logs/backup-sync.log"

TODAY=$(date '+%Y-%m-%d')
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
TODAY_BACKUP="${BACKUP_BASE}/SPZ_BACKUP_${TODAY}"

echo "========================================" >> "$LOG_FILE"
echo "[$TIMESTAMP] Starting daily backup (7-day rotation)" >> "$LOG_FILE"
echo "Source: $SOURCE_DIR" >> "$LOG_FILE"
echo "Today's backup: $TODAY_BACKUP" >> "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"

# Create today's backup directory
mkdir -p "$TODAY_BACKUP"

# Sync active-crons/ to today's backup (exclude logs)
rsync -av --delete \
  --exclude='logs/' \
  --exclude='*.log' \
  --exclude='node_modules/' \
  --exclude='.state.json' \
  "$SOURCE_DIR/" "$TODAY_BACKUP/" >> "$LOG_FILE" 2>&1

# Also copy changes.log for reference
if [ -f "$SOURCE_DIR/logs/changes.log" ]; then
    cp "$SOURCE_DIR/logs/changes.log" "$TODAY_BACKUP/"
fi

# Clean up backups older than 7 days
echo "[$TIMESTAMP] Cleaning up backups older than 7 days..." >> "$LOG_FILE"
DELETED=$(find "$BACKUP_BASE" -maxdepth 1 -type d -name 'SPZ_BACKUP_*' -mtime +6)

if [ -n "$DELETED" ]; then
    echo "[$TIMESTAMP] Removing old backups:" >> "$LOG_FILE"
    for dir in $DELETED; do
        echo "  - $(basename "$dir")" >> "$LOG_FILE"
        rm -rf "$dir"
    done
else
    echo "[$TIMESTAMP] No old backups to remove" >> "$LOG_FILE"
fi

# List remaining backups
REMAINING=$(find "$BACKUP_BASE" -maxdepth 1 -type d -name 'SPZ_BACKUP_*' | sort)
BACKUP_COUNT=$(echo "$REMAINING" | grep -c '^' || echo 0)

echo "[$TIMESTAMP] ✅ Backup completed. Total backups: $BACKUP_COUNT" >> "$LOG_FILE"
echo "[$TIMESTAMP] Active backups:" >> "$LOG_FILE"
for dir in $REMAINING; do
    SIZE=$(du -sh "$dir" 2>/dev/null | cut -f1)
    echo "  - $(basename "$dir") ($SIZE)" >> "$LOG_FILE"
done
echo "" >> "$LOG_FILE"
