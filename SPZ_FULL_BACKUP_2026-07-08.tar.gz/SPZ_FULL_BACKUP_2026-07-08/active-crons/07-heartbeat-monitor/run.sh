#!/bin/bash
# ⚠️ חוק מספר 0: קרא תחילה ~/.openclaw/workspace/MASTER-INSIGHTS.md
# ⚠️ חוק מספר 0.2: קרא גם ~/.openclaw/workspace/INSIGHTS-CROSS-REFERENCE.md

# Heartbeat with WhatsApp Alerts
# שולח התראה לוואטסאפ אם יש בעיה בקרונות

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/home/linuxbrew/.linuxbrew/bin"
export HOME="/home/yosia"

# מספר הוואטסאפ לשליחת התראות
ALERT_NUMBER="+972527222872"

LOG_DIR="/home/yosia/.openclaw/workspace/logs"
REPORT_LOG="$LOG_DIR/heartbeat-check.log"
NOW=$(date '+%Y-%m-%d %H:%M:%S')
ALERT_FILE="$LOG_DIR/alert_pending.txt"

# פונקציה לשליחת התראה בוואטסאפ
send_whatsapp_alert() {
    local message="$1"
    wacli send text --to "$ALERT_NUMBER" --message "$message" 2>/dev/null
}

# פונקציה לבדיקת זמן שעבר
hours_since() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo 999
        return
    fi
    local modified=$(stat -c %Y "$file" 2>/dev/null || stat -f %m "$file" 2>/dev/null)
    local now_epoch=$(date +%s)
    echo $(( (now_epoch - modified) / 3600 ))
}

# ניקוי התראות ישנות
rm -f "$ALERT_FILE" 2>/dev/null

echo "=== Heartbeat Check: $NOW ===" >> "$REPORT_LOG"

ISSUES=""

# בדיקה 1: האם הקרונים מוגדרים ב-crontab
CRON_COUNT=$(crontab -l 2>/dev/null | grep -v "^#" | grep -v "^$" | wc -l)
if [ "$CRON_COUNT" -lt 5 ]; then
    ISSUES="${ISSUES}❌ רק $CRON_COUNT קרונות מוגדרים (צריך 5+)\n"
else
    echo "✅ Crontab: $CRON_COUNT entries" >> "$REPORT_LOG"
fi

# בדיקה 2: האם הלוגים של מולטבוק מעודכנים
MOLTBOOK_HOURS=$(hours_since "$LOG_DIR/moltbook_cron.log")
if [ "$MOLTBOOK_HOURS" -gt 4 ]; then
    ISSUES="${ISSUES}❌ מולטבוק לא רץ ${MOLTBOOK_HOURS} שעות\n"
else
    echo "✅ Moltbook: רץ לפני ${MOLTBOOK_HOURS} שעות" >> "$REPORT_LOG"
fi

# בדיקה 3: האם הלוגים של SPZ מעודכנים
SPZ_LOG="$LOG_DIR/twitter_cron_$(date +%Y%m%d).log"
SPZ_HOURS=$(hours_since "$SPZ_LOG")
if [ "$SPZ_HOURS" -gt 5 ]; then
    ISSUES="${ISSUES}❌ SPZ לא רץ ${SPZ_HOURS} שעות\n"
else
    echo "✅ SPZ: רץ לפני ${SPZ_HOURS} שעות" >> "$REPORT_LOG"
fi

# בדיקה 4: האם יש 0 פוסטים ב-SPZ (בעיית API)
if [ -f "$SPZ_LOG" ]; then
    ZERO_POSTS=$(grep -c "0 posts found" "$SPZ_LOG" 2>/dev/null || echo 0)
    if [ "$ZERO_POSTS" -ge 2 ]; then
        ISSUES="${ISSUES}⚠️ SPZ מחזיר 0 פוסטים ($ZERO_POSTS פעמים היום)\n"
    fi
fi

# אם יש בעיות, שלח התראה
if [ -n "$ISSUES" ]; then
    ALERT_MSG="🚨 בעיות בקרונות ($NOW):\n\n${ISSUES}\nבדוק ב-: $REPORT_LOG"
    echo -e "$ALERT_MSG" > "$ALERT_FILE"
    send_whatsapp_alert "$ALERT_MSG"
    echo "🚨 התראה נשלחה!" >> "$REPORT_LOG"
else
    echo "✅ הכול תקין" >> "$REPORT_LOG"
fi

echo "=== Done ===" >> "$REPORT_LOG"
echo "" >> "$REPORT_LOG"
