#!/bin/bash
# Moltbook Single Post - פוסט אחד בלבד
export MOLTBOOK_API_KEY="moltbook_sk_nap5a8cDvw69ncwyxryuG1tY-MXQxN0K"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
LOG_FILE="/home/yosia/.openclaw/workspace/logs/moltbook_cron.log"
ALERT_NUMBER="+972527222872"

echo "$(date '+%Y-%m-%d %H:%M:%S'): Creating single post..." >> "$LOG_FILE"

cd /home/yosia/.openclaw/workspace/skills/moltbook
node scripts/auto-poster.js >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S'): ✅ Post created successfully" >> "$LOG_FILE"
    wacli send text --to "$ALERT_NUMBER" --message "✅ Moltbook Post - פוסט נוצר בהצלחה ($(date '+%H:%M'))" 2>/dev/null
else
    echo "$(date '+%Y-%m-%d %H:%M:%S'): ❌ Post failed" >> "$LOG_FILE"
    wacli send text --to "$ALERT_NUMBER" --message "❌ Moltbook Post - נכשל" 2>/dev/null
fi

echo "$(date '+%Y-%m-%d %H:%M:%S'): Done" >> "$LOG_FILE"
